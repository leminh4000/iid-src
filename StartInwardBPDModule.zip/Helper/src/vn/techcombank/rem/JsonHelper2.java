package vn.techcombank.rem;

import java.io.IOException;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class JsonHelper2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		JSONObject jsonObject = JSONObject.parse("{\"field72\": [\n" +
//                "        {\n" +
//                "            \"field72Narrative\": \"/INS/ABNANL2AXXX\",\n" +
//                "            \"field72\": \"/INS/ABNANL2AXXX\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"field72Narrative\": \"05A.10309\",\n" +
//                "            \"field72Narrative2\": \"/INS/REVOGB2LXXX\",\n" +
//                "            \"field72Narrative3\": \"/INS/BARCDEFF\",\n" +
//                "            \"field72\": \"05A.10309\\r\\n/INS/REVOGB2LXXX\\r\\n/INS/BARCDEFF\"\n" +
//                "        }\n" +
//                "    ]}");
		JSONObject jsonObject = JSONObject.parse("{\"field72\": \"xxx\"}");
	
		System.out.println("f72s = " + getMergedString(jsonObject, "field72"));
	}
	public static String getMergedString( JSONObject jSONObject, String fieldName){
		String result = "";
		Object object = jSONObject.get(fieldName);
		if (object == null) return null;
		//for legacy json string 
		System.out.println(object.getClass());
		if (object instanceof String) {
			return (String) object;
		}
		JSONArray fs =(JSONArray) object;
        if (fs == null || fs.size() == 0) return null;
        for (Object f : fs.toArray()) {
        	JSONObject jsonObject = (JSONObject) f;
        	result += jsonObject.get(fieldName) + "\n";
        }
        result = result.substring(0, result.length() - 1);
        return result; 
	}

}