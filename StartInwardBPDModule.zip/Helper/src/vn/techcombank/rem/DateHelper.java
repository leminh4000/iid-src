package vn.techcombank.rem;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateHelper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(str2Date("200512"));
	}

	public static Date str2Date(String dateStr) {
		SimpleDateFormat format = new SimpleDateFormat("yyMMdd");
		try {
			return format.parse(dateStr);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
