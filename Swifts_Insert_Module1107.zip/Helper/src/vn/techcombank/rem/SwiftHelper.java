package vn.techcombank.rem;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;
import java.util.Properties;

import com.ibm.icu.text.NumberFormat;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

import commonj.sdo.ChangeSummary;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Sequence;
import commonj.sdo.Type;

public class SwiftHelper {

	
	public static void main(String[] args) {
		System.out.println(LocalDateTime.now().toString());
		JSONObject propperties = new JSONObject();
	    propperties.put("SwiftID", "Inward");
	    propperties.put("DocName", "Inward");
	    propperties.put("DocType", "Inward");
	    propperties.put("UserUpload", "BPMUser");
	    propperties.put("CreateTime", LocalDateTime.now().toString());
	    System.out.println(propperties.toString());
	}
	public static String convert2JsonString(String inputString) {
		/*
		 * final String[] metaCharacters = {"\"","/","'","\n"};
		 * 
		 * for (int i = 0 ; i < metaCharacters.length ; i++){
		 * if(inputString.contains(metaCharacters[i])){ inputString =
		 * inputString.replaceAll(metaCharacters[i],"\\"+metaCharacters[i]); } }
		 * return inputString;
		 */
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("SWIFT_MESSAGE", inputString);
		JSONArray array = new JSONArray();
		array.add(jsonObject);
		return array.toString();
	}

}
