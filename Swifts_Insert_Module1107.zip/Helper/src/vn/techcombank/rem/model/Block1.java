package vn.techcombank.rem.model;

public class Block1 {
  private String applicationId;
  private String serviceId;
  private String logicalTerminal;
  private String sessionNumber;
  private String sequenceNumber;


 // Getter Methods 

  public String getApplicationId() {
    return applicationId;
  }

  public String getServiceId() {
    return serviceId;
  }

  public String getLogicalTerminal() {
    return logicalTerminal;
  }

  public String getSessionNumber() {
    return sessionNumber;
  }

  public String getSequenceNumber() {
    return sequenceNumber;
  }

 // Setter Methods 

  public void setApplicationId( String applicationId ) {
    this.applicationId = applicationId;
  }

  public void setServiceId( String serviceId ) {
    this.serviceId = serviceId;
  }

  public void setLogicalTerminal( String logicalTerminal ) {
    this.logicalTerminal = logicalTerminal;
  }

  public void setSessionNumber( String sessionNumber ) {
    this.sessionNumber = sessionNumber;
  }

  public void setSequenceNumber( String sequenceNumber ) {
    this.sequenceNumber = sequenceNumber;
  }
}