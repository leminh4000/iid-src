package vn.techcombank.rem;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class JsonHelper2 {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
//		JSONObject jsonObject = JSONObject.parse("{\"field72\": [\n" +
//                "        {\n" +
//                "            \"field72Narrative\": \"/INS/ABNANL2AXXX\",\n" +
//                "            \"field72\": \"/INS/ABNANL2AXXX\"\n" +
//                "        },\n" +
//                "        {\n" +
//                "            \"field72Narrative\": \"05A.10309\",\n" +
//                "            \"field72Narrative2\": \"/INS/REVOGB2LXXX\",\n" +
//                "            \"field72Narrative3\": \"/INS/BARCDEFF\",\n" +
//                "            \"field72\": \"05A.10309\\r\\n/INS/REVOGB2LXXX\\r\\n/INS/BARCDEFF\"\n" +
//                "        }\n" +
//                "    ]}");
		JSONObject jsonObject = JSONObject.parse("{\"field72\": \"xxx\"}");
	
		System.out.println("f72s = " + getMergedString(jsonObject, "field72"));
		System.out.println("FT = " + getEntryNumber("910", "OUR0100750605303"));
		System.out.println("FX = " + getEntryNumber("910", "OUR010090338"));
	}
	public static String getMergedString( JSONObject jSONObject, String fieldName){
		String result = "";
		Object object = jSONObject.get(fieldName);
		if (object == null) return null;
		//for legacy json string 
		if (object instanceof String) {
			return (String) object;
		}
		JSONArray fs =(JSONArray) object;
        if (fs == null || fs.size() == 0) return null;
        for (Object f : fs.toArray()) {
        	JSONObject jsonObject = (JSONObject) f;
        	result += jsonObject.get(fieldName) + "\n";
        }
        result = result.substring(0, result.length() - 1);
        return result; 
	}
	
	public static String getEntryNumber( String finType, String f21){
		if (f21 == null) return  null; 
		if (!"202".equals(finType) && !"910".equals(finType)) return null;
		if (!f21.startsWith("OUR") || !(f21.length() == 16 || f21.length() == 12)) return null;
		String result = null;
		if (f21.length() == 16){//ft
			result = "FT" + new SimpleDateFormat("yyyy").format(new Date()).charAt(2) +  f21.substring(3); 
		}
		else {
			result = "FX" + new SimpleDateFormat("yyyy").format(new Date()).charAt(2) +  f21.substring(3);
		}
		return result;
	}

}