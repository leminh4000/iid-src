package vn.techcombank.rem;

import java.util.Arrays;
import java.util.List;

public class HtmlHelper {

	public static String setHeader(List<String> headers) {
		StringBuilder result = new StringBuilder();
		result.append("<table>");
		result.append("<tr>");
		for (String header : headers) {
			result.append("<th>");
			result.append(header);
			result.append("</th>");
		}
		result.append("</tr>");
		return result.toString();
	}

	public static String append(List<String> row, String table) {
		StringBuilder result = new StringBuilder(table);

		result.append("<tr>");
		for (String cell : row) {
			result.append("<td>");
			result.append(cell);
			result.append("</td>");
		}
		result.append("</tr>");
		return result.toString();
	}

	public static String toString(String table) {
		StringBuilder result = new StringBuilder(table);
		result.append("</table>");
		return result.toString();
	}

	public static void main(String[] args) {
		/*List<String> headers = Arrays.asList("Company", "Contact", "Country");
		List<List<String>> data = Arrays
				.asList(Arrays.asList("Alfreds Futterkiste", "Maria Anders",
						"Germany"), Arrays.asList("Centro comercial Moctezuma",
						"Francisco Chang", "Mexico"));
		System.out.println(buildTable(headers, data));*/
		java.util.List<String> headers = java.util.Arrays.asList("No", "Swift code", "F20", "Case ID", "Ngày giờ nhận");
		String table = vn.techcombank.rem.HtmlHelper.setHeader(headers);
		String tableBody = "";
		for (int i = 0; i<2; i++){
			java.util.List<String> row = java.util.Arrays.asList(Integer.toString(i), "sender", "f20_value" , "id", java.time.LocalDateTime.now().toString());
			tableBody = vn.techcombank.rem.HtmlHelper.append(row, tableBody);
		}
		table = vn.techcombank.rem.HtmlHelper.toString(table+"<tr><td>2</td><td>84677383828</td><td>2082737373737</td><td>V20450</td><td>2020-05-24T14:12:59.173</td></tr><tr><td>3</td><td>IRVTSXXXXX</td><td>YI345678</td><td>V20478</td><td>2020-05-24T14:12:59.221</td></tr><tr><td>4</td><td>SLDRRU3SXXX</td><td>109FXS3 56702</td><td>V20681</td><td>2020-05-24T14:12:59.264</td></tr><tr><td>5</td><td>SLDRRU3SXXX</td><td>109FXS3 56702</td><td>V20682</td><td>2020-05-24T14:12:59.317</td></tr><tr><td>6</td><td>SLDRRU3SXXX</td><td>109FXS3 56702</td><td>V20723</td><td>2020-05-24T14:12:59.361</td></tr><tr><td>7</td><td>SLDRRU3SXXX</td><td>109FXS3 56702</td><td>V20726</td><td>2020-05-24T14:12:59.403</td></tr>");
		System.out.println(table);
	}

	public static String buildTable(List<String> headers,
			List<List<String>> data) {
		StringBuilder result = new StringBuilder();
		result.append("<table>");
		result.append("<tr>");
		for (String header : headers) {
			result.append("<th>");
			result.append(header);
			result.append("</th>");
		}
		result.append("</tr>");

		for (List<String> row : data) {
			result.append("<tr>");
			for (String cell : row) {
				result.append("<td>");
				result.append(cell);
				result.append("</td>");
			}
			result.append("</tr>");
		}
		result.append("</table>");
		return result.toString();
	}

}
