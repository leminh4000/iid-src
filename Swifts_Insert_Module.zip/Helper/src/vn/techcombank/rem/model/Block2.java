package vn.techcombank.rem.model;

public class Block2 {
  private String senderInputTime;
  private String MIRDate;
  private String MIRLogicalTerminal;
  private String MIRSessionNumber;
  private String MIRSequenceNumber;
  private String receiverOutputDate;
  private String receiverOutputTime;
  private String messagePriority;
  private String messageType;
  private String direction;


 // Getter Methods 

  public String getSenderInputTime() {
    return senderInputTime;
  }

  public String getMIRDate() {
    return MIRDate;
  }

  public String getMIRLogicalTerminal() {
    return MIRLogicalTerminal;
  }

  public String getMIRSessionNumber() {
    return MIRSessionNumber;
  }

  public String getMIRSequenceNumber() {
    return MIRSequenceNumber;
  }

  public String getReceiverOutputDate() {
    return receiverOutputDate;
  }

  public String getReceiverOutputTime() {
    return receiverOutputTime;
  }

  public String getMessagePriority() {
    return messagePriority;
  }

  public String getMessageType() {
    return messageType;
  }

  public String getDirection() {
    return direction;
  }

 // Setter Methods 

  public void setSenderInputTime( String senderInputTime ) {
    this.senderInputTime = senderInputTime;
  }

  public void setMIRDate( String MIRDate ) {
    this.MIRDate = MIRDate;
  }

  public void setMIRLogicalTerminal( String MIRLogicalTerminal ) {
    this.MIRLogicalTerminal = MIRLogicalTerminal;
  }

  public void setMIRSessionNumber( String MIRSessionNumber ) {
    this.MIRSessionNumber = MIRSessionNumber;
  }

  public void setMIRSequenceNumber( String MIRSequenceNumber ) {
    this.MIRSequenceNumber = MIRSequenceNumber;
  }

  public void setReceiverOutputDate( String receiverOutputDate ) {
    this.receiverOutputDate = receiverOutputDate;
  }

  public void setReceiverOutputTime( String receiverOutputTime ) {
    this.receiverOutputTime = receiverOutputTime;
  }

  public void setMessagePriority( String messagePriority ) {
    this.messagePriority = messagePriority;
  }

  public void setMessageType( String messageType ) {
    this.messageType = messageType;
  }

  public void setDirection( String direction ) {
    this.direction = direction;
  }
}