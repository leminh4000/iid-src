package vn.techcombank.rem.model;

import java.util.ArrayList;

public class Block5 {
  ArrayList<Property> tags = new ArrayList<Property>();


 // Getter Methods 



 // Setter Methods 


}