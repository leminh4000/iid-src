package vn.techcombank.rem;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.StringWriter;
import java.util.LinkedHashMap;

import org.apache.log4j.Logger;
import org.apache.log4j.Priority;

import commonj.sdo.DataObject;
import commonj.sdo.Type;

/**
 * @author Vinoth Philominraaj
 * 
 * @version 1.0
 *  
 */

public class BPMCustomLogger {
	private static final String LOGS_LOG4J_PROPERTIES_PATH = "/opt/IBM/BPM/remittance/logs/log4jSwift.properties";
	private static Logger logger;
	static{
		System.setProperty("log4j.configuration", "file:"
				+ BPMCustomLogger.LOGS_LOG4J_PROPERTIES_PATH);
		logger = Logger.getLogger(BPMCustomLogger.class);
	}

private static String dataObjectToString(DataObject dataObject) {
	    String serialForm = null;
	    try {
		    if (dataObject != null) {
	
		        ByteArrayOutputStream output = new ByteArrayOutputStream();
		        Type type = dataObject.getType();
		        try {
					com.ibm.websphere.bo.BOXMLSerializer boXMLSerializer = (com.ibm.websphere.bo.BOXMLSerializer) com.ibm.websphere.sca.ServiceManager.INSTANCE
							.locateService("com/ibm/websphere/bo/BOXMLSerializer");
					boXMLSerializer.writeDataObject(dataObject, type.getURI(), type.getName(), output);
		            serialForm = output.toString("UTF-8");
		            
		        } catch (IOException e) {
		        	StringWriter stringWriter = new StringWriter();
		            serialForm = stringWriter.toString();
		        }
		    }
		    else {
		    	serialForm = "Null DataObject";
		    }
	    }catch(Exception ee){
	    	ee.printStackTrace();
	    }
	    return serialForm;
	}
	
	private static void doLog(DataObject payload,
			String priority) {
		String message = dataObjectToString(payload);
		doLogMessage(message, priority);
	}

	public static void doLogMessage(String message, String priority) {
//		System.setProperty("log4j.configuration", "file:"
//				+ BPMCustomLogger.LOGS_LOG4J_PROPERTIES_PATH);
//		logger = Logger.getLogger(BPMCustomLogger.class);
		logger.log(Priority.toPriority(priority), message);
	}
		


	public static void log(DataObject payload, String priority){
		doLog(payload, priority);
	}


}
