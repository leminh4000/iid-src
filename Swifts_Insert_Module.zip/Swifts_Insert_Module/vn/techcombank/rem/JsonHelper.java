package vn.techcombank.rem;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;

public class JsonHelper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(UUID.randomUUID().toString());
		
		String json = "{     \"field62mCurrency\": \"USD\",     \"field62mAmount\": \"141289,49\",     \"field28cStatementNumber\": \"0141\",     \"type\": \"940\",     \"field60mDCMark\": \"C\",     \"field62mDCMark\": \"C\",     \"field86Narrative\": \"08052020KD2KN LESS CHARGES\",     \"field20\": \"TTS2013300693746\",     \"field86\": \"08052020KD2KN LESS CHARGES\\r\\nBNF:10610600762029 KHAI NGUYEN TRADING CO., LTD\\r\\nORD:FUXIN STEEL BUILDINGS CO LTD\\r\\nPOR SENCHEY DIST PHNOMPENH\",     \"field28cSequenceNumber\": \"00004\",     \"field25\": \"36240292\",     \"swiftCodeNo\": \"CITIUS33XXX\",     \"field60mAmount\": \"115378,50\",     \"field61\": [         {             \"field61ReferenceOfTheAccountServicingInstitution\": \"S0601330198B01\",             \"field61ReferenceForTheAccountOwner\": \"S0601330198B01\",             \"field61DCMark\": \"C\",             \"field61SupplementaryDetails\": \"B/O NEW TALENT INTL LTD.\",             \"field61TransactionType\": \"S\",             \"field61ValueDate\": \"200512\",             \"field61EntryDate\": \"0512\",             \"field61IdentificationCode\": \"100\",    ";;

		try {
			JSONObject jSONObject = JSONObject.parse(json);
			JSONArray f61 = (JSONArray)jSONObject.get ("field61");
			for (int i = 0; i < f61.size(); i++) {
				JSONObject aF61 = (JSONObject)f61.get(i);
				System.out.println(vn.techcombank.rem.DateHelper.str2Date(aF61.get("field61ValueDate").toString()));
				
				BigDecimal df = new BigDecimal(aF61.get("field61Amount").toString().replace(",", "."));
				System.out.println(df);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}

	}

}
