package vn.techcombank.rem;

import org.json.JSONArray;
import org.json.JSONObject;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;

public class TreaOpsPush {
	public static MailInfoType transform(String jsonString) {
		MailInfoType result = new MailInfoType();
		JSONObject jsonObject = new JSONObject(jsonString);
		JSONArray field20C = jsonObject.isNull("field20C") ? null : jsonObject
				.getJSONArray("field20C");
		JSONArray field35B = jsonObject.isNull("field35B") ? null : jsonObject
				.getJSONArray("field35B");
		JSONArray field98A = jsonObject.isNull("field98A") ? null : jsonObject
				.getJSONArray("field98A");
		JSONArray field36B = jsonObject.isNull("field36B") ? null : jsonObject
				.getJSONArray("field36B");
		JSONArray field90B = jsonObject.isNull("field90B") ? null : jsonObject
				.getJSONArray("field90B");
		JSONArray field19A = jsonObject.isNull("field19A") ? null : jsonObject
				.getJSONArray("field19A");
		JSONArray field95P = jsonObject.isNull("field95P") ? null : jsonObject
				.getJSONArray("field95P");
		JSONArray field92A = jsonObject.isNull("field92A") ? null : jsonObject
				.getJSONArray("field92A");

		result.setMsgid(UUID.randomUUID().toString());
		result.setRequesteddate(new Date());
		result.setRef(getValueFromJsonArray(field20C, "field20cReference"));
		result.setSwiftcode(jsonObject.getString("swiftCodeNo"));
		String secCode = field35B != null && field35B.length() > 0 ? field35B
				.getJSONObject(0).getString("field35bISIN").substring(2) : null;
		secCode = (secCode != null) ? secCode
				.substring(0, secCode.length() - 1) : null;
		result.setSeccode(secCode);

		for (int i = 0; field98A != null && i < field98A.length(); i++) {
			JSONObject ajsonObject = field98A.getJSONObject(i);
			switch (Objects.requireNonNull(ajsonObject
					.isNull("field98aQualifier") ? null : ajsonObject
					.getString("field98aQualifier"))) {
			case "TRAD":
				result.setTradedate(string2Date(ajsonObject
						.getString("field98aDate")));
				break;
			case "SETT":
				result.setStartdate(string2Date(ajsonObject
						.getString("field98aDate")));
				break;
			case "TERM":
				result.setEnddate(string2Date(ajsonObject
						.getString("field98aDate")));
				break;
			}
		}
		result.setQuantity(string2Number(getValueFromJsonArray(field36B,
				"field36bQuantity")));
		result.setCleanprice(string2Number(getValueFromJsonArray(field90B,
				"field90bPrice")));
		result.setCurrency(getValueFromJsonArray(field90B, "field90bCurrency"));

		for (int i = 0; field19A != null && i < field19A.length(); i++) {
			JSONObject ajsonObject = field19A.getJSONObject(i);
			switch (Objects.requireNonNull(ajsonObject
					.isNull("field19aQualifier") ? null : ajsonObject
					.getString("field19aQualifier"))) {
			case "SETT":
				result.setAmount(string2Number(ajsonObject
						.getString("field19aAmount")));
				break;
			case "TRTE":
				result.setAmount2(string2Number(ajsonObject
						.getString("field19aAmount")));
				break;
			}
		}
		result.setDealtype(getValueFromJsonArray(field95P, "field95pQualifier"));
		result.setDirtyprice(null);
		result.setRate(string2Number(getValueFromJsonArray(field92A,
				"field92aRateAmount")));
		result.setDocumentid(null);
		return result;
	}

	private static String getValueFromJsonArray(JSONArray jsonArray, String key) {
		return jsonArray != null && jsonArray.length() > 0
				&& !jsonArray.getJSONObject(0).isNull(key) ? jsonArray
				.getJSONObject(0).getString(key) : null;
	}

	private static Date string2Date(String dateString) {
		try {

			DateFormat format = new SimpleDateFormat("yyyyMMdd");
			return format.parse(dateString);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	private static BigDecimal string2Number(String text) {
		if (text == null)
			return null;
		try {

			DecimalFormat df = (DecimalFormat) NumberFormat
					.getInstance(Locale.GERMAN);
			df.setParseBigDecimal(true);
			BigDecimal bd = (BigDecimal) df.parseObject(text);
			System.out.println(bd.toString());
			return bd;
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return null;
	}

	public static class MailInfoType {

		protected String msgid;
		protected Date requesteddate;
		protected String ref;
		protected String swiftcode;
		protected String seccode;
		protected Date tradedate;
		protected Date startdate;
		protected java.math.BigDecimal quantity;
		protected java.math.BigDecimal cleanprice;
		protected String currency;
		protected java.math.BigDecimal amount;
		protected String dealtype;
		protected String dirtyprice;
		protected Date enddate;
		protected java.math.BigDecimal rate;
		protected java.math.BigDecimal amount2;
		protected String documentid;

		public String getMsgid() {
			return msgid;
		}

		public void setMsgid(String msgid) {
			this.msgid = msgid;
		}

		public Date getRequesteddate() {
			return requesteddate;
		}

		public void setRequesteddate(Date requesteddate) {
			this.requesteddate = requesteddate;
		}

		public String getRef() {
			return ref;
		}

		public void setRef(String ref) {
			this.ref = ref;
		}

		public String getSwiftcode() {
			return swiftcode;
		}

		public void setSwiftcode(String swiftcode) {
			this.swiftcode = swiftcode;
		}

		public String getSeccode() {
			return seccode;
		}

		public void setSeccode(String seccode) {
			this.seccode = seccode;
		}

		public Date getTradedate() {
			return tradedate;
		}

		public void setTradedate(Date tradedate) {
			this.tradedate = tradedate;
		}

		public Date getStartdate() {
			return startdate;
		}

		public void setStartdate(Date startdate) {
			this.startdate = startdate;
		}

		public java.math.BigDecimal getQuantity() {
			return quantity;
		}

		public void setQuantity(java.math.BigDecimal quantity) {
			this.quantity = quantity;
		}

		public java.math.BigDecimal getCleanprice() {
			return cleanprice;
		}

		public void setCleanprice(java.math.BigDecimal cleanprice) {
			this.cleanprice = cleanprice;
		}

		public String getCurrency() {
			return currency;
		}

		public void setCurrency(String currency) {
			this.currency = currency;
		}

		public java.math.BigDecimal getAmount() {
			return amount;
		}

		public void setAmount(java.math.BigDecimal amount) {
			this.amount = amount;
		}

		public String getDealtype() {
			return dealtype;
		}

		public void setDealtype(String dealtype) {
			this.dealtype = dealtype;
		}

		public String getDirtyprice() {
			return dirtyprice;
		}

		public void setDirtyprice(String dirtyprice) {
			this.dirtyprice = dirtyprice;
		}

		public Date getEnddate() {
			return enddate;
		}

		public void setEnddate(Date enddate) {
			this.enddate = enddate;
		}

		public java.math.BigDecimal getRate() {
			return rate;
		}

		public void setRate(java.math.BigDecimal rate) {
			this.rate = rate;
		}

		public java.math.BigDecimal getAmount2() {
			return amount2;
		}

		public void setAmount2(java.math.BigDecimal amount2) {
			this.amount2 = amount2;
		}

		public String getDocumentid() {
			return documentid;
		}

		public void setDocumentid(String documentid) {
			this.documentid = documentid;
		}

	}

	public static void main(String[] args) {
		String jsonString = "{\"field19A\":[{\"field19A\":\":SETT//VND12457700000,\",\"field19aAmount\":\"12457700000,\",\"field19aQualifier\":\"SETT\",\"field19aCurrency\":\"VND\"}],\"field23gFunction\":\"NEWM\",\"receiver\":\"VTCBVNVXXXX\",\"field95P\":[{\"field95P\":\":BUYR//VTCBVNVX\",\"field95pQualifier\":\"BUYR\",\"field95pBIC\":\"VTCBVNVX\"}],\"field16S\":[{\"field16sBlockName\":\"GENL\",\"field16S\":\"GENL\"},{\"field16sBlockName\":\"CONFPRTY\",\"field16S\":\"CONFPRTY\"},{\"field16sBlockName\":\"CONFDET\",\"field16S\":\"CONFDET\"}],\"type\":\"518\",\"field16R\":[{\"field16rBlockName\":\"GENL\",\"field16R\":\"GENL\"},{\"field16rBlockName\":\"CONFDET\",\"field16R\":\"CONFDET\"},{\"field16rBlockName\":\"CONFPRTY\",\"field16R\":\"CONFPRTY\"}],\"field90B\":[{\"field90bCurrency\":\"VND\",\"field90bPrice\":\"123090,\",\"field90bAmountTypeCode\":\"ACTU\",\"field90bQualifier\":\"DEAL\",\"field90B\":\":DEAL//ACTU/VND123090,\"}],\"field22H\":[{\"field22H\":\":BUSE//SELL\",\"field22hQualifier\":\"BUSE\",\"field22hCode\":\"SELL\"},{\"field22H\":\":PAYM//FREE\",\"field22hQualifier\":\"PAYM\",\"field22hCode\":\"FREE\"}],\"field23g\":\"NEWM\",\"field22F\":[{\"field22F\":\":TRTR//TRAD\",\"field22fIndicator\":\"TRAD\",\"field22fQualifier\":\"TRTR\"}],\"field20C\":[{\"field20cQualifier\":\"SEME\",\"field20C\":\":SEME//BONDS17509\",\"field20cReference\":\"BONDS17509\"}],\"field98A\":[{\"field98A\":\":TRAD//20201128\",\"field98aQualifier\":\"TRAD\",\"field98aDate\":\"20201128\"},{\"field98A\":\":SETT//20201130\",\"field98aQualifier\":\"SETT\",\"field98aDate\":\"20201130\"}],\"field35B\":[{\"field35B\":\"ISIN VNTD13230329\\r\\nORDER DATE 27/11/2020\",\"field35bQualifier\":\"ISIN\",\"field35bDescription\":\"ORDER DATE 27/11/2020\",\"field35bISIN\":\"VNTD13230329\"}],\"field36B\":[{\"field36bQualifier\":\"CONF\",\"field36B\":\":CONF//UNIT/100000,\",\"field36bQuantity\":\"100000,\",\"field36bQuantityTypeCode\":\"UNIT\"}],\"swiftCodeNo\":\"BIDVVNVXXXX\"}";
		MailInfoType transform = TreaOpsPush.transform(jsonString);
		System.out.println("transform.amount2 =" + transform.amount2);
		System.out.println("transform.amount =" + transform.amount);
		System.out.println("transform.enddate=" + transform.enddate);
	}
}
