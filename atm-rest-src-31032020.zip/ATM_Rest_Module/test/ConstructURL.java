package test;

public class ConstructURL {

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
	public static java.lang.Object sampleTransform(java.lang.String URL,
			java.lang.String from_time, java.lang.String to_time,
			java.lang.String term_name) {
		return URL+"?"+"from_time="+from_time+"&"+"to_time="+to_time+"&" + "term_name="+term_name;
	}

}
