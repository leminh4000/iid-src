import commonj.sdo.DataObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.math.BigInteger;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.oltu.oauth2.client.OAuthClient;
import org.apache.oltu.oauth2.client.URLConnectionClient;
import org.apache.oltu.oauth2.client.request.OAuthClientRequest;
import org.apache.oltu.oauth2.client.response.OAuthJSONAccessTokenResponse;
import org.apache.oltu.oauth2.common.OAuth;
import org.apache.oltu.oauth2.common.exception.OAuthProblemException;
import org.apache.oltu.oauth2.common.exception.OAuthSystemException;
import org.apache.oltu.oauth2.common.message.types.GrantType;

import vn.techcombank.rem.model.Item;
import vn.techcombank.rem.model.Link;
import vn.techcombank.rem.model.SumATMTrans;

import com.google.api.client.auth.oauth2.PasswordTokenRequest;
import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.auth.oauth2.TokenResponseException;
import com.google.api.client.http.BasicAuthentication;
import com.google.api.client.http.GenericUrl;
import com.google.api.client.http.javanet.NetHttpTransport;
import com.google.api.client.json.jackson2.JacksonFactory;
import com.google.gson.Gson;
import com.ibm.websphere.sca.ServiceManager;

public class RestImportImpl {
	/**
	 * Default constructor.
	 */
	public RestImportImpl() {
		super();
	}

	/**
	 * Return a reference to the component service instance for this
	 * implementation class. This method should be used when passing this
	 * service to a partner reference or if you want to invoke this component
	 * service asynchronously.
	 *
	 * @generated (com.ibm.wbit.java)
	 */
	@SuppressWarnings("unused")
	private Object getMyService() {
		return (Object) ServiceManager.INSTANCE.locateService("self");
	}

	/**
	 * Method generated to support implementation of operation "invoke" defined
	 * for WSDL port type named "ATMTransactionCallRest".
	 * 
	 * The presence of commonj.sdo.DataObject as the return type and/or as a
	 * parameter type conveys that it is a complex type. Please refer to the
	 * WSDL Definition for more information on the type of input, output and
	 * fault(s).
	 */
	public DataObject invoke(DataObject atmTransactionReq) {
		// To create a DataObject, use the creation methods on the BOFactory:
		// com.ibm.websphere.bo.BOFactory boFactory =
		// (com.ibm.websphere.bo.BOFactory)
		// ServiceManager.INSTANCE.locateService("com/ibm/websphere/bo/BOFactory");
		//
		// To get or set attributes for a DataObject such as atmTransactionReq,
		// use the APIs as shown below:
		// To set a string attribute in atmTransactionReq, use
		// atmTransactionReq.setString(stringAttributeName, stringValue)
		// To get a string attribute in atmTransactionReq, use
		// atmTransactionReq.getString(stringAttributeName)
		// To set a dataObject attribute in atmTransactionReq, use
		// atmTransactionReq.setDataObject(stringAttributeName, dataObjectValue)
		// To get a dataObject attribute in atmTransactionReq, use
		// atmTransactionReq.getDataObject(stringAttributeName)
		com.ibm.websphere.bo.BOFactory factory = (com.ibm.websphere.bo.BOFactory) new com.ibm.websphere.sca.ServiceManager()
				.locateService("com/ibm/websphere/bo/BOFactory");
		commonj.sdo.DataObject result = factory.create(
				"http://ATM_Transaction_Lib", "AtmTransactionResp");
		commonj.sdo.DataObject faultOut = factory.create(
				"http://techcombank/atm/t24/1.0", "GenericFault");
		try {
			commonj.sdo.DataObject credential = atmTransactionReq
					.getDataObject("credential");
			String endpoint = credential.getString("endpoint");
			String authEndpoint = credential.getString("auth_endpoint");
			String user = credential.getString("user");
			String pass = credential.getString("pass");
			System.out.println("endpoint: " + endpoint);
			String fromTime = atmTransactionReq.getString("from_time");
			String toTime = atmTransactionReq.getString("to_time");
			String termName = atmTransactionReq.getString("term_name");
			System.out.println("term_name: " + termName);

			TokenResponse response = new PasswordTokenRequest(
					new NetHttpTransport(), new JacksonFactory(),
					new GenericUrl(authEndpoint), user, pass)
					.setClientAuthentication(
							new BasicAuthentication(user, pass)).execute();
			String accessToken = response.getAccessToken();
			System.out.println("Access token: " + accessToken);

			String requestUrl = endpoint;
			System.out.println("requestUrl:" + requestUrl);
			URL url = new URL(requestUrl);
			System.out
					.println("1111111111111111111111111111111111111111111111111111111111");

			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");

			conn.setRequestProperty("from_time", fromTime);
			conn.setRequestProperty("to_time", toTime);
			conn.setRequestProperty("term_name", termName);

			conn.setRequestProperty("Accept", "application/json");
			conn.setRequestProperty("Authorization", "Bearer " + accessToken);

			if (conn.getResponseCode() != 200) {
				System.out.println("Status code: " + conn.getResponseCode());
				throw new Exception("Failed : HTTP error code : "
						+ conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader(
					(conn.getInputStream())));

			String json;
			json = br.readLine();

			conn.disconnect();
			Gson g = new Gson();
			SumATMTrans sumATMTrans = g.fromJson(json, SumATMTrans.class);

			System.out.println("count:" + sumATMTrans.getCount());
			System.out.println("Links:" + g.toJson(sumATMTrans.getLinks()));

			List<DataObject> items = new ArrayList();
			if (sumATMTrans.getItems() != null
					&& !sumATMTrans.getItems().isEmpty()) {
				for (Iterator iterator = sumATMTrans.getItems().iterator(); iterator
						.hasNext();) {
					Item item = (Item) iterator.next();

					commonj.sdo.DataObject itemBO = factory.create(
							"http://ATM_Transaction_Lib", "Item");

					itemBO.setString("termname", item.getTermname());

					itemBO.setInt("transcode", item.getTrancode());

					itemBO.setLong("amount",
							item.getAmount());
					items.add(itemBO);
				}
			}
			result.setList("items", items);

			result.setBoolean("hasMore", sumATMTrans.getHasMore());
			result.setInt("limit", sumATMTrans.getLimit());
			result.setInt("offset", sumATMTrans.getOffset());
			result.setInt("count", sumATMTrans.getCount());

			List<DataObject> links = new ArrayList();
			if (sumATMTrans.getLinks() != null
					&& !sumATMTrans.getLinks().isEmpty()) {
				for (Iterator iterator = sumATMTrans.getLinks().iterator(); iterator
						.hasNext();) {
					Link item = (Link) iterator.next();

					commonj.sdo.DataObject linkBO = factory.create(
							"http://ATM_Transaction_Lib", "Link");
					linkBO.setString("rel", item.getRel());
					linkBO.setString("href", item.getHref());
					links.add(linkBO);
				}
			}
			result.setList("links", links);
			faultOut.setInt("status", 0);
			faultOut.setString("message", "Success");
		} catch (Exception e) {
			faultOut.setInt("status", 1);
			faultOut.setString("message", e.getMessage());
			System.out.println(e.getMessage());
			StringWriter errors = new StringWriter();
			e.printStackTrace(new PrintWriter(errors));
			System.out.println(errors.toString());
		}
		result.setDataObject("faultOut", faultOut);
		return result;
	}

	public static void main(String[] args) throws OAuthSystemException,
			OAuthProblemException, IOException {
		/*
		 * OAuthClientRequest request = OAuthClientRequest
		 * .tokenLocation("http://localhost:7003/ords/dwh/oauth/token")
		 * .setGrantType(GrantType.CLIENT_CREDENTIALS)
		 * .setClientId("HQS1kvccj0rv1yC9NdQ7fQ..")
		 * .setClientSecret("g1hbkcI_ZBQb0BH6BMzhrQ..")
		 * .setUsername("HQS1kvccj0rv1yC9NdQ7fQ..")
		 * .setPassword("g1hbkcI_ZBQb0BH6BMzhrQ..").buildQueryMessage();
		 * OAuthClient client = new OAuthClient(new URLConnectionClient());
		 * OAuthJSONAccessTokenResponse response = client.accessToken(request,
		 * OAuth.HttpMethod.POST); String accessToken =
		 * response.getAccessToken(); System.out.println(accessToken);
		 */
		try {
			TokenResponse response = new PasswordTokenRequest(
					new NetHttpTransport(),
					new JacksonFactory(),
					new GenericUrl("http://localhost:7003/ords/dwh/oauth/token"),
					"HQS1kvccj0rv1yC9NdQ7fQ..", "g1hbkcI_ZBQb0BH6BMzhrQ..")
					.setClientAuthentication(
							new BasicAuthentication("HQS1kvccj0rv1yC9NdQ7fQ..",
									"g1hbkcI_ZBQb0BH6BMzhrQ..")).execute();
			System.out.println("Access token: " + response.getAccessToken());
		} catch (TokenResponseException e) {
			if (e.getDetails() != null) {
				System.err.println("Error: " + e.getDetails().getError());
				if (e.getDetails().getErrorDescription() != null) {
					System.err.println(e.getDetails().getErrorDescription());
				}
				if (e.getDetails().getErrorUri() != null) {
					System.err.println(e.getDetails().getErrorUri());
				}
			} else {
				System.err.println(e.getMessage());
			}
		}
	}
}