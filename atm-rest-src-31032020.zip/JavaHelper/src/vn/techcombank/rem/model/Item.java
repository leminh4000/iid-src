package vn.techcombank.rem.model;

public class Item {
	private String termname;
	private int trancode;
	private long amount;
	public Item() {
		super();
	}
	public String getTermname() {
		return termname;
	}
	public void setTermname(String termname) {
		this.termname = termname;
	}
	public int getTrancode() {
		return trancode;
	}
	public void setTrancode(int transcode) {
		this.trancode = transcode;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	
	
}
