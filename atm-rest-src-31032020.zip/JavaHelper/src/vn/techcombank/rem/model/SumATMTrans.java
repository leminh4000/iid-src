package vn.techcombank.rem.model;

import java.util.List;

public class SumATMTrans
{
	public SumATMTrans(){
		
	}
    private List<Item> items;

    private boolean hasMore;

    private int limit;

    private int offset;

    private int count;

    private List<Link> links;

    public void setItems(List<Item> items){
        this.items = items;
    }
    public List<Item> getItems(){
        return this.items;
    }
    public void setHasMore(boolean hasMore){
        this.hasMore = hasMore;
    }
    public boolean getHasMore(){
        return this.hasMore;
    }
    public void setLimit(int limit){
        this.limit = limit;
    }
    public int getLimit(){
        return this.limit;
    }
    public void setOffset(int offset){
        this.offset = offset;
    }
    public int getOffset(){
        return this.offset;
    }
    public void setCount(int count){
        this.count = count;
    }
    public int getCount(){
        return this.count;
    }
    public void setLinks(List<Link> links){
        this.links = links;
    }
    public List<Link> getLinks(){
        return this.links;
    }
}