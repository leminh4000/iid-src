package vn.techcombank.rem.model;

public class Data {
  Block1 Block1Object;
  Block2 Block2Object;
  Block3 Block3Object;
  Block4 Block4Object;
  Block5 Block5Object;


 // Getter Methods 

  public Block1 getBlock1() {
    return Block1Object;
  }

  public Block2 getBlock2() {
    return Block2Object;
  }

  public Block3 getBlock3() {
    return Block3Object;
  }

  public Block4 getBlock4() {
    return Block4Object;
  }

  public Block5 getBlock5() {
    return Block5Object;
  }

 // Setter Methods 

  public void setBlock1( Block1 block1Object ) {
    this.Block1Object = block1Object;
  }

  public void setBlock2( Block2 block2Object ) {
    this.Block2Object = block2Object;
  }

  public void setBlock3( Block3 block3Object ) {
    this.Block3Object = block3Object;
  }

  public void setBlock4( Block4 block4Object ) {
    this.Block4Object = block4Object;
  }

  public void setBlock5( Block5 block5Object ) {
    this.Block5Object = block5Object;
  }
}