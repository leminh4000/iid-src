package vn.techcombank.rem;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

import com.ibm.icu.text.NumberFormat;
import com.ibm.json.java.JSONArray;
import com.ibm.json.java.JSONObject;
import com.prowidesoftware.swift.model.SwiftBlock2.MessagePriority;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.Field;

import commonj.sdo.ChangeSummary;
import commonj.sdo.DataGraph;
import commonj.sdo.DataObject;
import commonj.sdo.Property;
import commonj.sdo.Sequence;
import commonj.sdo.Type;

public class SwiftHelper {

	public static final int AMOUNT_INDEX = 3;
	public static final int VALUE_DATE_INDEX = 1;
	public static final int CURRENCY_INDEX = 2;
	String fin;
	com.prowidesoftware.swift.model.SwiftMessage sm;
	String json;
	String eventId;
	private String f20;
	private String f21;
	private String f52;
	private String f57;
	private String f72;
	private String f79;
	private String sender;
	private String type;
	private String currency;
	private Date value_date;
	private double amount;
	private Locale locale = Locale.getDefault();

	public SwiftHelper(String fin, String eventId) throws Exception {
		super();
		this.fin = fin;
		this.eventId = eventId;
		this.sm = com.prowidesoftware.swift.model.SwiftMessage.parse(fin);
		if (sm.isAck() || sm.isNack()) {
			sm = SwiftMessage.parse(sm.getUnparsedTexts().getAsFINString());
		}
		if (sm.getBlock2() == null || sm.getBlock2() == null)
			throw new Exception("Can not parse Swift message");
		this.json = sm.toJson();
		f20 = Optional.ofNullable(sm.getBlock4().getFieldByName("20"))
				.map(o -> o.getValueDisplay()).orElse("");
		f21 = Optional.ofNullable(sm.getBlock4().getFieldByName("21"))
				.map(o -> o.getValueDisplay()).orElse("");
		f52 = Optional.ofNullable(sm.getBlock4().getFieldByName("52"))
				.map(o -> o.getValueDisplay()).orElse("");
		f57 = Optional.ofNullable(sm.getBlock4().getFieldByName("57"))
				.map(o -> o.getValueDisplay()).orElse("");
		f72 = Optional.ofNullable(sm.getBlock4().getFieldByName("72"))
				.map(o -> o.getValueDisplay()).orElse("");
		f79 = Optional.ofNullable(sm.getBlock4().getFieldByName("79"))
				.map(o -> o.getValueDisplay()).orElse("");
		sender = sm.getSender();
		type = sm.getType();

		Field f32A = sm.getBlock4().getFieldByName("32A");
		this.currency = f32A == null ? null : f32A.getValueDisplay(
				CURRENCY_INDEX, locale);
		try {
			this.value_date = f32A == null ? null : new SimpleDateFormat(
					"MMM dd, yyyy").parse(f32A.getValueDisplay(
					VALUE_DATE_INDEX, locale));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			this.amount = f32A == null ? 0 : NumberFormat.getInstance(locale)
					.parse(f32A.getValueDisplay(AMOUNT_INDEX, locale))
					.doubleValue();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public String getJson() {
		return sm.toJson();
	}

	public String getCurrency() {
		Field f32A = sm.getBlock4().getFieldByName("32A");

		String result = f32A.getValueDisplay(2, locale);
		System.out.println(f32A.getValueDisplay(AMOUNT_INDEX, locale));
		try {
			System.out.println(new SimpleDateFormat("MMM dd, yyyy").parse(f32A
					.getValueDisplay(VALUE_DATE_INDEX, locale)));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		System.out.println("20:"
				+ Optional.ofNullable(sm.getBlock4().getFieldByName("20"))
						.map(o -> o.getValueDisplay()).orElse(""));
		System.out.println("21:"
				+ Optional.ofNullable(sm.getBlock4().getFieldByName("21"))
						.map(o -> o.getValueDisplay()).orElse(""));
		System.out.println("52:"
				+ Optional.ofNullable(sm.getBlock4().getFieldByName("52"))
						.map(o -> o.getValueDisplay()).orElse(""));
		System.out.println("52:"
				+ Optional.ofNullable(sm.getBlock4().getFieldByName("52"))
						.map(o -> o.getValueDisplay()).orElse(""));
		System.out.println("sender:" + sender);
		System.out.println("type:" + type);
		System.out.println("amount:" + amount);
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// String fin =
		// "{1:F21VTCBVNVXAXXX3144688907}{4:{177:1909191435}{451:0}}{1:F01VTCBVNVXAXXX3144688907}{2:O9000335190919MRMDUS33EXXX13311634381909191435N}{3:{108:NAJ7A7003B75}}{4:\n"
		// +
		// ":20:262395785\n" +
		// ":21:9262073850437NBH\n" +
		// ":25:000139645\n" +
		// ":13D:1909190334-0500\n" +
		// ":32A:190919USD18760,90\n" +
		// ":72:/ACC/GUANGZHOU BRANCH\n" +
		// "-}{5:{CHK:FD98610364C9}}{S:{COP:P}}";

		// String fin =
		// "{1:F21VTCBVNVXAXXX3142673782}{4:{177:1909061403}{451:0}}{1:F01VTCBVNVXAXXX3142673782}{2:O7300303190906CITIUS33CXXX70489590241909061403N}{3:{108:90906CUJ21356USA}}{4:\n"
		// +
		// ":20:13621295\n" +
		// ":21:MD1924727400/BIZ\n" +
		// ":30:190905\n" +
		// ":32B:USD160,00\n" +
		// ":71D:ON APPLICANT A/C\n" +
		// "USD135,00STANDBY ADVISING\n" +
		// "USD25,00SWIFT/TELEX\n" +
		// "-}{5:{MAC:00000000}{CHK:896666C15645}}{S:{SAC:}{COP:P}}";

		// String fin =
		// "{1:F21VTCBVNVXAXXX3113599379}{4:{177:1907041840}{451:0}}{1:F01VTCBVNVXAXXX3113599379}{2:O1030739190705CITIUS33HXXX21782618781907041840N}{3:{108:197040211220UV01}{111:001}{121:11ce5026-1a59-4677-85a0-80a9d43c8d5a}}{4:\n"
		// +
		// ":20:S0691860369303\n" +
		// ":23B:CRED\n" +
		// ":32A:190705USD740,5\n" +
		// ":33B:USD748,\n" +
		// ":50K:/USD2000018836601\n" +
		// "ZHANG SHI TAI\n" +
		// "KANGPING RD 95,SHANGHAI,CHINA\n" +
		// ":52A:BOSHCNSHXXX\n" +
		// ":59:/S? T?I KHO?N\n" +
		// "TEN KH\n" +
		// "15B3 LA ASTORIA APARTMENT - 383\n" +
		// "NGUYEN DUY TRINH, HO CHI MIN\n" +
		// ":70:POKER 4\n" +
		// ":71A:SHA\n" +
		// ":71F:USD7,50\n" +
		// "-}{5:{MAC:00000000}{CHK:940A23C476F5}}{S:{SAC:}{COP:P}}[ibminstall@dr-odm-dev swift]$\n"
		// +
		// "[ibminstall@dr-odm-dev swift]$\n" +
		// "[ibminstall@dr-odm-dev swift]$\n" +
		// "[ibminstall@dr-odm-dev swift]$ cat 00229552\\ \\(2\\).out_1\n" +
		// "{1:F21VTCBVNVXAXXX3142667442}{4:{177:1909011139}{451:0}}{1:F01VTCBVNVXAXXX3142667442}{2:O1030005190901BNPAUS3NBXXX13381547491909011139N}{3:{111:001}{121:f746c348-4b63-4cf4-b711-c7bb4284f812}}{4:\n"
		// +
		// ":20:PAY190829C016875\n" +
		// ":23B:CRED\n" +
		// ":32A:190903USD429,00\n" +
		// ":33B:USD429,00\n" +
		// ":50K:/DE57701204008480696007\n" +
		// "SPERONI CHRISTOPHE\n" +
		// "PETER-STRASSER-WEG 4\n" +
		// "12101 BERLIN\n" +
		// "BUNDESREP. DEUTSCHLAND\n" +
		// ":52D:/SW-CSDBDE71\n" +
		// "BNP PARIBAS S.A. NIEDERLASSUNG DEUT\n" +
		// "SCHLAND\n" +
		// "NUERNBERG\n" +
		// "GERMANY\n" +
		// ":54A:SCBLUS33\n" +
		// ":59:/19112345\n" +
		// "VU THI THAO\n" +
		// ":70:CUSTOMER ID: 152\n" +
		// "ORDER DATE: 08/28/2018\n" +
		// "CHRISTOPHE SPERONI\n" +
		// ":71A:OUR\n" +
		// "-}{5:{MAC:00000000}{CHK:938391DED33A}}{S:{SAC:}{COP:P}}";
		// String fin =
		// "{1:F21VTCBVNVXAXXX3142667623}{4:{177:1909021231}{451:0}}{1:F01VTCBVNVXAXXX3142667623}{2:O2020731190902HYVEDEMMAXXX79315001201909021231N}{3:{108:PTS102437936}{119:COV}{111:001}{121:eeef94c7-d0fc-413f-9721-5f3f0507a7a1}}{4:\n"
		// +
		// ":20:AZNA924204408700\n" +
		// ":21:AZNA924204408700\n" +
		// ":32A:190902EUR500,00\n" +
		// ":52A:COBADEFF\n" +
		// ":58A:VTCBVNVX\n" +
		// ":50F:/DE95200411110357431600\n" +
		// "1/DIETER WERTH\n" +
		// "2/SCHULSTRASSE 82A\n" +
		// "3/DE/08352 RASCHAU\n" +
		// ":52A:COBADEHH\n" +
		// ":59:/19026900741014\n" +
		// "VUONG THI MY HUYEN\n" +
		// "1\n" +
		// "VT\n" +
		// ":70:PRIVAT\n" +
		// "-}{5:{MAC:00000000}{CHK:1EA53928CC92}}{S:{SAC:}{COP:P}}";

		// String fin =
		// "{1:F21VTCBVNVXAXXX3111595657}{4:{177:1907021215}{451:0}}{1:F01VTCBVNVXAXXX3111595657}{2:O9100115190703IRVTUS3NUXXX02306700131907021215N}{3:{108:FDC1907020713800}}{4:\n"
		// +
		// ":20:FDC1907020713800\n" +
		// ":21:2019070200123759\n" +
		// ":25P:8900433582\n" +
		// "VTCBVNVX\n" +
		// ":13D:1907020115-0400\n" +
		// ":32A:190702USD107770,\n" +
		// ":50K:1/HERITAGE GROWER CORPORATION\n" +
		// "1/LIMITED\n" +
		// "2/95/10 MOO 8,TAMBOL NAKA,\n" +
		// "3/TH/RANONG 85120 THAILAND\n" +
		// ":52A:SICOTHBK\n" +
		// ":56D:BANK OF AMERICA N.A.\n" +
		// "N.Y. BRANCH\n" +
		// "100 WEST 33RD STREET, NE\n" +
		// "NEW YORK, N.Y. 10001\n" +
		// ":72: CVR OF DIR PYMT\n" +
		// "SSN:092232\n" +
		// "-}{5:{CHK:7F935DA9E3BF}}{S:{COP:P}}";
		// String fin =
		// "{1:F21VTCBVNVXAXXX3144687725}{4:{177:1909181647}{451:0}}{1:F01VTCBVNVXAXXX3144687725}{2:O9501847190918CZNBKRSEAXXX25704457251909181647N}{3:{108:1952478029}}{4:\n"
		// +
		// ":20:8878USD018176001\n" +
		// ":25:8878USD018\n" +
		// ":28C:00176/001\n" +
		// ":60F:C190918USD852433,04\n" +
		// ":61:1909180918CD105,NTRFNONREF//OT07AB1909000053\n" +
		// ":61:1909180918CD248,NTRFNONREF//OT10BS1909000003\n" +
		// ":61:1909180918CD6193,NTRFNONREF//OT07L21909000038\n" +
		// ":61:1909180918CD15470,NTRFNONREF//OT07321909000075\n" +
		// ":61:1909180918CD19836,08NTRFNONREF//OT10BR1909000016\n" +
		// ":61:1909180918CD21464,NTRFNONREF//OT105A1909000036\n" +
		// ":61:1909180918DD25,NCHG9261706652695HTY//TA1909MN00446630\n" +
		// ":61:1909180918DD6300,NTRF9261706652695HTY//IT40331909034528\n" +
		// ":61:1909180918DD52536,60NTRF9259847290634HPG//IT40331909034359\n" +
		// ":62F:C190918USD856887,52\n" +
		// "-}{5:{CHK:5D5EC76EDC6A}}{S:{COP:P}}";
		//
		String fin = "aa";
		// String fin =
		// "{1:F21VTCBVNVXAXXX3113599379}{4:{177:1907041840}{451:0}}{1:F01VTCBVNVXAXXX3113599379}{2:O1030739190705CITIUS33HXXX21782618781907041840N}{3:{108:197040211220UV01}{111:001}{121:11ce5026-1a59-4677-85a0-80a9d43c8d5a}}{4:\n"
		// +
		// ":20:S0691860369303\n" +
		// ":23B:CRED\n" +
		// ":32A:190705USD740,5\n" +
		// ":33B:USD748,\n" +
		// ":50K:/USD2000018836601\n" +
		// "ZHANG SHI TAI\n" +
		// "KANGPING RD 95,SHANGHAI,CHINA\n" +
		// ":52A:BOSHCNSHXXX\n" +
		// ":59:/S? T?I KHO?N\n" +
		// "TEN KH\n" +
		// "15B3 LA ASTORIA APARTMENT - 383\n" +
		// "NGUYEN DUY TRINH, HO CHI MIN\n" +
		// ":70:POKER 4\n" +
		// ":71A:SHA\n" +
		// ":71F:USD7,50\n" +
		// "-}{5:{MAC:00000000}{CHK:940A23C476F5}}{S:{SAC:}{COP:P}}";

		SwiftHelper helper;
		try {
			helper = new SwiftHelper(fin, "1234");
			System.out.println(helper.getReadable());
		} catch (Exception e) {
			// TODO Auto-generated catch block

			System.out.println(getF20(fin));
			System.out.println(getId(fin));
			System.out.println(getType(fin));
		}

		// helper.getCurrency();
		// System.out.println(convert2JsonString(helper.getReadable()));
	}

	public static String swiftMessageToJson(String fin) {
		try {
			SwiftMessage swiftMessage = SwiftMessage.parse(fin);

			if (swiftMessage.isAck() || swiftMessage.isNack()) {
				SwiftMessage sm = SwiftMessage.parse(swiftMessage
						.getUnparsedTexts().getAsFINString());
				return sm.toJson();
			}

			return swiftMessage.toJson();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	public static String swiftMessageToXml(String fin) {
		try {
			SwiftMessage swiftMessage = SwiftMessage.parse(fin);

			if (swiftMessage.isAck() || swiftMessage.isNack()) {
				SwiftMessage sm = SwiftMessage.parse(swiftMessage
						.getUnparsedTexts().getAsFINString());
				return sm.toJson();
			}

			return swiftMessage.toXml();
		} catch (Exception e) {
			// TODO: handle exception
		}
		return null;
	}

	public static String calculateLane(String jsonSwift) {
		return "CTQT";
	}

	public static String convert2JsonString(String inputString) {
		/*
		 * final String[] metaCharacters = {"\"","/","'","\n"};
		 * 
		 * for (int i = 0 ; i < metaCharacters.length ; i++){
		 * if(inputString.contains(metaCharacters[i])){ inputString =
		 * inputString.replaceAll(metaCharacters[i],"\\"+metaCharacters[i]); } }
		 * return inputString;
		 */
		System.out.println("678961111111111111111111111111111111111111");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("SWIFT_MESSAGE", inputString);
		JSONArray array = new JSONArray();
		array.add(jsonObject);
		System.out.println("6789611111111111111111111111111111111111112222");
		return array.toString();
	}

	public String getReadable() {

		/*
		 * With single value per field
		 */
		if (sm.getBlock2() == null || sm.getBlock2() == null)
			return "";
		StringBuilder stringBuilder = new StringBuilder("");

		stringBuilder
				.append("-------------------- Instance Type and Transmission ----------------\n");
		stringBuilder.append("Copy received from SWIFT\n");
		String messagePriorityType = Optional
				.ofNullable(sm.getBlock2().getMessagePriorityType())
				.map(o -> o.toString()).orElse(null);
		String messagePriority = "";
		if ("S".equals(messagePriorityType))
			messagePriority = "System";
		else if ("U".equals(messagePriorityType))
			messagePriority = "Urgent";
		else if ("N".equals(messagePriorityType))
			messagePriority = "Normal";
		stringBuilder.append("Priority : ").append(messagePriority)
				.append("\n");
		String outRef = "";
		String inRef = "";
		try {
			JSONObject block2Object = JSONObject.parse(sm.getBlock2().toJson());
			JSONObject block1Object = JSONObject.parse(sm.getBlock1().toJson());
			System.out.println("block1Object:" + block1Object);
			System.out.println("block2Object:" + block2Object);
			outRef = new StringBuilder(
					(String) block2Object.get("receiverOutputTime"))
					.append(" ").append((String) block2Object.get("MIRDate"))
					.append(sm.getReceiver())
					.append((String) block1Object.get("sessionNumber"))
					.append((String) block1Object.get("sequenceNumber"))
					.toString();
			inRef = new StringBuilder(
					(String) block2Object.get("senderInputTime")).append(" ")
					.append((String) block2Object.get("MIRDate"))
					.append((String) block2Object.get("MIRLogicalTerminal"))
					.append((String) block2Object.get("MIRSessionNumber"))
					.append((String) block2Object.get("MIRSequenceNumber"))
					.toString();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		stringBuilder.append("Message Output Reference : " + outRef + "\n");
		stringBuilder.append("Correspondent Input Reference : " + inRef + "\n");

		stringBuilder
				.append("--------------------------- Message Header -------------------------\n");
		stringBuilder.append("Swift Output : ");
		stringBuilder.append("Sender : " + sm.getSender() + "\n");
		stringBuilder.append("Receiver : " + sm.getReceiver() + "\n");
		stringBuilder.append("MUR : " + sm.getMUR() + "\n");

		stringBuilder
				.append("--------------------------- Message Text -------------------------\n");
		/*
		 * With values per component
		 */
		for (Tag tag : Optional.ofNullable(sm.getBlock4())
				.map(o -> o.getTags()).orElse(new ArrayList<Tag>())) {
			Field field = tag.asField();
			stringBuilder.append(field.getName()
					+ ":\t"
					+ Field.getLabel(field.getName(), sm.getType(), null,
							locale) + "\n");
			for (int component = 1; component <= field.componentsSize(); component++) {
				if (field.getComponent(component) != null) {
					stringBuilder.append("\t"
							+ field.getComponentLabel(component) + ": "
							+ field.getValueDisplay(component, locale) + "\n");
				}
			}
		}

		stringBuilder
				.append("--------------------------- Message Trailer -------------------------\n");
		for (Tag tag : Optional.ofNullable(sm.getBlock5())
				.map(o -> o.getTags()).orElse(new ArrayList<>())) {
			stringBuilder.append("{" + tag.getName() + ":" + tag.getValue()
					+ "}");
		}
		return stringBuilder.toString();
	}

	public void updateRecord(DataObject upsertBpm_Sor_RemittanceSwift_Message) {

		upsertBpm_Sor_RemittanceSwift_Message.setString("type", sm.getType());
		upsertBpm_Sor_RemittanceSwift_Message.setString("sender",
				sm.getSender());

		upsertBpm_Sor_RemittanceSwift_Message.setString("currency", currency);
		upsertBpm_Sor_RemittanceSwift_Message.setDate("created_date",
				new Date());

		upsertBpm_Sor_RemittanceSwift_Message.setDate("value_date", value_date);

		upsertBpm_Sor_RemittanceSwift_Message.setBigDecimal("amount",
				BigDecimal.valueOf(amount));
		upsertBpm_Sor_RemittanceSwift_Message.setString("f20_value", f20);
		upsertBpm_Sor_RemittanceSwift_Message.setString("f21_value", f21);
		upsertBpm_Sor_RemittanceSwift_Message.setInt("status", 0);

		upsertBpm_Sor_RemittanceSwift_Message.setString("from_department", "");
		upsertBpm_Sor_RemittanceSwift_Message.setString("bc", "");
		upsertBpm_Sor_RemittanceSwift_Message.setString("created_by", "");
		upsertBpm_Sor_RemittanceSwift_Message.setString("full_content", json);
		upsertBpm_Sor_RemittanceSwift_Message.setString("suffix", "");
	}

	public void updateDividingRule(DataObject inputClassifyMessage) {
		inputClassifyMessage.setString("currency", currency);
		inputClassifyMessage.setString("f20", f20);
		inputClassifyMessage.setString("f21", f21);
		inputClassifyMessage.setString("f52", f52);
		inputClassifyMessage.setString("f57", f57);
		inputClassifyMessage.setString("f72", f72);
		inputClassifyMessage.setString("f79", f79);
		inputClassifyMessage.setString("sender", sender);
		inputClassifyMessage.setString("typeSwift", type);
	}

	public static String getType(String fin) {
		int typeInd = fin.indexOf("{2:") + 4;
		System.out.println(typeInd);
		System.out.println(fin.length());
		String result;
		try {
			result= fin.substring(typeInd, typeInd + 3);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "";
		}
		return result;
	}

	public static String getF20(String fin) {
		int f20Ind = fin.indexOf("20:") + 3;
		String result;
		try {
			result = fin.substring(f20Ind, fin.indexOf(":", f20Ind));
		} catch (Exception e) {
			// TODO Auto-generated catch block
			return "";
		}
		return result;
	}

	public static String getId(String fin) {
		return "1";
	}

}
