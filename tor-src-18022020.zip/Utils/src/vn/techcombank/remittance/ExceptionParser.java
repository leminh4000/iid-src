package vn.techcombank.remittance;

public class ExceptionParser {
	
	final String FAULT_CODE = "<faultcode>";
	final String FAULT_CODE_END = "</faultcode>";
	final String FAULT_STRING = "<faultstring>";
	final String FAULT_STRING_END = "</faultstring>";
	final String FAIL_STRING = "<failureString>";
	final String FAIL_STRING_END = "</failureString>";
	
	private String errCode;
	private String message;
	private String detail;
	public String getErrCode() {
		return errCode;
	}
	private String failString;
	
	
	public ExceptionParser(String failString) {
		super();
		this.failString = failString;
		parse();
	}
	private void parse() {
		errCode =  StringHelper.getTagValue(failString, FAULT_CODE, FAULT_CODE_END);
		message = StringHelper.getTagValue(failString, FAULT_STRING, FAULT_STRING_END);
		message = (message == null || "".equals(message)) ? StringHelper.getTagValue(failString, FAIL_STRING, FAIL_STRING_END) : message;
		detail = StringHelper.unescapeHtml3(failString);
	}
	public void setErrCode(String errCode) {
		this.errCode = errCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDetail() {
		return detail;
	}
	public void setDetail(String detail) {
		this.detail = detail;
	}
	
	
}
