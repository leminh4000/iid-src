package vn.techcombank.rem;

import java.io.UnsupportedEncodingException;

import javax.xml.bind.DatatypeConverter;

public class HexHelper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	
	public static String convertHexToString(String hex) {
	    hex = hex.replaceAll("^(00)+", "");
	    byte[] bytes = DatatypeConverter.parseHexBinary(hex);
	    try {
			return new String(bytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}

}
