@javax.xml.bind.annotation.XmlSchema(namespace = "http://StartInwardBPDModule")
package vn.techcombank.rem.startbpd;
