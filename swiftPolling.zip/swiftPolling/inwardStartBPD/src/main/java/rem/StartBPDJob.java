package vn.techcombank.rem;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import vn.techcombank.rem.startbpd.StartInwardBPDReq;
import vn.techcombank.rem.startbpd.StartInwardBPDService;
import vn.techcombank.rem.startbpd.StartInwardBPDServiceExport1StartInwardBPDServiceHttpService;

import javax.net.ssl.*;
import java.net.Socket;
import java.security.cert.CertificateException;

public class StartBPDJob implements Job {
    final static Logger logger = Logger.getLogger(StartBPDJob.class);

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        invoke();
    }

    static void invoke() {
        try {
            logger.info("Before call");
            StartInwardBPDServiceExport1StartInwardBPDServiceHttpService service = new StartInwardBPDServiceExport1StartInwardBPDServiceHttpService();
            StartInwardBPDService port = service.getStartInwardBPDServiceExport1StartInwardBPDServiceHttpPort();
            StartInwardBPDReq input1 = new StartInwardBPDReq();
            port.invokeOneWay(input1);
            logger.info("Call success");
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
    }

    public static void main(String[] args) {
        System.setProperty("javax.net.ssl.trustStore", vn.techcombank.rem.StartBPDMain.prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", vn.techcombank.rem.StartBPDMain.prop.getProperty("trustStorePassword"));
//        trustAllHosts();
        invoke();
    }

    public static void trustAllHosts() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509ExtendedTrustManager() {
                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
