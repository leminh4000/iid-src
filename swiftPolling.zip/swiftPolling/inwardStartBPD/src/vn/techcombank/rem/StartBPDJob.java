package vn.techcombank.rem;

import com.sun.xml.internal.ws.client.BindingProviderProperties;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import vn.techcombank.rem.startbpd.StartInwardBPDReq;
import vn.techcombank.rem.startbpd.StartInwardBPDResp;
import vn.techcombank.rem.startbpd.StartInwardBPDService;
import vn.techcombank.rem.startbpd.StartInwardBPDServiceExport1StartInwardBPDServiceHttpService;

import javax.net.ssl.*;
import javax.xml.ws.BindingProvider;
import java.net.Socket;
import java.security.cert.CertificateException;
import java.util.Map;

public class StartBPDJob implements Job {
    final static Logger logger = Logger.getLogger(StartBPDJob.class);

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        invoke();
    }

    static StartInwardBPDResp invoke() {
        StartInwardBPDResp startInwardBPDResp = null;
        try {
//            logger.info("Before call");
            StartInwardBPDServiceExport1StartInwardBPDServiceHttpService service = new StartInwardBPDServiceExport1StartInwardBPDServiceHttpService();
            StartInwardBPDService port = service.getStartInwardBPDServiceExport1StartInwardBPDServiceHttpPort();
            Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
            requestContext.put(BindingProviderProperties.REQUEST_TIMEOUT, new Integer((String) StartBPDMain.prop.get("startInwardRequestTimeout"))); // Timeout in millis
            requestContext.put(BindingProviderProperties.CONNECT_TIMEOUT, new Integer((String) StartBPDMain.prop.get("startInwardConnectTimeout"))); // Timeout in millis

            StartInwardBPDReq input1 = new StartInwardBPDReq();
            input1.setEnv(Integer.valueOf(StartBPDMain.prop.getProperty("env")));
            logger.info("req=" + new JSONObject(input1).toString());
            startInwardBPDResp = port.invokeOneWay(input1);
            logger.info("resp=" + new JSONObject(startInwardBPDResp).toString());

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
        return startInwardBPDResp;
    }

    public static void main(String[] args) {
        System.setProperty("javax.net.ssl.trustStore", vn.techcombank.rem.StartBPDMain.prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", vn.techcombank.rem.StartBPDMain.prop.getProperty("trustStorePassword"));
//        trustAllHosts();
        invoke();
    }

    public static void trustAllHosts() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509ExtendedTrustManager() {
                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
