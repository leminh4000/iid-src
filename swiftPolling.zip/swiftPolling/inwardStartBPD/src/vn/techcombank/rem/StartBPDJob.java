package vn.techcombank.rem;

import org.apache.cxf.configuration.jsse.TLSClientParameters;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.log4j.Logger;
import org.apache.wss4j.dom.handler.WSHandlerConstants;
import org.json.JSONObject;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import vn.techcombank.rem.startbpd.StartInwardBPDReq;
import vn.techcombank.rem.startbpd.StartInwardBPDResp;
import vn.techcombank.rem.startbpd.StartInwardBPDService;
import vn.techcombank.rem.startbpd.StartInwardBPDServiceExport1StartInwardBPDServiceHttpService;

import javax.net.ssl.*;
import java.net.Socket;
import java.net.URL;
import java.security.cert.CertificateException;
import java.util.HashMap;
import java.util.Map;

public class StartBPDJob implements Job {
    final static Logger logger = Logger.getLogger(StartBPDJob.class);

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
        invoke();
    }

    public static void modifyReceiveTimeout(final Object o, int receiveTimeout, int connectionTimeout)
    {
        Client client = ClientProxy.getClient( o );
        HTTPConduit conduit = (HTTPConduit)client.getConduit();
        HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
        httpClientPolicy.setReceiveTimeout(receiveTimeout);
        httpClientPolicy.setConnectionTimeout(connectionTimeout);
        conduit.setClient( httpClientPolicy );


        TLSClientParameters tlsParams = new TLSClientParameters();
        tlsParams.setUseHttpsURLConnectionDefaultSslSocketFactory(true);
        tlsParams.setUseHttpsURLConnectionDefaultHostnameVerifier(true);
        conduit.setTlsClientParameters(tlsParams);
    }
    static StartInwardBPDResp invoke() {
        StartInwardBPDResp startInwardBPDResp = null;
        try {
//            logger.info("Before call");
            StartInwardBPDServiceExport1StartInwardBPDServiceHttpService service = new StartInwardBPDServiceExport1StartInwardBPDServiceHttpService(new URL(StartBPDMain.prop.getProperty("startBPDEndpoint")));
            StartInwardBPDService port = service.getStartInwardBPDServiceExport1StartInwardBPDServiceHttpPort();
            if ("true".equals(StartBPDMain.prop.get("isEncryted"))) {
                org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
                org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();
                WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(createOutProps());
                cxfEndpoint.getOutInterceptors().add(wssOut);
            }

//            Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
//            requestContext.put(BindingProviderProperties.REQUEST_TIMEOUT, Integer.parseInt((String) StartBPDMain.prop.get("startInwardRequestTimeout"))); // Timeout in millis
//            requestContext.put(BindingProviderProperties.CONNECT_TIMEOUT, Integer.parseInt((String) StartBPDMain.prop.get("startInwardConnectTimeout"))); // Timeout in millis
            modifyReceiveTimeout(port, Integer.parseInt((String) StartBPDMain.prop.get("startInwardRequestTimeout")), Integer.parseInt((String) StartBPDMain.prop.get("startInwardConnectTimeout")));

            StartInwardBPDReq input1 = new StartInwardBPDReq();
            input1.setMaxRetries(Integer.valueOf(StartBPDMain.prop.getProperty("maxRetries")));
            input1.setMaxConcurrentProcess(Integer.valueOf(StartBPDMain.prop.getProperty("maxConcurrentProcess")));
            logger.info("req=" + new JSONObject(input1).toString());
            startInwardBPDResp = port.invokeOneWay(input1);
            logger.info("resp=" + new JSONObject(startInwardBPDResp).toString());

        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
        return startInwardBPDResp;
    }

    private static Map<String, Object> createOutProps() {
        Map<String, Object> outProps = new HashMap<String, Object>();
        outProps.put("action", "Timestamp Encrypt");
        outProps.put("encryptionUser", "hpt");
        outProps.put("encryptionPropFile", "Client_Encrypt.properties");
        outProps.put("encryptionKeyIdentifier", "IssuerSerial");
        outProps.put(WSHandlerConstants.ENC_KEY_TRANSPORT, "http://www.w3.org/2001/04/xmlenc#rsa-1_5");
        return outProps;
    }

    public static void main(String[] args) {
        System.setProperty("javax.net.ssl.trustStore", vn.techcombank.rem.StartBPDMain.prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", vn.techcombank.rem.StartBPDMain.prop.getProperty("trustStorePassword"));
//        trustAllHosts();
        invoke();
    }

    public static void trustAllHosts() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509ExtendedTrustManager() {
                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
