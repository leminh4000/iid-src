
package vn.techcombank.rem.startbpd;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="input1" type="{http://StartInwardBPDModule}StartInwardBPDReq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "input1"
})
@XmlRootElement(name = "invokeOneWay", namespace = "http://StartInwardBPDModule/StartInwardBPDService")
public class InvokeOneWay {

    @XmlElement(required = true, nillable = true)
    protected StartInwardBPDReq input1;

    /**
     * Gets the value of the input1 property.
     * 
     * @return
     *     possible object is
     *     {@link StartInwardBPDReq }
     *     
     */
    public StartInwardBPDReq getInput1() {
        return input1;
    }

    /**
     * Sets the value of the input1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link StartInwardBPDReq }
     *     
     */
    public void setInput1(StartInwardBPDReq value) {
        this.input1 = value;
    }

}
