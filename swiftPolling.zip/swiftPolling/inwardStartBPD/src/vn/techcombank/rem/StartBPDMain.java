package vn.techcombank.rem;

import org.quartz.*;
import vn.techcombank.rem.startbpd.StartInwardBPDResp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.Properties;

import static vn.techcombank.rem.StartBPDJob.logger;
import static vn.techcombank.rem.StartBPDJob.trustAllHosts;

public class StartBPDMain {
    public static Properties prop;

    static {
        InputStream is = null;
        try {
            prop = new Properties();
            is = new FileInputStream("StartBPD.properties");
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static ServerSocket socket = null;

    public static void main(String[] args) throws SchedulerException {
        try{
            socket =
                    new ServerSocket(Integer.parseInt(prop.getProperty("localPort")), 10, InetAddress.getLocalHost());

        }catch(java.net.BindException b){
            System.out.println("Already Running...");
            System.exit(1);
        }catch(Exception e){
            System.out.println(e.toString());
        }
        trustAllHosts();
        System.setProperty("javax.net.ssl.trustStore", prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", prop.getProperty("trustStorePassword"));
        /*JobDetail startBPDJob = JobBuilder.newJob(StartBPDJob.class)
                .withIdentity("StartBPD", "group1").build();


        Trigger startBPDtrigger = TriggerBuilder
                .newTrigger()
                .withIdentity("StartBPD", "group1")
                .withSchedule(
                        SimpleScheduleBuilder.simpleSchedule()
                                .withIntervalInSeconds(Integer.parseInt(StartBPDMain.prop.getProperty("startBPDIntervalInSecond"))).repeatForever())
                .build();

        // schedule it
        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(startBPDJob, startBPDtrigger);*/
        while (true){
            StartInwardBPDResp startInwardBPDResp = StartBPDJob.invoke();
            try {
                if (startInwardBPDResp != null && startInwardBPDResp.getStatus() == 0) {
                    logger.info("The returned result is successful, the system will sleep for " +
                            prop.getProperty("startBPDIntervalInSecond") +
                            " seconds");
                    Thread.sleep(Long.parseLong(prop.getProperty("startBPDIntervalInSecond")) * 1000);
                }
                else{
                    logger.error("Attention: The returned result has been failed, the system will sleep for " +
                            prop.getProperty("startBPDIntervalInSecondFail") +
                            " seconds");
                    Thread.sleep(Long.parseLong(prop.getProperty("startBPDIntervalInSecondFail"))*1000);
                }
            } catch (InterruptedException e) {
                logger.error(e);
                e.printStackTrace();
            }
        }

    }
}
