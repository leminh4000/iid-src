package vn.techcombank.rem;

import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;

public class TestScheduler {
    public static void main(String[] args) throws SchedulerException {
        JobDetail jobDetail = JobBuilder.newJob(TestJob.class)
                .withIdentity("TEST", "group1").build();


        Trigger trigger = TriggerBuilder
                .newTrigger()
                .withIdentity("TEST", "group1")
                .withSchedule(
                        SimpleScheduleBuilder.simpleSchedule()
                                .withIntervalInSeconds(2).repeatForever())
                .build();

        // schedule it
        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(jobDetail, trigger);
    }

}
