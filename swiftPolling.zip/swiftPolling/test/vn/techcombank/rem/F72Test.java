package vn.techcombank.rem;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class F72Test {
    String fin;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        fin =
         "{1:F21VTCBVNVXAXXX3227952403}{4:{177:2005131247}{451:0}}{1:F01VTCBVNVXAXXX3227952403}{2:O2021747200513UOVBSGSGAXXX60372095212005131247N}{3:{108:PTS105647580}{119:COV}{111:001}{121:9af15dc7-b650-4d8d-bda1-6a67b620f353}}{4:\n" +
                 ":20:1OR909092300C11\n" +
                 ":21:TP19242007957557\n" +
                 ":32A:200513EUR1330,00\n" +
                 ":52A:UOVBSGSGXXX\n" +
                 "UNITED OVERSEAS BANK LIMITED\n" +
                 "SINGAPORE SG\n" +
                 ":58A:VTCBVNVXXXX\n" +
                 "VIETNAM TECHNOLOGICAL AND COMMERCIAL JOINT STOCK BANK\n" +
                 "HANOI VN\n" +
                 ":50F:/DE56700400410226118800\n" +
                 "1/GOETHE-INSTITUT E.V.\n" +
                 "2/OSKAR-VON-MILLER-RING 18\n" +
                 "3/DE/80333 MUENCHEN\n" +
                 ":52A:COBADEHH\n" +
                 ":59:/1152196\n" +
                 "NGUYEN NGOC \n" +
                 "UNIT 1604, CT2A BUILDING\n" +
                 ":70:NR.II/2018/401-522/10.4.2020\n" +
                 ":72Z:abc TF12301233 abc\n" +
                 "\n" +
                 "-}{5:{MAC:00000000}{CHK:754D9BA317E0}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(fin, "test.txt");
    }
    @Test
    public void test() {
        Assert.assertTrue(swiftMT.getF72s() != null && !swiftMT.getF72s().equals(""));
    }
}
