package vn.techcombank.rem;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MT940Test {
    String finMT940;
    private JSONObject jsonObject;
    private SwiftMT swiftMT;
    private JSONArray field61s;

    @Before
    public void setup() throws Exception {
        finMT940 =
                "{1:F21VTCBVNVXAXXX3227951926}{4:{177:2005130727}{451:0}}{1:F01VTCBVNVXAXXX3227951926}{2:O9402027200512CITIUS33DXXX24933209582005130727N}{3:{108:00513LPB89336USA}}{4:\n" +
                ":20:TTS2013300/TUAN111\n" +
                ":25:36240292\n" +
                ":28C:0141/00006\n" +
                ":60M:C200512USD194536,66\n" +
                ":61:2005120512CD10162,00S100S06013307C8001//S06013307C8001\n" +
                "B/O PHAM BICH VAN\n" +
                ":86:TRANSFER FOR PERSONAL NEEDS LESS CHARGES\n" +
                "BNF:19133407707010 PHAM BICH VAN 208 PHAM THAI BUONG,\n" +
                "ORD:PHAM BICH VAN\n" +
                "HOCHIMINH VN\n" +
                "ZAO RAIFFEISENBANK USD ACCOUNT\n" +
                ":61:2005120512CD10757,13S910C514182OCP051220//C0001331861801\n" +
                "B/O 1/I TRUST NETWORK CO.,LTD\n" +
                ":86:YR HA THANH BRANCHNO 74 BA TRIEU STREET,HANG BAI WORD HOAN KIEMD\n" +
                "ISTRICT HANOI\n" +
                "ORD:1/I TRUST NETWORK CO.,LTD\n" +
                "3/TH/SAMUTPARKAN THAILAND\n" +
                "SIAM COMMERCIAL BANK PUBLIC CO\n" +
                ":61:2005120512CD11979,50S100S06013306AEC01//S06013306AEC01\n" +
                "B/O THANH THUY MY SCHENKEL\n" +
                ":86:LESS CHARGES\n" +
                "BNF:19020213225016 NGUYEN THANH VAN\n" +
                "ORD:THANH THUY MY SCHENKEL\n" +
                "8820 WAEDENSWIL\n" +
                "BANQUE CANTONALE DE ZURICH\n" +
                ":61:2005120512CD14305,00S910C520984OCP051220//C0001332645401\n" +
                "B/O ANDERSON WHOLESALE PACKAGING\n" +
                ":86:ORD:ANDERSON WHOLESALE PACKAGING PTY LT\n" +
                "4109 SUNNYBANK HILLS QLD\n" +
                "NATIONAL AUSTRALIA BANK LIMITE\n" +
                ":61:2005120512CD15804,06S100S0601330958D01//S0601330958D01\n" +
                "B/O PAUL REINHART AG\n" +
                ":86:/ROC/2PRW8-20200508-AAFETR COMM. LESS CHARGES\n" +
                "BNF:19110116421888 DAU XUAN HOA\n" +
                "ORD:PAUL REINHART AG\n" +
                "8400 WINTERTHUR\n" +
                "BANQUE CANTONALE DE ZURICH\n" +
                ":61:2005120512CD18546,00S100C0001333581701//C0001333581701\n" +
                "B/O YEUNG MARINE PRODUCTS INC\n" +
                ":86:PAYMENT TO SUPPLIER LESS CHARGES\n" +
                "BNF:19128818976019 TRUNG HOANG KHANH\n" +
                "ORD:YEUNG MARINE PRODUCTS INC\n" +
                "PHILIPPINES\n" +
                "CTBC BANK PHILIPPINES CORP\n" +
                ":61:2005120512CD20284,00S910C535097OCP051220//C0001335290601\n" +
                "B/O SEASCO COMPANY LTD\n" +
                ":86:ORD:SEASCO COMPANY LTD\n" +
                "MICRONESIA FED STATES OF\n" +
                "BANK OF THE FEDERATED STATES O\n" +
                ":62M:C200512USD296374,35\n" +
                "-}{5:{CHK:8550791493E8}}{S:{COP:P}}";
            swiftMT = new SwiftMT(finMT940, "test.txt");
            jsonObject = new JSONObject(swiftMT.getReadableJson());
        field61s = (JSONArray) jsonObject.get("field61");

    }
    @Test
    public void test() {
        Assert.assertEquals(swiftMT.getType(), "940");
        Assert.assertNotNull("Amount is greater than 0", swiftMT.getCurrency());
    }

    @Test
    public void testF61() {
        Assert.assertTrue("Field 61 array have element", field61s.length() > 0);
    }
    @Test
    public void testCcyNotNull() throws Exception {
        String finMT9402 =
                "{1:F21VTCBVNVXAXXX3211904737}{4:{177:2003280609}{451:0}}{1:F01VTCBVNVXAXXX3211904737}{2:O9402309200419SCBLGB2LBXXX46082452652003280609N}{3:{108:202003270013685}}{4:\n" +
                        ":20:0327000486882983\n" +
                        ":25:01703923901\n" +
                        ":28C:2588/1\n" +
                        ":60F:C200326GBP1278105,97\n" +
                        ":61:2003270327D12825,60NMSC0086530160089DDA//03274608086311  \n" +
                        ":86:LINCOLN MARITIME LIMITEDHOP NHAT INTERNATIONAL JSC:PMT FORINTERNA\n" +
                        "TIONAL STATEMENT AMOUNT12,825.60 GBP\n" +
                        ":61:2003270327C801,00NMSCPET411415087//03275032053930  \n" +
                        ":86:GB35REVO009970868815701/MICHAEL BRAZIER2/43 PALMERSTON ROAD3/GB/C\n" +
                        "OVENTRY CV5 6FHSAM\n" +
                        ":61:2003270327D20,CTQT.103.18//03274608086311  \n" +
                        ":86:LINCOLN MARITIME LIMITEDHOP NHAT INTERNATIONAL JSC:PMT FORINTERNA\n" +
                        "TIONAL STATEMENT AMOUNT12,825.60 GBP\n" +
                        ":61:2003270327D1000,00NMSC0087137179305TKE//03275032069946  \n" +
                        ":86:P H PHAM TRANTRANSFER FOR LIVING FEE\n" +
                        ":61:2003270327C19,67NMSCFT20079050466008//03270438604858  \n" +
                        ":86:TB CHARGES OURSETTLEMENT OF YRCHARGES CLAIM FOR OUR MT103REF RBO1\n" +
                        "8030AN76LJI8 DD 20200318FOR ANY QUERIES PLS CONTACT USUNDER CLAIM\n" +
                        ".CHARGE(AT)SC.COMUNDER REF UKH200327-000051\n" +
                        ":62M:C200327GBP1265081,04\n" +
                        "-}{5:{CHK:3A34815868AE}}{S:{COP:P}}";
        SwiftMT swiftMT2 = new SwiftMT(finMT9402, "test.txt");
        String currency = swiftMT2.getCurrency();

        Assert.assertTrue("Currency not null", currency != null && !currency.equals(""));
    }
}
