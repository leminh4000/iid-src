package vn.techcombank.rem;

import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MT910Test {
    String finMT910;
    private JSONObject jsonObject;
    private SwiftMT swiftMT;
    private JSONArray field61s;

    @Before
    public void setup() throws Exception {
        finMT910 =
                "{1:F21VTCBVNVXAXXX3227952132}{4:{177:2005131027}{451:0}}{1:F01VTCBVNVXAXXX3227952132}{2:O9102327200512PNBPUS3NCNYC11921195433010202005N}{3:{108:209555449RSC3}}{4:\n" +
                        ":20:TPP FEE SHA30105\n" +
                        ":21:DK5.910/301020-5\n" +
                        ":25:2000191004023\n" +
                        ":13D:2010292326-0400\n" +
                        ":32A:201029USD1192,00\n" +
                        ":52D:WESTERN UNION/8900708905\n" +
                        "BQIDBQAQAXX\n" +
                        ":56A:/8900708905\n" +
                        "QIDBQAQAXXX\n" +
                        "-}{5:{CHK:556437513E1B}}{S:{COP:P}}";
            swiftMT = new SwiftMT(finMT910, "test.txt");
            jsonObject = new JSONObject(swiftMT.getReadableJson());

    }
    @Test
    public void test() throws Exception {
        Assert.assertEquals(swiftMT.getType(), "910");
        Assert.assertNotNull("Amount is greater than 0", swiftMT.getCurrency());
        Assert.assertNotNull("Not null", swiftMT.getReadable());
    }


}
