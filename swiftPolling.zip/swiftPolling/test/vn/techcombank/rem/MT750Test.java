package vn.techcombank.rem;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MT750Test {
    String fin;
    private SwiftMT swiftMT;
    private JSONObject jsonObject;
    private String field98A;


    @Before
    public void setup() throws Exception {
        fin =
                "{1:F21VTCBVNVXAXXX3238980317}{4:{177:2006051356}{451:0}}{1:F01VTCBVNVXAXXX3238980317}{2:O7501125211105BOPIPHMMAXXX97188894622006051356N}{4:\n" +
                        ":20:TESTMEINU32345678Tads\n" +
                        ":21:AHAHAHA\n" +
                        ":72Z:E20125020270385555\n" +
                        ":32B:USD43920,\n" +
                        ":77J:RE : YOUR REFERENCE NO. OUR LC\n" +
                        "NO.00407010250112 DOCUMENTS FOR\n" +
                        "USD43920,\n" +
                        "WE REFUSE TO HONOR DOCUMENTS DUE TO THE FOLLOWING\n" +
                        "DISCREPANCIES:\n" +
                        "1. LATE SHIPMENT\n" +
                        "2. EXPIRED LC\n" +
                        "WE ARE HOLDING DOCUMENTS UNTIL RECEIPT OF\n" +
                        "ACCEPTANCE FROM APPLICANT. WE WILL REVERT.\n" +
                        "-}{5:{MAC:00000000}{CHK:7A2196F61D2C}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(fin, "test.txt");
        jsonObject = new JSONObject(swiftMT.getReadableJson());
    }
    @Test
    public void test() {
        Assert.assertEquals(swiftMT.getType(), "750");
    }

    @Test
    public void testJson() {
        String readableJson = swiftMT.getReadableJson();
        System.out.println(readableJson);
        Assert.assertNotNull(readableJson);
    }

    @Test
    public void testReadable() throws Exception {
        String readable = swiftMT.getReadable();
        System.out.println(readable);
        Assert.assertNotNull(readable);
    }
}
