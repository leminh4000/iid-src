package vn.techcombank.rem;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SwiftHelperTest {
    String fin;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        fin = "{1:F21VTCBVNVXAXXX3227951980}{4:{177:2005130829}{451:0}}{1:F01VTCBVNVXAXXX3227951980}{2:O5180829200513ASCBVNVXAXXX77617537382005130829N}{4:\n" +
                ":16X:GENL\n" +
                ":20C::SEME//KNQ5608-20\n" +
                ":23G:NEWM\n" +
                ":22F::TRTR//TRAD\n" +
                ":16S:GENL\n" +
                ":16R:CONFDET\n" +
                ":98A::TRAD//20200512\n" +
                ":98A::SETT//20200514\n" +
                ":90B::DEAL//ACTU/VND128422,\n" +
                ":19A::SETT//VND65113500000,\n" +
                ":22H::BUSE//SELL\n" +
                ":22H::PAYM//FREE\n" +
                ":16R:CONFPRTY\n" +
                ":95P::BUYR//VTCBVNVXXXX\n" +
                ":16S:CONFPRTY\n" +
                ":36B::CONF//UNIT/500000,\n" +
                ":35B:ISIN VNTD19392008\n" +
                ":16S:CONFDET\n" +
                "-}{5:{MAC:00000000}{CHK:7B1E0DD7D855}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(fin, "test.txt");
    }
    @Test
    public void test() {
        Assert.assertNotNull(swiftMT.getType());
    }

    @Test
    public void testReadable() throws Exception {
        System.out.println(swiftMT.getReadable());
        Assert.assertTrue("Readable have Sender string", swiftMT.getReadable().contains("Sender"));
    }
    @Test
    public void testDate() throws ParseException {
        Date date = new SimpleDateFormat("yyyyD").parse("202911");
        System.out.println(date);

    }
    @Test
    public void testF59() throws Exception {
        SwiftMT swiftMT = new SwiftMT("{1:F21VTCBVNVXAXXX3142667623}{4:{177:1909021231}{451:0}}{1:F01VTCBVNVXAXXX3142667623}{2:O2020721548609SMBCJPJTAXXX79315301201919021231N}{3:{108:PTS102437936}{111:001}{119:COV}{121:eeef94c7-d0fc-413f-9721-5f3f0507a7a1}}{4:\n" +
                ":20:HIEU3284912\n" +
                ":21:AZNA924204408701\n" +
                ":32A:190902USD500,00\n" +
                ":52A:SLDRRU3SXXX\n" +
                ":58A:/19131163346689\n" +
                "SLDRRU3SXXX\n" +
                ":50F:/DE95200411110357431600\n" +
                "1/DIETER WERTH\n" +
                "2/SCHULSTRASSE 82A\n" +
                "3/DE/08352 RASCHAU\n" +
                ":59:/19026900741014\n" +
                "VUONG THI MY HUYEN\n" +
                "1\n" +
                "VT\n" +
                ":70:PRIVAT\n" +
                ":72:ATTN LC DEPT,\n" +
                ":72:HIEU3214008\n" +
                "-}{5:{MAC:00000000}{CHK:1EA53928CC92}}{S:{SAC:}{COP:P}}", null);
        Assert.assertTrue("Readable found", swiftMT.getReadable().length() > 0);

    }

    @Test
    public void testString() throws Exception {
        SwiftMT swiftMT = new SwiftMT("{1:F21VTCBVNVXAXXX3227952105}{4:{177:2005131001}{451:0}}{1:F01VTCBVNVXAXXX3227952105}{2:O1031424193003PNBPUS3N1NYC16152710042088031001N}{3:{119:STP}{111:001}{121:89ddd22d-fa66-4343-bb57-c47194696e5b}}{4:\n" +
                ":20:HIEU3214009\n" +
                ":23B:CRED\n" +
                ":32A:200513USD13300000\n" +
                ":33B:USD3000000,\n" +
                ":36:12,4\n" +
                ":50K:1/HERITAGE GROWER CORPORATION\n" +
                "1/LIMITED\n" +
                "2/95/10 MOO 8,TAMBOL NAKA,\n" +
                "3/TH/RANONG 85120 THAILAND\n" +
                ":52A:CITIHKHXXXX\n" +
                "CITIBANK N.A.\n" +
                "HONG KONG HK\n" +
                "CITIBANK JAPAN LTD.\n" +
                "TOKYO JP\n" +
                ":53A:SMBCJPJTXXX\n" +
                ":59:/19133188159037\n" +
                "KHACH HANG 33188159\n" +
                "123 XA DAN\n" +
                "DONG DA, HA NOI\n" +
                ":70:NR.001/13.4.2020\n" +
                ":71A:OUR\n" +
                ":71F:TEST TEST TEST\n" +
                ":72:\n" +
                "\n" +
                "-}{5:{MAC:00000000}{CHK:193937E9D67D}}{S:{SAC:}{COP:P}}", null);
        System.out.println(swiftMT.getReadable());
        Assert.assertTrue("Readable found", swiftMT.getReadable().length() > 0);

    }
    @Test
    public void testf72() throws Exception {
        SwiftMT swiftMT = new SwiftMT("{1:F21VTCBVNVXAXXX3142667623}{4:{177:1909021231}{451:0}}{1:F01VTCBVNVXAXXX3142667623}{2:O2020721188562SMBCJPJTAXXX79315301201919021231N}{3:{108:PTS102437936}{111:001}{119:COV}{121:eeef94c7-d0fc-413f-9721-5f3f0507a7a1}}{4:\n" +
                ":20:HIEU3284901\n" +
                ":21:AZNA924204408748\n" +
                ":32A:190902USD500,00\n" +
                ":52A:SLDRRU3SXXX\n" +
                ":58A:/19131163346689\n" +
                "SLDRRU3SXXX\n" +
                ":50F:/DE95200411110357431600\n" +
                "1/DIETER WERTH\n" +
                "2/SCHULSTRASSE 82A\n" +
                "3/DE/08352 RASCHAU\n" +
                ":59:/19026900741014\n" +
                "VUONG THI MY HUYEN\n" +
                "1\n" +
                "VT\n" +
                ":70:PRIVAT\n" +
                ":72:ATTN LC DEPT,\n" +
                ":72:HIEU3214041\n" +
                "-}{5:{MAC:00000000}{CHK:1EA53928CC92}}{S:{SAC:}{COP:P}}", null);
        System.out.println(swiftMT.getF72());
        Assert.assertTrue("Readable found", swiftMT.getF72().contains("HIEU3214041"));

    }

}
