package vn.techcombank.rem;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class MT103Test {
    String finMT103;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        finMT103 =
         "{1:F01PNBPUS3N1NYC0000000000}{2:I103FOORECV0XXXXN}{3:{121:58e770ff-e782-4a2e-936a-763e1e6cbddd}}{4:\n" +
                 ":20:REFERENCE\n" +
                 ":23B:CRED\n" +
                 ":32A:200925EUR1234567,89\n" +
                 ":50A:/12345678901234567890\n" +
                 "FOOBANKXXXXX\n" +
                 ":59:/12345678901234567890\n" +
                 "JOE DOE\n" +
                 ":71A:OUR\n" +
                 "-}";
        swiftMT = new SwiftMT(finMT103, "test.txt");
    }
    @Test
    public void test() {
        System.out.println("sender="+ swiftMT.getSender());
        Assert.assertEquals(swiftMT.getType(), "103");
        Assert.assertTrue("Amount is greater than 0", swiftMT.getAmount().compareTo(new BigDecimal(0)) > 0);
    }

    @Test
    public void testValueDateIn2019() throws ParseException {
        Assert.assertTrue("Value date in 2919", swiftMT.getValue_date().after(new SimpleDateFormat("yyyy-MM-dd").parse("2019-01-01")) && swiftMT.getValue_date().before(new SimpleDateFormat("yyyy-MM-dd").parse("2020-01-01")));
    }
}
