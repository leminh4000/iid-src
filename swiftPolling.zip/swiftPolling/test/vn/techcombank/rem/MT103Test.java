package vn.techcombank.rem;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import vn.techcombank.rem.exception.ParserException;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;

public class MT103Test {
    String finMT103;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        finMT103 =
         "{1:F21VTCBVNVXAXXX3111595656}{4:{177:1907021215}{451:0}}{1:F01VTCBVNVXAXXX3111595656}{2:O1030114190703SCBLDEFXAXXX30149735370311202016N}{3:{108:1907020123758-03}{111:001}{121:b8f3cfe5-c240-4bc5-b6a3-72ea81c0e440}}{4:\n" +
                 ":20:DG6A/10341120-16\n" +
                 ":23B:CRED\n" +
                 ":32A:201029EUR10770,00\n" +
                 ":33B:USD10800,00\n" +
                 ":50F:SA5655000000080400500192\n" +
                 "1/SULAIMAN A.RAHMAN IBRAHIM\n" +
                 "2/ALSHAYEEs\n" +
                 "3/P.O BOX 430 RIYADH AL-KABRA\n" +
                 "4/SA/SAUDI ARABIA 51961\n" +
                 ":52A:SICOTHBK\n" +
                 ":54A:HYVEDEMMXXX\n" +
                 ":59F:/19120710177011\n" +
                 "ROYAL TEA CN CAU GIAY\n" +
                 "BINH TAN WARD PHU RIENG DIST. BINH\n" +
                 "PHUOC PROV. S.R. VIETNAM\n" +
                 ":70:FOR GOODS AS PER NO. 97/NC/19\n" +
                 ":71A:OUR\n" +
                 ":71F:USD3,00\n" +
                 ":72:/ACC/YR BINH PHUOC BR.\n" +
                 "-}{5:{MAC:00000000}{CHK:C806DFB5E16B}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(finMT103, "test.txt");
    }
    @Test
    public void test() throws Exception {
        System.out.println("sender="+ swiftMT.getSender());
        Assert.assertEquals(swiftMT.getType(), "103");
        Assert.assertTrue("Amount is greater than 0", swiftMT.getAmount().compareTo(new BigDecimal(0)) > 0);
        System.out.println(swiftMT.getReadableJson());
    }

    @Test
    public void testValueDateIn2019() throws ParseException {
        Assert.assertTrue("Value date in 2919", swiftMT.getValue_date().after(new SimpleDateFormat("yyyy-MM-dd").parse("2019-01-01")) && swiftMT.getValue_date().before(new SimpleDateFormat("yyyy-MM-dd").parse("2020-01-01")));
    }
    @Test
    public void test71F() throws ParseException, ParserException {
        SwiftMT swiftMT2 = new SwiftMT("{1:F21VTCBVNVXAXXX3227952105}{4:{177:2005131001}{451:0}}{1:F01VTCBVNVXAXXX3227952105}{2:O1039999999999SCBLUS33AXXX99999999952105231002N}{3:{119:STP}{111:001}{121:89ddd22d-fa66-4343-bb57-c47194696e5b}}{4:\n" +
                ":20:T9601000T3011B00\n" +
                ":23B:CRED\n" +
                ":32A:200513USD760,00\n" +
                ":33B:USD3000000,\n" +
                ":36:12,4\n" +
                ":50K:1/HERITAGE GROWER CORPORATION\n" +
                "1/LIMITED\n" +
                "2/95/10 MOO 8,TAMBOL NAKA,\n" +
                "3/TH/RANONG 85120 THAILAND\n" +
                ":52A:COBADEHHXXX\n" +
                "ABC123\n" +
                ":59F:/19199889988030\n" +
                "1/KHACH HANG 99998888\n" +
                "1/KHACH HANG 99998888 123\n" +
                "2/715 KINH DUONG VUONG STREET, AN\n" +
                "2/LAC WARD\n" +
                "3/VN/715 KINH DUONG VUONG STREET,\n" +
                ":70: ABC CREDIT ABC\n" +
                ":71A:OUR\n" +
                ":71F:EUR12,00\n" +
                ":71F:EUR2,34\n" +
                ":72:ATTN LC DEPT,\n" +
                ".\n" +
                "PLS CREDIT OUR ACC.36053008 WITH CITIUS33 IN\n" +
                "PAYMENT OF OUR ADVISING FEES FOR USD 135.00 AND\n" +
                "CABLE FEES FOR USD 25.00\n" +
                ".\n" +
                "REGARDS,\n" +
                "-}{5:{MAC:00000000}{CHK:193937E9D67D}}{S:{SAC:}{COP:P}}", "test.txt");
        System.out.println("71f=" + swiftMT2.getF71f());
        System.out.println("121=" + swiftMT2.getF121());
        System.out.println("72=" + swiftMT2.getF72());
        System.out.println("json=" + swiftMT2.getReadableJson());
    }
    @Test
    public void testReadable() throws Exception {
        SwiftMT swiftMT2 = new SwiftMT("{1:F21VTCBVNVXAXXX3227952105}{4:{177:2005131001}{451:0}}{1:F01VTCBVNVXAXXX3227952105}{2:O1039999999999SCBLUS33AXXX99999999997115231002N}{3:{119:STP}{111:001}{121:89ddd22d-fa66-4343-bb57-c47194696e5b}}{4:\n" +
                ":20:T9921000T3021B22\n" +
                ":23B:CRED\n" +
                ":32A:200513USD760,20\n" +
                ":33B:USD3000000,00\n" +
                ":36:12,4\n" +
                ":50K:1/HERITAGE GROWER CORPORATION\n" +
                "1/LIMITED\n" +
                "2/95/10 MOO 8,TAMBOL NAKA,\n" +
                "3/TH/RANONG 85120 THAILAND\n" +
                ":52A:COBADEHHXXX\n" +
                "ABC123\n" +
                ":59F:/1059998888023\n" +
                "1/KHACH HANG 99998889\n" +
                "1/KHACH HANG 99998888 123\n" +
                "2/715 KINH DUONG VUONG STREET, AN\n" +
                "2/LAC WARD\n" +
                "3/VN/715 KINH DUONG VUONG STREET,\n" +
                ":70: ABC CREDIT ABC\n" +
                ":71A:OUR\n" +
                ":71F:EUR12,00\n" +
                ":71F:EUR2,34\n" +
                ":72:ATTN LC DEPT,\n" +
                ".\n" +
                "PLS CREDIT OUR ACC.36053008 WITH CITIUS33 IN\n" +
                "PAYMENT OF OUR ADVISING FEES FOR USD 135.00 AND\n" +
                "CABLE FEES FOR USD 25.00\n" +
                ".\n" +
                "REGARDS,\n" +
                "-}{5:{MAC:00000000}{CHK:193937E9D67D}}{S:{SAC:}{COP:P}}", "test.txt");
        System.out.println("json=" + swiftMT2.getReadable());
    }

}
