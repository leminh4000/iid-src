package vn.techcombank.rem;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.regex.Pattern;

public class MT202covTest {
    String fin;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        fin =
                "{1:F21VTCBVNVXAXXX3142667623}{4:{177:1909021231}{451:0}}{1:F01VTCBVNVXAXXX3142667623}{2:O2021732191912HYVEDEMMAXXX79315102201909021231N}{3:{108:PTS102437936}{119:COV}{111:001}{121:eeef94c7-d0fc-413f-9721-5f3f0507a7a1}}{4:\n" +
                        ":20:AZNA34204418721\n" +
                        ":21:AZNA24204408700\n" +
                        ":32A:190902EUR500,00\n" +
                        ":52A:COBADEFF\n" +
                        ":58A:VTCBVNVX\n" +
                        ":50F:/DE95200411110357431600\n" +
                        "1/DIETER WERTH\n" +
                        "2/SCHULSTRASSE 82A\n" +
                        "3/DE/08352 RASCHAU\n" +
                        ":52A:COBADEHH\n" +
                        ":59:/19026900741014\n" +
                        "VUONG THI MY HUYEN\n" +
                        "1\n" +
                        "VT\n" +
                        ":70:PRIVAT\n" +
                        ":72:LORREM IPSUM IS SIMPLE DUMMY TEXT AUTOMATIC OVERNIGHT SWEEP SIMPLE DUMMY TEX\n" +
                        "-}{5:{MAC:00000000}{CHK:1EA53928CC92}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(fin, "test.txt");
    }
    @Test
    public void testGetReadable() throws Exception {
        String readable = swiftMT.getReadable();
        System.out.println(readable);
        Assert.assertTrue("Readable not contains number", !readable.contains("Number 1"));
    }
    @Test
    public void testMatchPattern() throws Exception {
        Assert.assertTrue(Pattern.matches("Number [0-9][0-9]?", "Number 1"));
        Assert.assertTrue(Pattern.matches("Number [0-9][0-9]?", "Number 11"));
        Assert.assertFalse(Pattern.matches("Number [0-9][0-9]?", "11Number"));
        Assert.assertFalse(Pattern.matches("Number [0-9][0-9]?", "Number 111"));
    }
}
