package vn.techcombank.rem;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class ReadableTest {
    String fin;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        fin = "{1:F21VTCBVNVXAXXX3199873534}{4:{177:2003040704}{451:0}}{1:F01VTCBVNVXAXXX3199873534}{2:O1030909279347BOTKJPJTDXXX22724714312003040704N}{3:{111:001}{121:132ce6d6-acdd-43fe-abb0-c47ca208cb9f}}{4:\n" +
                ":20:347.22109301\n" +
                ":21:2100219946\n" +
                ":23B:CRED\n" +
                ":32A:200327USD200,00\n" +
                ":33B:USD200,00\n" +
                ":50K:/404-1429927\n" +
                "SETJAPANCORPORATION\n" +
                "6-2-3,NISHIMACHI,TOYOTA,AICHI\n" +
                "471-0025 JAPAN\n" +
                ":52A:BOTKJPJTXXX\n" +
                ":53A:CITIUS33XXX\n" +
                ":59F:/19133187380015\n" +
                "1/CUT LON XAO ME SERVICES\n" +
                "2/DUONG PHAN BA VANH - KHU DO THI 3\n" +
                "3/VN/PHUONG QUANG TRUNG - THAI BINH\n" +
                ":71A:SHA\n" +
                ":71F:USD10,00\n" +
                ":72:\n" +
                "/ACC/PURPOSE:OUTSOURCING\n" +
                "//DEVELOPMENT(WEBSITE)\n" +
                "-}{5:{MAC:00000000}{CHK:2C4341EE9038}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(fin, "test.txt");
    }
    @Test
    public void testReadable() throws Exception {

        String readable = swiftMT.getReadable();
        System.out.println(readable);
        Assert.assertTrue("Readable have Sender string", readable.contains("Sender"));
    }

    @Test
    public void testReadableJson() {

        String readable = swiftMT.getReadableJson();
        System.out.println(readable);
    }
}
