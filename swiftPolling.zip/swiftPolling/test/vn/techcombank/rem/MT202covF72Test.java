package vn.techcombank.rem;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.util.regex.Pattern;

public class MT202covF72Test {
    String fin;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        fin =
                "{1:F21VTCBVNVXAXXX3210904164}{4:{177:2003271659}{451:0}}{1:F01VTCBVNVXAXXX3210904164}{2:O2021008282325CITIUS33DXXX76028021242003271659N}{3:{108:0027032020ZV4471}{119:COV}{121:c9b5eb51-9560-44c1-9875-7a2f02294a3d}}{4:\n" +
                        ":20:05.10828\n" +
                        ":21:2020.14.28.8TEST\n" +
                        ":32A:200326USD20000,39\n" +
                        ":52A:REVOGB21XXX\n" +
                        ":58A:VTCBVNVXXXX\n" +
                        ":72:/INS/ABNANL2AXXX\n" +
                        ":50F:/GB88REVO00997074679374\n" +
                        "1/TRONG HIEU NGUYEN\n" +
                        "2/09 AVENUE SAINT-EXUPERY\n" +
                        "3/FR/ANTONY 92160\n" +
                        ":52A:REVOGB21XXX\n" +
                        ":59F://19134054291032\n" +
                        "1/QPHUONG\n" +
                        "2/25T2,TRAN DUY HUNG TRUNG HOA,\n" +
                        "3/CAU GIAY HANOI,VIET NAM\n" +
                        ":72:05A.10309\n" +
                        "/INS/REVOGB2LXXX\n" +
                        "/INS/BARCDEFF\n" +
                        ":33B:EUR5,00\n" +
                        "-}{5:{MAC:00000000}{CHK:ED7F466E2A97}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(fin, "test.txt");
    }
    @Test
    public void testGetF72() throws Exception {
        String f72 = swiftMT.getF72();
        Assert.assertTrue("Value for F72", f72.contains("\n"));
    }

    @Test
    public void testGetReadableJson() throws Exception {
        String json = swiftMT.getReadableJson();
        JsonObject jsonObject= new JsonParser().parse(json).getAsJsonObject();
        Assert.assertTrue("F72 is multiple", jsonObject.get("field72").isJsonArray());
    }
}
