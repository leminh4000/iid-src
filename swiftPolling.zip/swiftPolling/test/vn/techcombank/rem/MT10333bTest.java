package vn.techcombank.rem;

import org.json.JSONObject;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class MT10333bTest {
    String finMT103;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        finMT103 =
         "{1:F21VTCBVNVXAXXX3227952105}{4:{177:2005131001}{451:0}}{1:F01VTCBVNVXAXXX3227952105}{2:O1036523221623PNBPUS3NANYC36153127742005131001N}{3:{119:STP}{111:001}{121:89ddd22d-fa66-4343-bb57-c47194696e5b}}{4:\n" +
                 ":20:T4000000006\n" +
                 ":23B:CRED\n" +
                 ":32A:200513USD3000000\n" +
                 ":33B:USD3000001,49\n" +
                 ":50K:1/HERITAGE GROWER CORPORATION\n" +
                 "1/LIMITED\n" +
                 "2/95/10 MOO 8,TAMBOL NAKA,\n" +
                 "3/TH/RANONG 85120 THAILAND\n" +
                 ":52A::53A:CITIUS33DXXX\n" +
                 "CITIBANK JAPAN LTD.\n" +
                 "TOKYO JP\n" +
                 ":59F:/19120875599042\n" +
                 "1/ANH KHACH HANG 88888888\n" +
                 "2/HANOI/VIETNAM\n" +
                 ":70:NR.001/13.4.2020\n" +
                 ":71A:SHA\n" +
                 ":71F:TEST TEST TEST\n" +
                 ":72:ATTN LC DEPT,\n" +
                 ".\n" +
                 "PLS CREDIT OUR ACC.36053008 WITH CITIUS33 IN\n" +
                 "PAYMENT OF OUR ADVISING FEES FOR USD 135.00 AND\n" +
                 "CABLE FEES FOR USD 25.00\n" +
                 ".\n" +
                 "REGARDS,\n" +
                 "-}{5:{MAC:00000000}{CHK:193937E9D67D}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(finMT103, "test.txt");
    }
    @Test
    public void test33b() {
        Assert.assertEquals(swiftMT.getType(), "103");
        JSONObject jsonObject = new JSONObject(swiftMT.getReadableJson());
        String field33bAmount = (String) jsonObject.get("field33bAmount");
        Assert.assertTrue("33b Amount is greater than 0", !"0".equals(field33bAmount));
    }

}
