package vn.techcombank.rem;

import org.junit.Before;
import org.junit.Test;

public class MT202CovReadableTest {
    String finMT103;
    private SwiftMT swiftMT;

    @Before
    public void setup() throws Exception {
        finMT103 =
         "{1:F21VTCBVNVXAXXX3227952403}{4:{177:2005131247}{451:0}}{1:F01VTCBVNVXAXXX3227952403}{2:O2020169696523HYVEDEMMCXXX60372095212005131247N}{3:{108:PTS105647580}{119:COV}{111:001}{121:9af15dc7-b650-4d8d-bda1-6a67b620f353}}{4:\n" +
                 ":20:CHIFANLAT_6969\n" +
                 ":21:546A013200467100\n" +
                 ":32A:200513EUR1330,00\n" +
                 ":52A:COBADEFF\n" +
                 ":58A:VTCBVNVX\n" +
                 ":50F:/DE56700400410226118800\n" +
                 "1/GOETHE-INSTITUT E.V.\n" +
                 "2/OSKAR-VON-MILLER-RING 18\n" +
                 "3/DE/80333 MUENCHEN\n" +
                 ":52A:COBADEHH\n" +
                 ":59:/1152196\n" +
                 "NGUYEN NGOC \n" +
                 "UNIT 1604, CT2A BUILDING\n" +
                 ":70:NR.II/2018/401-522/10.4.2020\n" +
                 ":72:GIAO DICH TEST\n" +
                 "AUTOMATIC OVERNIGHT SWEEP\n" +
                 "KH\n" +
                 "-}{5:{MAC:00000000}{CHK:754D9BA317E0}}{S:{SAC:}{COP:P}}";
        swiftMT = new SwiftMT(finMT103, "test.txt");
    }
    @Test
    public void testReadable() throws Exception {
        System.out.println(swiftMT.getReadable());
    }

}
