package vn.techcombank.rem;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import java.math.BigDecimal;
import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;

public class MT103Test {
    String finMT103;
    private SwiftHelper swiftHelper;

    @Before
    public void setup() throws Exception {
        finMT103 =
         "{1:F21VTCBVNVXAXXX3113599379}{4:{177:1907041840}{451:0}}{1:F01VTCBVNVXAXXX3113599379}{2:O1030739190705CITIUS33HXXX21782618781907041840N}{3:{108:197040211220UV01}{111:001}{121:11ce5026-1a59-4677-85a0-80a9d43c8d5a}}{4:\n"
         +
         ":20:S0691860369303\n" +
         ":23B:CRED\n" +
         ":32A:190705USD740,5\n" +
         ":33B:USD748,\n" +
         ":50K:/USD2000018836601\n" +
         "ZHANG SHI TAI\n" +
         "KANGPING RD 95,SHANGHAI,CHINA\n" +
         ":52A:BOSHCNSHXXX\n" +
         ":59:/S? T?I KHO?N\n" +
         "TEN KH\n" +
         "15B3 LA ASTORIA APARTMENT - 383\n" +
         "NGUYEN DUY TRINH, HO CHI MIN\n" +
         ":70:POKER 4\n" +
         ":71A:SHA\n" +
         ":71F:USD7,50\n" +
         "-}{5:{MAC:00000000}{CHK:940A23C476F5}}{S:{SAC:}{COP:P}}[ibminstall@dr-odm-dev swift]$\n"
         +
         "[ibminstall@dr-odm-dev swift]$\n" +
         "[ibminstall@dr-odm-dev swift]$\n" +
         "[ibminstall@dr-odm-dev swift]$ cat 00229552\\ \\(2\\).out_1\n" +
         "{1:F21VTCBVNVXAXXX3142667442}{4:{177:1909011139}{451:0}}{1:F01VTCBVNVXAXXX3142667442}{2:O1030005190901BNPAUS3NBXXX13381547491909011139N}{3:{111:001}{121:f746c348-4b63-4cf4-b711-c7bb4284f812}}{4:\n"
         +
         ":20:PAY190829C016875\n" +
         ":23B:CRED\n" +
         ":32A:190903USD429,00\n" +
         ":33B:USD429,00\n" +
         ":50K:/DE57701204008480696007\n" +
         "SPERONI CHRISTOPHE\n" +
         "PETER-STRASSER-WEG 4\n" +
         "12101 BERLIN\n" +
         "BUNDESREP. DEUTSCHLAND\n" +
         ":52D:/SW-CSDBDE71\n" +
         "BNP PARIBAS S.A. NIEDERLASSUNG DEUT\n" +
         "SCHLAND\n" +
         "NUERNBERG\n" +
         "GERMANY\n" +
         ":54A:SCBLUS33\n" +
         ":59:/19112345\n" +
         "VU THI THAO\n" +
         ":70:CUSTOMER ID: 152\n" +
         "ORDER DATE: 08/28/2018\n" +
         "CHRISTOPHE SPERONI\n" +
         ":71A:OUR\n" +
         "-}{5:{MAC:00000000}{CHK:938391DED33A}}{S:{SAC:}{COP:P}}";
        swiftHelper = new SwiftHelper(finMT103, "test.txt");
    }
    @Test
    public void test() {
        Assert.assertEquals(swiftHelper.getType(), "103");
        Assert.assertTrue("Amount is greater than 0", swiftHelper.getAmount().compareTo(new BigDecimal(0)) > 0);
    }

    @Test
    public void testValueDateIn2019() throws ParseException {
        Assert.assertTrue("Value date in 2919", swiftHelper.getValue_date().after(new SimpleDateFormat("yyyy-MM-dd").parse("2019-01-01")) && swiftHelper.getValue_date().before(new SimpleDateFormat("yyyy-MM-dd").parse("2020-01-01")));
    }
}
