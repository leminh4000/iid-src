package vn.techcombank.rem;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
        SwiftHelperTest.class,
        MT940Test.class,
        MT518Test.class,
        MT103Test.class
})

public class AllTests {
}
