package vn.techcombank.rem;


import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class SwiftHelperTest {
    String fin;
    private SwiftHelper swiftHelper;

    @Before
    public void setup() throws Exception {
        fin = "{1:F21VTCBVNVXAXXX3227951980}{4:{177:2005130829}{451:0}}{1:F01VTCBVNVXAXXX3227951980}{2:O5180829200513ASCBVNVXAXXX77617537382005130829N}{4:\n" +
                ":16R:GENL\n" +
                ":20C::SEME//KNQ5608-20\n" +
                ":23G:NEWM\n" +
                ":22F::TRTR//TRAD\n" +
                ":16S:GENL\n" +
                ":16R:CONFDET\n" +
                ":98A::TRAD//20200512\n" +
                ":98A::SETT//20200514\n" +
                ":90B::DEAL//ACTU/VND128422,\n" +
                ":19A::SETT//VND65113500000,\n" +
                ":22H::BUSE//SELL\n" +
                ":22H::PAYM//FREE\n" +
                ":16R:CONFPRTY\n" +
                ":95P::BUYR//VTCBVNVXXXX\n" +
                ":16S:CONFPRTY\n" +
                ":36B::CONF//UNIT/500000,\n" +
                ":35B:ISIN VNTD19392008\n" +
                ":16S:CONFDET\n" +
                "-}{5:{MAC:00000000}{CHK:7B1E0DD7D855}}{S:{SAC:}{COP:P}}";
        swiftHelper = new SwiftHelper(fin, "test.txt");
    }
    @Test
    public void test() {
        Assert.assertNotNull(swiftHelper.getType());
    }

    @Test
    public void testReadable() {
        Assert.assertTrue("Readable have Sender string", swiftHelper.getReadable().contains("Sender"));
    }

}
