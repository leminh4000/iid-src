package vn.techcombank.rem;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import com.prowidesoftware.swift.model.SwiftBlock4;
import com.prowidesoftware.swift.model.SwiftMessage;
import com.prowidesoftware.swift.model.Tag;
import com.prowidesoftware.swift.model.field.*;
import com.prowidesoftware.swift.model.mt.mt5xx.MT518;
import org.apache.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;

public class SwiftMT {

    final static Logger logger = Logger.getLogger(SwiftMT.class);
    private static Properties prop;


    static {
        InputStream is;
        try {
            prop = new Properties();
            is = new FileInputStream("SwiftMapFields.properties");
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static final String SHARP_SYMBOL = "#";
    private static final String DATE_FORMAT_DISPLAY = "yyyy/MM/dd";
    private static final String DATE_FORMAT_BY_LOCALE = "MMM dd,yyyy";
    private final String SWIFT_DATE_FORMAT = "yyMMdd";
    private static final String[] MULTI_VALUE_FIELD_LIST = {"86", "61", "72"};
    Map<String, String[]> SINGLE_VALUE_TYPE_FIELD_MAP = Stream.of(new String[][]{
            {"518", "23G"}
    }).collect(Collectors.collectingAndThen(
            Collectors.toMap(data -> data[0], data -> data),
            Collections::<String, String[]>unmodifiableMap));

    String fin;
    com.prowidesoftware.swift.model.SwiftMessage sm;
    private String f20;
    private String f21;
    private String f52d;
    private String f57a;
    private String f57d;
    private String f72;
    private String f72s;
    private String f70;
    private String f79;
    private String f53a;
    private String f54a;
    private String sender;
    private String receiver;
    private String type;
    private String currency;
    private Date value_date;
    private BigDecimal amount;
    private String fileName;
    private String swiftId;
    private static final Locale DISPLAY_LOCALE = new Locale("en", "EN");// Locale.getDefault();
    private static final Locale SWIFT_NUMBER_LOCALE = Locale.FRANCE;
    private static DecimalFormat df;

    static {
        df = (DecimalFormat) NumberFormat.getInstance(SWIFT_NUMBER_LOCALE);
        df.setParseBigDecimal(true);
    }

    private JSONArray f61jsonArray2;

    public SwiftMT(String fin, String fileName) throws Exception {
        super();
        this.fin = fin;
        this.fileName = fileName;
        this.sm = com.prowidesoftware.swift.model.SwiftMessage.parse(fin);
        if (sm.isAck() || sm.isNack()) {
            sm = SwiftMessage.parse(sm.getUnparsedTexts().getAsFINString());
        }
        if (sm.getBlock2() == null || sm.getBlock2() == null)
            throw new Exception("Can not parse Swift message");
        f20 = Optional.ofNullable(sm.getBlock4().getFieldByName("20"))
                .map(o -> o.getValueDisplay()).orElse("");
        f21 = Optional.ofNullable(sm.getBlock4().getFieldByName("21"))
                .map(o -> o.getValueDisplay()).orElse("");
        f52d = Optional.ofNullable(sm.getBlock4().getFieldByName("52D"))
                .map(o -> o.getValueDisplay()).orElse("");
        f57a = Optional.ofNullable(sm.getBlock4().getFieldByName("57A"))
                .map(o -> o.getValueDisplay()).orElse("");
        f57d = Optional.ofNullable(sm.getBlock4().getFieldByName("57D"))
                .map(o -> o.getValueDisplay()).orElse("");
        f72 = getValueDisplay(sm.getBlock4().getFieldsByName("72"));
        f72s = "";
        for (char alphabet = 'A'; alphabet <= 'Z'; alphabet++) {
            Field f72x = sm.getBlock4().getFieldByName("72" + alphabet);
            if (f72x != null) {
                f72s += f72x.getValueDisplay();
            }
        }
        f72s += f72;
        f70 = Optional.ofNullable(sm.getBlock4().getFieldByName("70"))
                .map(o -> o.getValueDisplay()).orElse("");
        f79 = Optional.ofNullable(sm.getBlock4().getFieldByName("79"))
                .map(o -> o.getValueDisplay()).orElse("");
        f53a = Optional.ofNullable(sm.getBlock4().getFieldByName("53A"))
                .map(o -> o.getValueDisplay()).orElse("");
        f54a = Optional.ofNullable(sm.getBlock4().getFieldByName("54A"))
                .map(o -> o.getValueDisplay()).orElse("");
        sender = (sm.getSender().length() >= 8 ? sm.getSender().substring(0, 8) : sm.getSender()) + (sm.getSender().length() > 8 ? sm.getSender().substring(9) : "");
        receiver = (sm.getReceiver().length() >= 8 ? sm.getReceiver().substring(0, 8) : sm.getReceiver()) + (sm.getReceiver().length() > 8 ? sm.getReceiver().substring(9) : "");
        type = sm.getType();
        if ("202".equals(type)) {
            if (sm.getBlock3() != null && sm.getBlock3().getFieldByName("119") != null && "COV".equals(sm.getBlock3().getFieldByName("119").getValue()))
                type = "202cov";
        }

        Field f32A = sm.getBlock4().getFieldByName("32A");
        if (this.type.equals("940") || this.type.equals("950")) {
            Field f60M = sm.getBlock4().getFieldByName("60M");
            Field f60F = sm.getBlock4().getFieldByName("60F");
            this.currency = (f60M == null ? "" : f60M.getComponent(
                    Field60M.CURRENCY)) + (f60F == null ? "" : f60F.getComponent(
                    Field60F.CURRENCY));
        } else
            this.currency = f32A == null ? null : f32A.getComponent(
                    Field32A.CURRENCY);
        logger.info("currency = " + this.currency);
        try {
            this.value_date = f32A == null ? null : new SimpleDateFormat(
                    SWIFT_DATE_FORMAT).parse(f32A.getComponent(
                    Field32A.DATE));
            logger.info("value_date=" + value_date);
        } catch (ParseException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
            logger.error(e.getMessage());
        }
        if (this.type.equals("940") || this.type.equals("950")) {
            Field f60M = sm.getBlock4().getFieldByName("60M");
            Field f60F = sm.getBlock4().getFieldByName("60F");
            this.amount = (BigDecimal) df.parseObject((f60M == null ? "" : f60M.getComponent(
                    Field60M.AMOUNT)) + (f60F == null ? "" : f60F.getComponent(
                    Field60F.AMOUNT)));
        } else
            this.amount = f32A == null ? null : (BigDecimal) df.parseObject(f32A.getComponent(Field32A.AMOUNT));
        logger.info("amount=" + amount);
        this.swiftId = sm.getBlock2().getBlockValue();
        System.out.println("swiftId=" + this.swiftId);
    }

    private String getValueDisplay(Field[] fields) {
        String result = "";
        if (fields == null || fields.length == 0) return "";
        for (Field field : fields) {
            result += field.getValueDisplay() + "\n";
        }
        return result;
    }

    public String getJson() {
        return sm.toJson();
    }

    public String getCurrency() {
        return currency;
    }

    public static void main(String[] args) throws Exception {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("test", LocalDateTime.now());
        String fin =
                "{1:F21VTCBVNVXAXXX3227952132}{4:{177:2005131027}{451:0}}{1:F01VTCBVNVXAXXX3227952132}{2:O9102826900512CITIUS331XXX21931495432005131027N}{3:{108:209555449RSC3}}{4:\n" +
                        ":20:F60512062101662\n" +
                        ":21:FT1924234273253\n" +
                        ":25:2000191004023\n" +
                        ":13D:2005122326-0400\n" +
                        ":32A:200513CAD6\n" +
                        ":52D:/8900708905\n" +
                        "BQIDBQAQA\n" +
                        ":58A:/8900708905\n" +
                        "QIDBQAQAXXX\n" +
                        ":72:FVT COMMERCIAL  \n" +
                        "//CHARGE REQUEST DATED 190909\n" +
                        "//REFERENCE FT19242342373253\n" +
                        "/INS/UNMAPPED GLS ACCOUNT\n" +
                        "-}{5:{CHK:556437513E1B}}{S:{COP:P}}";
        SwiftMT helper;
        helper = new SwiftMT(fin, "test.txt");
        System.out.println(helper.getReadable());
        System.out.println(helper.getReadableJson());
    }

    public String getReadableJson() {
        SwiftBlock4 block4 = sm.getBlock4();
        if (block4 == null) return "";
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("swiftCodeNo", sender);
        jsonObject.put("type", this.type);
        jsonObject.put("receiver", receiver);

        Map<String, JSONArray> mapFieldNameValues = new HashMap<>();
        for (Tag tag : block4.getTags()) {
            Field field = tag.asField();
            String fieldName = field.getName();
            boolean isMultiValue = (Arrays.asList(MULTI_VALUE_FIELD_LIST).contains(fieldName)) || checkMultiValue(this.type, tag.getName());
            if (isMultiValue) {
                if (mapFieldNameValues.get(fieldName) == null) {
                    JSONArray jsonArray1 = new JSONArray();
                    mapFieldNameValues.put(fieldName, jsonArray1);
                }
                JSONArray jsonArray = mapFieldNameValues.get(fieldName);
                JSONObject jsonObject1 = new JSONObject();
                jsonObject1.put("field" + fieldName, field.getValue());
                for (int component = 1; component <= field.componentsSize(); component++) {
                    if (field.getComponent(component) != null) {

                        jsonObject1.put(
                                "field"
                                        + fieldName.toLowerCase()
                                        + field.getComponentLabel(component)
                                        .replaceAll("[^a-zA-Z0-9]", ""),
                                field.getComponent(component));
                    }
                }
                jsonArray.put(jsonObject1);
            } else {
                jsonObject.put("field" + fieldName.toLowerCase(),
                        field.getValue());
                if (field.componentsSize() > 1) {
                    for (int component = 1; component <= field.componentsSize(); component++) {
                        if (field.getComponent(component) != null) {

                            jsonObject.put("field"
                                            + fieldName.toLowerCase()
                                            + field.getComponentLabel(component)
                                            .replaceAll("[^a-zA-Z0-9]", ""),
                                    field.getComponent(component));
                        }
                    }
                }
            }
        }
        mapFieldNameValues.entrySet().forEach(stringJSONArrayEntry -> {
            jsonObject.put("field" + stringJSONArrayEntry.getKey(), stringJSONArrayEntry.getValue());
        });
        return jsonObject.toString();
    }

    private boolean checkMultiValue(String type, String name) {
        String[] singleFields = SINGLE_VALUE_TYPE_FIELD_MAP.get(type);
        if (singleFields == null) return false;
        for (String singleField : singleFields) {
            if (singleField.equals(name)) return false;
        }
        return true;
    }

    public String getReadable() throws Exception {

        StringBuilder stringBuilder = new StringBuilder("");

        stringBuilder
                .append("-------------------- Instance Type and Transmission ----------------\n");
        stringBuilder.append("Copy received from SWIFT\n");
        if (sm.getBlock2() != null) {
            String messagePriorityType = Optional
                    .ofNullable(sm.getBlock2().getMessagePriorityType())
                    .map(o -> o.toString()).orElse(null);
            String messagePriority = "";
            if ("S".equals(messagePriorityType))
                messagePriority = "System";
            else if ("U".equals(messagePriorityType))
                messagePriority = "Urgent";
            else if ("N".equals(messagePriorityType))
                messagePriority = "Normal";
            stringBuilder.append("Priority : ").append(messagePriority)
                    .append("\n");
            String outRef = "";
            String inRef = "";
            JSONObject block2Object = new JSONObject(sm.getBlock2()
                    .toJson());
            JSONObject block1Object = new JSONObject(sm.getBlock1()
                    .toJson());
            outRef = new StringBuilder(
                    block2Object.get("receiverOutputTime") == null ? ""
                            : (String) block2Object
                            .get("receiverOutputTime"))
                    .append(" ")
                    .append(block2Object.get("MIRDate") == null ? ""
                            : (String) block2Object.get("MIRDate"))
                    .append(receiver)
                    .append(block1Object.get("sessionNumber") == null ? ""
                            : (String) block1Object.get("sessionNumber"))
                    .append(block1Object.get("sequenceNumber") == null ? ""
                            : (String) block1Object.get("sequenceNumber"))
                    .toString();
            inRef = new StringBuilder(
                    block2Object.get("senderInputTime") == null ? ""
                            : (String) block2Object.get("senderInputTime"))
                    .append(" ")
                    .append(block2Object.get("MIRDate") == null ? ""
                            : (String) block2Object.get("MIRDate"))
                    .append(block2Object.get("MIRLogicalTerminal") == null ? ""
                            : (String) block2Object
                            .get("MIRLogicalTerminal"))
                    .append(block2Object.get("MIRSessionNumber") == null ? ""
                            : (String) block2Object.get("MIRSessionNumber"))
                    .append(block2Object.get("MIRSequenceNumber") == null ? ""
                            : (String) block2Object
                            .get("MIRSequenceNumber")).toString();

            stringBuilder.append("Message Output Reference : " + outRef + "\n");
            stringBuilder.append("Correspondent Input Reference : " + inRef
                    + "\n");
        }

        stringBuilder
                .append("--------------------------- Message Header -------------------------\n");
        stringBuilder.append("Swift Output : ");
        stringBuilder.append(prop.getProperty(this.getType()) + "\n");
        stringBuilder.append("Sender\t: " + sender + "\n");
        stringBuilder.append("\t\t  #SENDER\n");
        stringBuilder.append("Receiver\t: " + receiver + "\n");
        stringBuilder.append("\t\t  #RECEIVER\n");
        stringBuilder.append("MUR : " + sm.getMUR() + "\n");

        stringBuilder
                .append("--------------------------- Message Text -------------------------\n");
        for (Tag tag : Optional.ofNullable(sm.getBlock4())
                .map(o -> o.getTags()).orElse(new ArrayList<Tag>())) {
            Field field = tag.asField();
            /*if (field == null ) {
                throw new Exception("Field " + tag.getName() + " not found");
            }*/
            String fieldLabel = Optional.ofNullable(field).map(o -> Field.getLabel(field.getName(), sm.getType(),
                    null, DISPLAY_LOCALE)).orElse("");
            if (fieldLabel.contains(".name")) fieldLabel = "";
            stringBuilder.append(Optional.ofNullable(field).map(o -> field.getName()).orElse(tag.getName()) + ":\t" + fieldLabel
                    + "\n");
            if (field == null) {
                stringBuilder.append("\t" + tag.getValue().replace("\n", "\n\t") + "\n");
            } else if (isMultiline(field)) {
                stringBuilder.append("\t" + field.getValue().replace("\n", "\n\t") + "\n");
            } else
                for (int component = 1; component <= field.componentsSize(); component++) {
                    try{
                    if (field.getComponent(component) != null) {
                        String valueDisplay = field.getValueDisplay(component,
                                DISPLAY_LOCALE);
                        String componentLabel = field
                                .getComponentLabel(component);
                        valueDisplay = getValueDisplay(valueDisplay,
                                componentLabel);
                        if (!readableException(componentLabel))
                            stringBuilder.append("\t" + (field.componentsSize() == 1 ? "" : componentLabel + ": ")
                                    + valueDisplay + "\n");
                    }} catch (Exception e){
                        logger.info("Error at field : " + tag.getName());
                        throw e;
                    }
                }
        }

        stringBuilder
                .append("--------------------------- Message Trailer -------------------------\n");
        for (Tag tag : Optional.ofNullable(sm.getBlock5())
                .map(o -> o.getTags()).orElse(new ArrayList<>())) {
            stringBuilder.append("{" + tag.getName() + ":" + tag.getValue()
                    + "}");
        }
        return stringBuilder.toString();
    }

    private boolean readableException(String componentLabel) {
        if (componentLabel == null) return false;
        return Pattern.matches("Number [0-9][0-9]?", componentLabel);
    }

    private boolean isMultiline(Field field) {
        String componentLabel = "";
        for (int component = 1; component <= field.componentsSize(); component++) {
            if (field.getComponent(component) != null) {
                /*String valueDisplay = field.getValueDisplay(component,
                        DISPLAY_LOCALE);

                if (componentLabel.length() > 0 && (componentLabel + " 2").equals(field
                        .getComponentLabel(component))) return true;
                componentLabel = field
                        .getComponentLabel(component);*/
                if (field.getComponentLabel(component).matches(".*\\d.*"))
                    return true;

            }
        }
        return false;
    }

    private String getValueDisplay(String valueDisplay, String componentLabel) throws ParseException {
        if ("Date".equals(componentLabel)) {
            Date date;
                date = new SimpleDateFormat(DATE_FORMAT_BY_LOCALE)
                        .parse(valueDisplay);
                valueDisplay = new SimpleDateFormat(DATE_FORMAT_DISPLAY)
                        .format(date);
        }

        if ("Amount".equals(componentLabel)) {
            valueDisplay = SHARP_SYMBOL + valueDisplay + SHARP_SYMBOL;
        }
        return valueDisplay;
    }

    public static String getType(String fin) {
        int typeInd = fin.indexOf("{2:") + 4;
        String result;
        try {
            result = fin.substring(typeInd, typeInd + 3);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            return "";
        }
        return result;
    }

    public static String getF20(String fin) {
        int f20Ind = fin.indexOf("20:") + 3;
        String result;
        try {
            result = fin.substring(f20Ind, fin.indexOf(":", f20Ind));
        } catch (Exception e) {
            // TODO Auto-generated catch block
            return "";
        }
        return result;
    }

    public static String getId(String fin) {
        return "1";
    }

    public String getFin() {
        return fin;
    }

    public void setFin(String fin) {
        this.fin = fin;
    }

    public com.prowidesoftware.swift.model.SwiftMessage getSm() {
        return sm;
    }

    public void setSm(com.prowidesoftware.swift.model.SwiftMessage sm) {
        this.sm = sm;
    }

    public String getF20() {
        return f20;
    }

    public void setF20(String f20) {
        this.f20 = f20;
    }

    public String getF21() {
        return f21;
    }

    public void setF21(String f21) {
        this.f21 = f21;
    }

    public String getF52d() {
        return f52d;
    }

    public void setF52d(String f52d) {
        this.f52d = f52d;
    }

    public String getF57a() {
        return f57a;
    }

    public void setF57a(String f57a) {
        this.f57a = f57a;
    }

    public String getF72() {
        return f72;
    }

    public void setF72(String f72) {
        this.f72 = f72;
    }

    public String getF79() {
        return f79;
    }

    public void setF79(String f79) {
        this.f79 = f79;
    }

    public String getF53a() {
        return f53a;
    }

    public void setF53a(String f53a) {
        this.f53a = f53a;
    }


    public String getF54a() {
        return f54a;
    }

    public void setF54a(String f54a) {
        this.f54a = f54a;
    }

    public String getSender() {
        return sender;
    }

    public void setSender(String sender) {
        this.sender = sender;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public Date getValue_date() {
        return value_date;
    }

    public void setValue_date(Date value_date) {
        this.value_date = value_date;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getReceiver() {
        return receiver;
    }

    public void setReceiver(String receiver) {
        this.receiver = receiver;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getSwiftId() {
        return swiftId;
    }

    public String getF72s() {
        return f72s;
    }

    public void setF72s(String f72s) {
        this.f72s = f72s;
    }

    public String getF70() {
        return f70;
    }

    public String getF57d() {
        return f57d;
    }
}
