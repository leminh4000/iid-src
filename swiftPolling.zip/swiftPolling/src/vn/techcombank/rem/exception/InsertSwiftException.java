package vn.techcombank.rem.exception;

public class InsertSwiftException extends GeneralException {
    public InsertSwiftException(String message, String f20, String fileName) {
        super(message, f20, fileName);
    }
}
