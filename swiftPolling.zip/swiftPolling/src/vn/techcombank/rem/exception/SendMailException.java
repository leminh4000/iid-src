package vn.techcombank.rem.exception;

public class SendMailException extends GeneralException {
    public SendMailException(String message, String f20, String fileName) {
        super(message, f20, fileName);
    }
}
