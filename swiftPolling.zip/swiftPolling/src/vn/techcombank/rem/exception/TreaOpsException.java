package vn.techcombank.rem.exception;

public class TreaOpsException extends GeneralException {
    public TreaOpsException(String message, String f20, String fileName) {
        super(message, f20, fileName);
    }
}
