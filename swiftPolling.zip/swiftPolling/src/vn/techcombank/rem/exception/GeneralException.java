package vn.techcombank.rem.exception;

import java.io.PrintWriter;
import java.io.StringWriter;

public class GeneralException extends Exception{
    String f20;
    String fileName;

    public GeneralException(String message, String f20, String fileName) {
        super(message);
        this.f20 = f20;
        this.fileName = fileName;
    }

    @Override
    public String getMessage() {
        return fileName + " " + f20 + " " + "Detail:" + super.getMessage();
    }
}
