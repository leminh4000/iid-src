package vn.techcombank.rem.exception;

public class ParserException extends GeneralException {
    public ParserException(String message, String f20, String fileName) {
        super(message, f20, fileName);
    }
}
