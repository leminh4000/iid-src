package vn.techcombank.rem.exception;

public class MoveFileException extends GeneralException {
    public MoveFileException(String message, String f20, String fileName) {
        super(message, f20, fileName);
    }
}
