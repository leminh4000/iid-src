package vn.techcombank.rem.exception;

public class DetermineSwiftException extends GeneralException {
    public DetermineSwiftException(String message, String f20, String fileName) {
        super(message, f20, fileName);
    }
}
