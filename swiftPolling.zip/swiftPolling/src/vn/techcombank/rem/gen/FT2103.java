package vn.techcombank.rem.gen;

import java.io.IOException;

public class FT2103 {
    public static void main(String[] args) throws IOException {
        FT52 ft52 = new FT52("FT2103.properties");
        ft52.create();
    }
}
