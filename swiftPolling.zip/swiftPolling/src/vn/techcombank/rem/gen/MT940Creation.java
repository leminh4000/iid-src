package vn.techcombank.rem.gen;

import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.field.*;
import com.prowidesoftware.swift.model.mt.mt9xx.MT910;
import com.prowidesoftware.swift.model.mt.mt9xx.MT940;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class MT940Creation {
    private final ArrayList<String> f59fs;
    private List<String> senders;
    private List<String> f32aCcys;
    private List<String> f32aAmounts;
    private List<String> f71As;
    public MT940 mt940 = new MT940();

    String create(){
        /*
         * Set sender and receiver BIC codes
         */
        String sender = senders.get(new Random().nextInt(senders.size()));
        boolean isVostro = sender.contains("VOSTRO");
        sender = sender.substring(sender.indexOf("_") + 1);
        mt940.setSender(sender);
        mt940.setReceiver("VTCBVNVXAXXX");

        SwiftBlock2Output b2 = new SwiftBlock2Output();

        b2.setValue("O940" +
                StringUtils.givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(10, '0', '9') +
                sender.substring(0,8) + "1" + sender.substring(8) +
                "16153117742005131001N");
        mt940.getSwiftMessage().setBlock2(b2);

        /*
         * Start adding the message's fields in correct order
         */
        String f20 = (isVostro? "FT5": "FT2") +
                "394" + StringUtils.givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(10, 'A', 'Z');
        mt940.addField(new Field13D("2005122326-0400"));
        mt940.addField(new Field20(f20));
        mt940.addField(new Field21(f20));
        mt940.addField(new Field25("2000191004023"));
        mt940.addField(new Field28C("0141/00004"));

        /*
         * Add a field using comprehensive setters API
         */
        String ccy = f32aCcys.get(new Random().nextInt(f32aCcys.size()));
        Field32A f32A = new Field32A()
                .setDate(Calendar.getInstance())
                .setCurrency(ccy)
                .setAmount(f32aAmounts.get(new Random().nextInt(f32aAmounts.size())));
        mt940.addField(f32A);
        mt940.addField(new Field60M("C200512" +
                ccy +
                "115378,50"));
        mt940.addField(new Field61("2005120512CD1,00S100" +
                f20 +
                "//S0601322999C01\n" +
                "B/O 1/GON KARASSO\n" +
                ":86:SELF TRANSFER LESS CHARGES\n" +
                "BNF:19133724268022 GON KARASSO\n" +
                "ORD:1/GON KARASSO\n" +
                "3/IL/MODIIN\n" +
                "THE FIRST INTERNATIONAL BANK O"));
        mt940.addField(new Field62M("C200512CAD141289,49"));
        /*
         * Create and print out the SWIFT FIN message string
         */
        System.out.println(mt940.message());
        return mt940.message();
    }

    public MT940Creation(List<String> senders, List<String> f32aCcys, List<String> f32aAmounts, List<String> f71As, ArrayList<String> f59fs) {
        this.senders = senders;
        this.f32aCcys = f32aCcys;
        this.f32aAmounts = f32aAmounts;
        this.f71As = f71As;
        this.f59fs = f59fs;
    }

    public MT940 getMt940() {
        return mt940;
    }

    public List<String> getSenders() {
        return senders;
    }

    public void setSenders(List<String> senders) {
        this.senders = senders;
    }

    public List<String> getF32aCcys() {
        return f32aCcys;
    }

    public void setF32aCcys(List<String> f32aCcys) {
        this.f32aCcys = f32aCcys;
    }

    public List<String> getF71As() {
        return f71As;
    }

    public void setF71As(List<String> f71As) {
        this.f71As = f71As;
    }

}
