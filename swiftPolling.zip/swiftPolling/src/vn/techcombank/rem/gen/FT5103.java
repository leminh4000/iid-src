package vn.techcombank.rem.gen;

import java.io.IOException;

public class FT5103 {
    public static void main(String[] args) throws IOException {
        FT52 ft52 = new FT52("FT5103.properties");
        ft52.create();
    }
}
