package vn.techcombank.rem.gen;

import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.field.*;
import com.prowidesoftware.swift.model.mt.mt1xx.MT103;
import com.prowidesoftware.swift.model.mt.mt9xx.MT910;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class MT910Creation {
    private final ArrayList<String> f59fs;
    private List<String> senders;
    private List<String> f32aCcys;
    private List<String> f32aAmounts;
    private List<String> f71As;
    public MT910 mt910 = new MT910();

    String create(){
        /*
         * Set sender and receiver BIC codes
         */
        String sender = senders.get(new Random().nextInt(senders.size()));
        boolean isVostro = sender.contains("VOSTRO");
        sender = sender.substring(sender.indexOf("_") + 1);
        mt910.setSender(sender);
        mt910.setReceiver("VTCBVNVXAXXX");

        SwiftBlock2Output b2 = new SwiftBlock2Output();

        b2.setValue("O910" +
                StringUtils.givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(10, '0', '9') +
                sender.substring(0,8) + "1" + sender.substring(8) +
                "16153117742005131001N");
        mt910.getSwiftMessage().setBlock2(b2);

        /*
         * Start adding the message's fields in correct order
         */
        String f20 = (isVostro? "FT5": "FT2") +
                "391" + StringUtils.givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(10, 'A', 'Z');
        mt910.addField(new Field13D("2005122326-0400"));
        mt910.addField(new Field20(f20));
        mt910.addField(new Field21(f20));
        mt910.addField(new Field25("2000191004023"));

        /*
         * Add a field using comprehensive setters API
         */
        Field32A f32A = new Field32A()
                .setDate(Calendar.getInstance())
                .setCurrency(f32aCcys.get(new Random().nextInt(f32aCcys.size())))
                .setAmount(f32aAmounts.get(new Random().nextInt(f32aAmounts.size())));
        mt910.addField(f32A);
        mt910.addField(new Field72("/BNF/SETTLEMENT YOUR MT 191\n" +
                "//CHARGE REQUEST DATED 190909\n" +
                "//REFERENCE FT19242342373253\n" +
                "/INS/UNMAPPED GLS ACCOUNT"));

        /*
         * Create and print out the SWIFT FIN message string
         */
        System.out.println(mt910.message());
        return mt910.message();
    }

    public MT910Creation(List<String> senders, List<String> f32aCcys, List<String> f32aAmounts, List<String> f71As, ArrayList<String> f59fs) {
        this.senders = senders;
        this.f32aCcys = f32aCcys;
        this.f32aAmounts = f32aAmounts;
        this.f71As = f71As;
        this.f59fs = f59fs;
    }

    public MT910 getMt910() {
        return mt910;
    }

    public List<String> getSenders() {
        return senders;
    }

    public void setSenders(List<String> senders) {
        this.senders = senders;
    }

    public List<String> getF32aCcys() {
        return f32aCcys;
    }

    public void setF32aCcys(List<String> f32aCcys) {
        this.f32aCcys = f32aCcys;
    }

    public List<String> getF71As() {
        return f71As;
    }

    public void setF71As(List<String> f71As) {
        this.f71As = f71As;
    }

}
