package vn.techcombank.rem.gen;

import java.io.IOException;

public class FT52103910 {
    public static void main(String[] args) throws IOException {
        FT52 ft52 = new FT52("FT52103910.properties");
        ft52.create();
    }
}
