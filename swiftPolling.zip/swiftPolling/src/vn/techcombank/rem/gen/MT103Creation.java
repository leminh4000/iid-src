package vn.techcombank.rem.gen;

import com.prowidesoftware.swift.model.SwiftBlock2Output;
import com.prowidesoftware.swift.model.field.*;
import com.prowidesoftware.swift.model.mt.mt1xx.MT103;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class MT103Creation {
    private final ArrayList<String> f59fs;
    private final String f53;
    private final String f20;
    private List<String> senders;
    private List<String> f32aCcys;
    private List<String> f32aAmounts;
    private List<String> f71As;
    public MT103 mt103 = new MT103();

    String create(){
        /*
         * Set sender and receiver BIC codes
         */
        String sender = senders.get(new Random().nextInt(senders.size()));
        boolean isVostro = sender.contains("VOSTRO");
        sender = sender.substring(sender.indexOf("_") + 1);
        mt103.setSender(sender);
        mt103.setReceiver("VTCBVNVXAXXX");

        SwiftBlock2Output b2 = new SwiftBlock2Output();

        b2.setValue("O103" +
                StringUtils.givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(10, '0', '9') +
                sender.substring(0,8) + "1" + sender.substring(8) +
                "16153117742005131001N");
        mt103.getSwiftMessage().setBlock2(b2);

        /*
         * Start adding the message's fields in correct order
         */
        String f20 = this.f20 != null ? this.f20 : (isVostro? "FT5": "FT2") +
                "103" + StringUtils.givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(10, 'A', 'Z');
        mt103.addField(new Field20(f20));
        mt103.addField(new Field23B("CRED"));

        /*
         * Add a field using comprehensive setters API
         */
        Field32A f32A = new Field32A()
                .setDate(Calendar.getInstance())
                .setCurrency(f32aCcys.get(new Random().nextInt(f32aCcys.size())))
                .setAmount(f32aAmounts.get(new Random().nextInt(f32aAmounts.size())));
        mt103.addField(f32A);
        mt103.addField(new Field33B("USD1131"));
        mt103.addField(new Field50K("/NL80ABNA0581122240\n" +
                "        1/DE JONG DRAAD   ZO B.V.\n" +
                "        2/MERCURIUSWEG 11\n" +
                "        3/NL/2741 TB WADDINXVEEN"));
        mt103.addField(new Field52A("ABNANL2AXXX\n" +
                "        :59F:/19720179755029\n" +
                "        1/KHACH HANG 20179755\n" +
                "        2/HANOI/VIETNAM"));
        if (f53 != null) mt103.addField(new Field53A(f53));

        mt103.addField(new Field59F(f59fs.get(new Random().nextInt(f59fs.size()))));
        mt103.addField(new Field70("INVOICE 2019-1-PD"));
        mt103.addField(new Field71A(f71As.get(new Random().nextInt(f71As.size()))));

        /*
         * Create and print out the SWIFT FIN message string
         */
        System.out.println(mt103.message());
        return mt103.message();
    }

    public MT103Creation(List<String> senders, List<String> f32aCcys, List<String> f32aAmounts, List<String> f71As, ArrayList<String> f59fs, String f53, String f20) {
        this.senders = senders;
        this.f32aCcys = f32aCcys;
        this.f32aAmounts = f32aAmounts;
        this.f71As = f71As;
        this.f59fs = f59fs;
        this.f53 = f53;
        this.f20 =  f20;
    }

    public List<String> getSenders() {
        return senders;
    }

    public void setSenders(List<String> senders) {
        this.senders = senders;
    }

    public List<String> getF32aCcys() {
        return f32aCcys;
    }

    public void setF32aCcys(List<String> f32aCcys) {
        this.f32aCcys = f32aCcys;
    }

    public List<String> getF71As() {
        return f71As;
    }

    public void setF71As(List<String> f71As) {
        this.f71As = f71As;
    }

    public MT103 getMt103() {
        return mt103;
    }
}
