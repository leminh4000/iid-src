package vn.techcombank.rem.gen;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;

public class FT52 {

    private  String propsFile;

    public FT52(String propsFile) {
        this.propsFile = propsFile;
    }

    public static void main(String[] args) throws IOException {
        FT52 ft52 = new FT52("FT5103.properties");
        ft52.create();
    }

    public void create() throws IOException {
        InputStream is = null;
        Properties prop = null;
        try {
            prop = new Properties();
            is = new FileInputStream(propsFile);
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        List<String> merges = StringUtils.toList(prop.getProperty("fins"), ",");
        int size = new Integer(prop.getProperty("size")).intValue();
        if (merges.size() == 1 && merges.get(0).equals("103")) {//103 don
            for (int i = 0; i < size; i++) {
                createMT103(prop);
            }
        }
        else if (merges.size() == 2 && merges.get(0).equals("103") && merges.get(1).equals("910")) {
            for (int i = 0; i < size; i++) {
                String f53="CITIUS33DXXX\n" +
                        "CITIBANK JAPAN LTD.\n" +
                        "TOKYO JP";
                MT910Creation mt910Creation = createMT910(prop);
                String f20=mt910Creation.getMt910().getField21().getValue();
                String sender=mt910Creation.getMt910().getSender();
                createMT103with910(prop, f53, f20, sender.substring(0,8) + sender.substring(9));
            }
        } else if (merges.size() == 2 && merges.get(0).equals("103") && merges.get(1).equals("940")) {
            for (int i = 0; i < size; i++) {
                MT940Creation mt940Creation = createMT940(prop);
                String f20=mt940Creation.getMt940().getField21().getValue();
                String sender=mt940Creation.getMt940().getSender();
                String swiftCode = sender.substring(0, 8) + sender.substring(9);
                String f53=swiftCode;
                createMT103with940(prop, f53, f20, swiftCode);
            }
        }
    }

    private MT910Creation createMT910(Properties prop) throws IOException {
        MT910Creation mt910Creation = new MT910Creation(StringUtils.toList(prop.getProperty("senders"), ","),
                StringUtils.toList(prop.getProperty("f32aCcys"), ","),
                StringUtils.toList(prop.getProperty("f32aAmounts"), ":"),
                StringUtils.toList(prop.getProperty("f71As"), ","),
                StringUtils.toList(prop.getProperty("f59s"), ":")
        );
        String content = mt910Creation.create();
        String fileName = prop.getProperty("folder") + "/"
                + mt910Creation.getMt910().getField21().getValue()
                + "_910";
        Files.write(Paths.get(fileName)
                , content.getBytes());
        System.out.println("Created file: " + fileName);
        return mt910Creation;
    }
    private MT940Creation createMT940(Properties prop) throws IOException {
        MT940Creation mt940Creation = new MT940Creation(StringUtils.toList(prop.getProperty("senders"), ","),
                StringUtils.toList(prop.getProperty("f32aCcys"), ","),
                StringUtils.toList(prop.getProperty("f32aAmounts"), ":"),
                StringUtils.toList(prop.getProperty("f71As"), ","),
                StringUtils.toList(prop.getProperty("f59s"), ":")
        );
        String content = mt940Creation.create();
        String fileName = prop.getProperty("folder") + "/"
                + mt940Creation.getMt940().getField21().getValue()
                + "_940";
        Files.write(Paths.get(fileName)
                , content.getBytes());
        System.out.println("Created file: " + fileName);
        return mt940Creation;
    }

    private MT103Creation createMT103(Properties prop) throws IOException {
        MT103Creation mt103Creation = new MT103Creation(StringUtils.toList(prop.getProperty("senders"), ","),
                StringUtils.toList(prop.getProperty("f32aCcys"), ","),
                StringUtils.toList(prop.getProperty("f32aAmounts"), ":"),
                StringUtils.toList(prop.getProperty("f71As"), ","),
                StringUtils.toList(prop.getProperty("f59s"), ":"),
                null,
                null
        );
        String content = mt103Creation.create();
        String fileName = prop.getProperty("folder") + "/"
                + mt103Creation.getMt103().getField20().getValue()
                + "_103"
                + "_" + mt103Creation.getMt103().getField71A().getValue()
                + "_" + mt103Creation.getMt103().getField32A().getCurrency()
                + "_" + (mt103Creation.getMt103().getField59F().getValue().contains("RETAIL") ? "CN" : "DN");
        Files.write(Paths.get(fileName)
                , content.getBytes());
        System.out.println("Created file: " + fileName);
        return mt103Creation;
    }
    private MT103Creation createMT103with910(Properties prop, String f53, String f20, String sender) throws IOException {
        List<String> senders = new ArrayList<>();
        senders.add(sender);
        MT103Creation mt103Creation = new MT103Creation(senders,
                StringUtils.toList(prop.getProperty("f32aCcys"), ","),
                StringUtils.toList(prop.getProperty("f32aAmounts"), ":"),
                StringUtils.toList(prop.getProperty("f71As"), ","),
                StringUtils.toList(prop.getProperty("f59s"), ":"),
                f53,
                f20
        );
        String content = mt103Creation.create();
        String fileName = prop.getProperty("folder") + "/"
                + mt103Creation.getMt103().getField20().getValue()
                + "_103"
                + "_" + mt103Creation.getMt103().getField71A().getValue()
                + "_" + mt103Creation.getMt103().getField32A().getCurrency()
                + "_" + (mt103Creation.getMt103().getField59F().getValue().contains("RETAIL") ? "CN" : "DN");
        Files.write(Paths.get(fileName)
                , content.getBytes());
        System.out.println("Created file: " + fileName);
        return mt103Creation;
    }
    private MT103Creation createMT103with940(Properties prop, String f53, String f20, String sender) throws IOException {
        List<String> senders = new ArrayList<>();
        senders.add(sender);
        MT103Creation mt103Creation = new MT103Creation(senders,
                StringUtils.toList(prop.getProperty("f32aCcys"), ","),
                StringUtils.toList(prop.getProperty("f32aAmounts"), ":"),
                StringUtils.toList(prop.getProperty("f71As"), ","),
                StringUtils.toList(prop.getProperty("f59s"), ":"),
                f53,
                f20
        );
        String content = mt103Creation.create();
        String fileName = prop.getProperty("folder") + "/"
                + mt103Creation.getMt103().getField20().getValue()
                + "_103"
                + "_" + mt103Creation.getMt103().getField71A().getValue()
                + "_" + mt103Creation.getMt103().getField32A().getCurrency()
                + "_" + (mt103Creation.getMt103().getField59F().getValue().contains("RETAIL") ? "CN" : "DN");
        Files.write(Paths.get(fileName)
                , content.getBytes());
        System.out.println("Created file: " + fileName);
        return mt103Creation;
    }

}
