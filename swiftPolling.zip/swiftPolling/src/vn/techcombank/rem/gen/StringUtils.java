package vn.techcombank.rem.gen;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class StringUtils {
    public static String givenUsingPlainJava_whenGeneratingRandomStringBounded_thenCorrect(int targetStringLength, char startChar, char endChar) {

        int leftLimit = (int) startChar; // letter 'A'
        int rightLimit = (int) endChar; // letter 'Z'
        Random random = new Random();
        StringBuilder buffer = new StringBuilder(targetStringLength);
        for (int i = 0; i < targetStringLength; i++) {
            int randomLimitedInt = leftLimit + (int)
                    (random.nextFloat() * (rightLimit - leftLimit + 1));
            buffer.append((char) randomLimitedInt);
        }
        return buffer.toString();
    }

    static ArrayList<String> toList(String stringValue, String regex) {
        return new ArrayList<String>(Arrays.asList(stringValue.split(regex)));
    }
}
