
package vn.techcombank.rem.sendmail;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.bind.annotation.adapters.HexBinaryAdapter;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;


/**
 * <p>Java class for EmailResponseBO complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="EmailResponseBO">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="deliveredTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="undeliveredTo" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="status" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="messageId" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="emailRequest" type="{http://BBSESTK}EmailRequest" minOccurs="0"/>
 *         &lt;element name="emailRequestXML" type="{http://www.w3.org/2001/XMLSchema}hexBinary" minOccurs="0"/>
 *         &lt;element name="statusInfo" type="{http://BBSESTK}StatusInfo" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "EmailResponseBO", propOrder = {
    "deliveredTo",
    "undeliveredTo",
    "status",
    "messageId",
    "emailRequest",
    "emailRequestXML",
    "statusInfo"
})
public class EmailResponseBO {

    protected String deliveredTo;
    protected String undeliveredTo;
    protected String status;
    protected String messageId;
    protected EmailRequest emailRequest;
    @XmlElement(type = String.class)
    @XmlJavaTypeAdapter(HexBinaryAdapter.class)
    @XmlSchemaType(name = "hexBinary")
    protected byte[] emailRequestXML;
    protected StatusInfo statusInfo;

    /**
     * Gets the value of the deliveredTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDeliveredTo() {
        return deliveredTo;
    }

    /**
     * Sets the value of the deliveredTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDeliveredTo(String value) {
        this.deliveredTo = value;
    }

    /**
     * Gets the value of the undeliveredTo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getUndeliveredTo() {
        return undeliveredTo;
    }

    /**
     * Sets the value of the undeliveredTo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setUndeliveredTo(String value) {
        this.undeliveredTo = value;
    }

    /**
     * Gets the value of the status property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getStatus() {
        return status;
    }

    /**
     * Sets the value of the status property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setStatus(String value) {
        this.status = value;
    }

    /**
     * Gets the value of the messageId property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getMessageId() {
        return messageId;
    }

    /**
     * Sets the value of the messageId property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setMessageId(String value) {
        this.messageId = value;
    }

    /**
     * Gets the value of the emailRequest property.
     * 
     * @return
     *     possible object is
     *     {@link EmailRequest }
     *     
     */
    public EmailRequest getEmailRequest() {
        return emailRequest;
    }

    /**
     * Sets the value of the emailRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmailRequest }
     *     
     */
    public void setEmailRequest(EmailRequest value) {
        this.emailRequest = value;
    }

    /**
     * Gets the value of the emailRequestXML property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public byte[] getEmailRequestXML() {
        return emailRequestXML;
    }

    /**
     * Sets the value of the emailRequestXML property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setEmailRequestXML(byte[] value) {
        this.emailRequestXML = value;
    }

    /**
     * Gets the value of the statusInfo property.
     * 
     * @return
     *     possible object is
     *     {@link StatusInfo }
     *     
     */
    public StatusInfo getStatusInfo() {
        return statusInfo;
    }

    /**
     * Sets the value of the statusInfo property.
     * 
     * @param value
     *     allowed object is
     *     {@link StatusInfo }
     *     
     */
    public void setStatusInfo(StatusInfo value) {
        this.statusInfo = value;
    }

}
