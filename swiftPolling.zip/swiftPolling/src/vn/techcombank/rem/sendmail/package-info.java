@javax.xml.bind.annotation.XmlSchema(namespace = "http://BBSESTK", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package vn.techcombank.rem.sendmail;
