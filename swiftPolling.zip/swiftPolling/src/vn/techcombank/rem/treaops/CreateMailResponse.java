
package vn.techcombank.rem.treaops;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="output1" type="{http://TREHSC8/WS_CatchMailInfo.tws}TreaOpsResponse"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "output1"
})
@XmlRootElement(name = "CreateMailResponse")
public class CreateMailResponse {

    @XmlElement(required = true)
    protected TreaOpsResponse output1;

    /**
     * Gets the value of the output1 property.
     * 
     * @return
     *     possible object is
     *     {@link TreaOpsResponse }
     *     
     */
    public TreaOpsResponse getOutput1() {
        return output1;
    }

    /**
     * Sets the value of the output1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link TreaOpsResponse }
     *     
     */
    public void setOutput1(TreaOpsResponse value) {
        this.output1 = value;
    }

}
