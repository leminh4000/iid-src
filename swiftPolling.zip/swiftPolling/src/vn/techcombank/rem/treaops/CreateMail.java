
package vn.techcombank.rem.treaops;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="input1" type="{http://TREHSC8/WS_CatchMailInfo.tws}MailInfoType"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "input1"
})
@XmlRootElement(name = "CreateMail")
public class CreateMail {

    @XmlElement(required = true)
    protected MailInfoType input1;

    /**
     * Gets the value of the input1 property.
     * 
     * @return
     *     possible object is
     *     {@link MailInfoType }
     *     
     */
    public MailInfoType getInput1() {
        return input1;
    }

    /**
     * Sets the value of the input1 property.
     * 
     * @param value
     *     allowed object is
     *     {@link MailInfoType }
     *     
     */
    public void setInput1(MailInfoType value) {
        this.input1 = value;
    }

}
