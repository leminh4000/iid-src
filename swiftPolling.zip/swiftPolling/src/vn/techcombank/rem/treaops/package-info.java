@javax.xml.bind.annotation.XmlSchema(namespace = "http://TREHSC8/WS_CatchMailInfo.tws", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package vn.techcombank.rem.treaops;
