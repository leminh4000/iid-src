package vn.techcombank.rem;

import vn.techcombank.rem.classify.*;

public class ClassifyClient {
    public static void main(String[] args) throws DetermineClassifyMessageFlowSoapFault {
        DetermineClassifyMessageFlowDecisionService_Service service = new DetermineClassifyMessageFlowDecisionService_Service();
        DetermineClassifyMessageFlowDecisionService port = service.getRMINClassifyMessageDetermineClassifyMessageFlowPort();
        DetermineClassifyMessageFlowRequest request = new DetermineClassifyMessageFlowRequest();
        CMRuleRequest cmRuleRequest = new CMRuleRequest();
        ClassifyMessageRequest classifyMessageRequest = new ClassifyMessageRequest();
        InputClassifyMessageArr inputClassifyMessageArr = new InputClassifyMessageArr();
        InputClassifyMessage inputClassifyMessage = new InputClassifyMessage();
        inputClassifyMessage.setF20("");
        inputClassifyMessageArr.getInputSwiftMessagersArr().add(inputClassifyMessage);

        classifyMessageRequest.setIInputInforArr(inputClassifyMessageArr);
        cmRuleRequest.setCMRuleRequest(classifyMessageRequest);
        request.setCMRuleRequest(cmRuleRequest);
        port.determineClassifyMessageFlow(request);

    }
}
