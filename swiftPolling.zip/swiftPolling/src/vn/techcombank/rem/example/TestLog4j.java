package vn.techcombank.rem.example;

import org.apache.commons.logging.Log;
import org.apache.log4j.Logger;
import org.apache.log4j.Priority;
import vn.techcombank.rem.SwiftConsumer;

import java.io.File;
import java.net.MalformedURLException;

public class TestLog4j {
    static{
        System.setProperty("log4j.configuration", "file:C:/Users/MinhLV/log4j.xml");
    }
    private static Logger logger = Logger.getLogger(TestLog4j.class);

    public static void main(String[] args) throws MalformedURLException {
//        System.setProperty("log4j.configuration", "file:C:/Users/MinhLV/log4j.xml");
//        Logger logger = Logger.getLogger(TestLog4j.class);
        logger.info("test22");
        logger.log(Priority.toPriority("INFO"), "test111");

    }
}
