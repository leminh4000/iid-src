package vn.techcombank.rem;

import java.util.Arrays;
import java.util.List;

public class HtmlHelper {

    public static void main(String[] args) {
        String readableContent ="fádfá";
        readableContent.replace("#SENDER", "dsfà").replace("#RECEIVER", null);

        List<String> headers = Arrays.asList("Company", "Contact", "Country");
        List<List<String>> data = Arrays.asList(Arrays.asList("Alfreds Futterkiste", "Maria Anders", "Germany"), Arrays.asList("Centro comercial Moctezuma", "Francisco Chang", "Mexico"));
        System.out.println(buildTable(headers, data));
    }

    public static String buildTable(List<String> headers,
                                    List<List<String>> data) {
        StringBuilder result = new StringBuilder();
        result.append("<table>");
        result.append("<tr>");
        for (String header : headers) {
            result.append("<th>");
            result.append(header);
            result.append("</th>");
        }
        result.append("</tr>");

        for (List<String> row : data) {
            result.append("<tr>");
            for (String cell : row) {
                result.append("<td>");
                result.append(cell);
                result.append("</td>");
            }
            result.append("</tr>");
        }
        result.append("</table>");
        return result.toString();
    }

}
