package vn.techcombank.rem;

import vn.techcombank.rem.treaops.MailInfoType;

import javax.xml.datatype.DatatypeConfigurationException;
import java.text.ParseException;

public interface TreaOpsPushInf {
    public MailInfoType transform() throws ParseException, DatatypeConfigurationException;
}
