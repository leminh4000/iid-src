package vn.techcombank.rem;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.log4j.Logger;
import org.apache.wss4j.common.crypto.Merlin;
import org.apache.wss4j.dom.handler.WSHandlerConstants;
import org.json.JSONObject;
import vn.techcombank.rem.classify.*;
import vn.techcombank.rem.exception.*;
import vn.techcombank.rem.insertswift.*;
import vn.techcombank.rem.insertswift.ObjectFactory;
import vn.techcombank.rem.sendmail.*;

import javax.xml.datatype.XMLGregorianCalendar;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class SwiftMessage {
    final static Logger logger = Logger.getLogger("log1");
    final static Logger loggerMovefile = Logger.getLogger("movefile");
    final static Logger loggerInsertswift = Logger.getLogger("insertswift");
    final static Logger loggerSendmail = Logger.getLogger("sendmail");
    final static Logger loggerDetermineswift = Logger.getLogger("determineswift");
    final static Logger loggerParser = Logger.getLogger("parser");
    private final Map<String, String> cloneDepsMap;
    final static String FILE_DATETIME_PATTERN = "-yyyy-MM-dd-HH-mm-ss";

    private Path path;
    private String fileName;
    private String fin;
    private SwiftMT swiftMT;

    SwiftMessage(Path path, Map<String, String> cloneDepsMap) {
        this.path = path;
        this.cloneDepsMap = cloneDepsMap;
    }

    void process() {
//        trustAllHosts();
        String fin = "";
        fileName = path.getFileName().toString();
        SwiftInsertResp insertResp = null;
        try {
            try {
                backupFile(fileName, swiftMT);
                fin = pathToString();
                swiftMT = new SwiftMT(fin, fileName);
                logger.info("F20 = " + swiftMT.getF20());

                ResultClassifyMessage classify = getClassify(swiftMT);

                //            if (classify.getDepartment01().equals(TTTMNK) || classify.getDepartment01().equals(TTTMXK)) {
                if (cloneDepsMap.containsKey(classify.getDepartment01())) {
                    logger.info("Coping file to ECM folder");
                    copy2Ecm(fileName);
                    logger.info("File has been copied");
                }
                logger.info("Calling Insert Swift service");
                insertResp = insert(swiftMT, classify.getDepartment01(), classify.getDepartment02(), classify.getTransaction());
                logger.info("Call Insert Swift service success");
                logger.info("Copied file " + fileName + " to backup folder");
                moveFile(fileName, insertResp);
            } catch (ParserException e) {
                loggerParser.error(e);
                doError(fin);
            } catch (DetermineSwiftException e) {
                loggerDetermineswift.error(e);
                doError(fin);
            } catch (MoveFileException e) {
                loggerMovefile.error(e);
                doError(fin);
            } catch (InsertSwiftException e) {
                loggerInsertswift.error(e);
                doError(fin);
            } catch (Exception e) {
                logger.error(e);
                doError(fin);
            }

        } catch (MoveFileException e) {
            loggerMovefile.error(e);
        } catch (Exception e){
            logger.error(e);
        }


        logger.info(".");
    }

    private void doError(String fin) throws MoveFileException {
        logger.error("ERROR!!!!!!!!!!!!!!!!!!!!Sending email...");
        try {
            sendErrorMail(path, fin == null ? "" : (fin.length() < 500? fin : fin.substring(500)));
        } catch (SendMailException e) {
            loggerSendmail.error(e);
            e.printStackTrace();
            moveToFail(fileName);
        }
        logger.error("Sent email for error fin " + path.getFileName().toString());
        moveToFail(fileName);
    }

    private void copy2Ecm(String fileName) throws MoveFileException {
        try {
            Files.copy(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.ecmDir, fileName), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
            throw new MoveFileException(e.getMessage(), swiftMT.getF20(), fileName);
        }
    }

    private String pathToString() throws MoveFileException {
        String fin = null;
        try {
            fin = new String(Files.readAllBytes(path));
        } catch (IOException e) {
            e.printStackTrace();
            throw new MoveFileException(e.getMessage(), swiftMT.getF20(), swiftMT.getFileName());
        }
        return fin;
    }

    private void moveFile(String fileName, SwiftInsertResp insertResp) throws MoveFileException {
        try {
            if (insertResp == null || insertResp.getId() == null) {
                moveToFail(fileName);
            } else {
                moveToSuccess(fileName);
            }
        } catch (IOException e) {
            e.printStackTrace();
            throw new MoveFileException(e.getMessage(), swiftMT.getF20(), swiftMT.getFileName());
        }
    }

    private void moveToSuccess(String fileName) throws IOException {
        Files.move(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.successDir, fileName), StandardCopyOption.REPLACE_EXISTING);
        logger.info("Moved file " + fileName + " to success folder");
    }

    private void moveToFail(String fileName) throws MoveFileException {
        try {
            if (Files.exists(Paths.get(SwiftProducer.eventDir, fileName))) {
                Files.move(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.failDir, fileName), StandardCopyOption.REPLACE_EXISTING);
                logger.error("Move file " + fileName + " to fail folder");
            }
        } catch (IOException e) {
            throw new MoveFileException(e.getMessage(), swiftMT.getF20(), swiftMT.getFileName());
        }
    }

    private void backupFile(String fileName, SwiftMT swiftMT) throws MoveFileException {
        try {
            Files.copy(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.backupDir, fileName), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            e.printStackTrace();
            throw new MoveFileException(e.getMessage(), swiftMT.getF20(), swiftMT.getFileName());
        }
    }

    private SwiftInsertResp insert(SwiftMT swiftMT, String department01, String department02, String transaction) throws InsertSwiftException {
//        SSLUtilities.trustAllHttpsCertificates();
        SwiftInsertResp resp = null;
        try {
            InsertSwift port = createServicePort();

            SwiftInsertReq req = new SwiftInsertReq();
            ObjectFactory objectFactory = new ObjectFactory();
            req.setAmount(objectFactory.createSwiftInsertReqAmount(swiftMT.getAmount()));
            req.setReadable(swiftMT.getReadable());
            req.setType(objectFactory.createSwiftInsertReqType(swiftMT.getType()));
            req.setCurrency(objectFactory.createSwiftInsertReqCurrency(swiftMT.getCurrency()));
            req.setDept(objectFactory.createSwiftInsertReqDept(department01));
            req.setDept2(department02);
            req.setProcessType(transaction);
            req.setSwiftId(swiftMT.getSwiftId());
            req.setF20Value(objectFactory.createSwiftInsertReqF20Value(swiftMT.getF20()));
            req.setF53A(swiftMT.getF53a());
            req.setF54A(swiftMT.getF54a());
            req.setF72(swiftMT.getF72());
            req.setF71F(swiftMT.getF71f());
            req.setF121(swiftMT.getF121());
            req.setF21Value(objectFactory.createSwiftInsertReqF21Value(swiftMT.getF21()));
            req.setFin(swiftMT.getFin());
            req.setFullContent(objectFactory.createSwiftInsertReqFullContent(swiftMT.getReadableJson()));
            req.setFileName(swiftMT.getFileName());
            req.setLinkNewFI(SwiftProducer.newFiLink);
            req.setLinkReminderNewKhdvkh(SwiftProducer.newKhLink);
            req.setDuplicateMailTo(SwiftProducer.duplicateMailTo);
            req.setMailFrom(SwiftProducer.mailFrom);
            req.setNewFiMailTo(SwiftProducer.newFiMailTo);
            req.setNewKhMailTo(SwiftProducer.newKhMailTo);
            req.setReceiver(swiftMT.getReceiver());
            req.setSender(objectFactory.createSwiftInsertReqSender(swiftMT.getSender()));
            req.setStatus(objectFactory.createSwiftInsertReqStatus(BigDecimal.valueOf(0)));
            XMLGregorianCalendar xmlGregorianCalendar = null;
            Date date = swiftMT.getValue_date();
            if (swiftMT.getValue_date() != null) {
                xmlGregorianCalendar = DateHelper.getXmlGregorianCalendar(date);
                req.setValueDate(objectFactory.createSwiftInsertReqValueDate(xmlGregorianCalendar));
            }
        /*try {
            req.setCreatedDate(objectFactory.createSwiftInsertReqCreatedDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(LocalDate.now().toString())));
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }*/
//        ((BindingProvider) port).getRequestContext().put(BindingProviderProperties.REQUEST_TIMEOUT, -1);
        /*Map requestContext = ((BindingProvider) port).getRequestContext();
        requestContext.put(JAXWSProperties.CONNECT_TIMEOUT, 300000);
        requestContext.put(JAXWSProperties.REQUEST_TIMEOUT, 300000);*/

            resp = port.operation1(req);
            logger.info("Inserted Swift message have id " + resp.getId() + "," + resp.getId2());
        } catch (Exception e) {
            e.printStackTrace();
            throw new InsertSwiftException(e.getMessage(), swiftMT.getF20(), swiftMT.getFileName());
        }
        return resp;
    }

    private InsertSwift createServicePort() {
//        outProps.put("encryptionParts",
//                "{Element}{" + WSSE_NS + "}UsernameToken;"
//                        + "{Content}{http://schemas.xmlsoap.org/soap/envelope/}Body");
        InsertSwiftExport1InsertSwiftHttpService service = new InsertSwiftExport1InsertSwiftHttpService();
        InsertSwift port = service.getInsertSwiftExport1InsertSwiftHttpPort();

        if ("true".equals(SwiftProducer.prop.get("isEncryted"))) {
            org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
            org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();
            WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(createOutProps());
            cxfEndpoint.getOutInterceptors().add(wssOut);
        }


//        Map<String, Object> requestContext = ((BindingProvider) port).getRequestContext();
//        requestContext.put(BindingProviderProperties.REQUEST_TIMEOUT, new Integer((String) SwiftProducer.prop.get("insertSwiftRequestTimeout"))); // Timeout in millis
//        requestContext.put(BindingProviderProperties.CONNECT_TIMEOUT, new Integer((String) SwiftProducer.prop.get("insertSwiftConnectTimeout"))); // Timeout in millis
        modifyReceiveTimeout(port, new Integer((String) SwiftProducer.prop.get("insertSwiftRequestTimeout")), new Integer((String) SwiftProducer.prop.get("insertSwiftConnectTimeout")));
        return port;
    }

    public static void modifyReceiveTimeout(final Object o, int receiveTimeout, int connectionTimeout) {
        Client client = ClientProxy.getClient(o);
        HTTPConduit conduit = (HTTPConduit) client.getConduit();
        HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
        httpClientPolicy.setReceiveTimeout(receiveTimeout);
        httpClientPolicy.setConnectionTimeout(connectionTimeout);
        conduit.setClient(httpClientPolicy);
    }

    private void sendErrorMail(Path path, String fin) throws SendMailException {
        try {
            java.util.List<String> headers = java.util.Arrays.asList("STT", "Nội dung điện", "Tên file");
            java.util.List<java.util.List<String>> data = java.util.Arrays.asList(java.util.Arrays.asList("1", fin, path.getFileName().toString()));
            String tableErrorSwift = HtmlHelper.buildTable(headers, data);

            SendEmailServiceAIS port = getSendEmailServiceAIS();


            SendEmailTemplateReq sendTemplateEmailReq = new SendEmailTemplateReq();
            EmailRequest emailRequest = new EmailRequest();
            sendTemplateEmailReq.setEmailRequest(emailRequest);
            emailRequest.setTemplateId("99802");
            emailRequest.setTo(SwiftProducer.duplicateMailTo);
            emailRequest.setFrom(SwiftProducer.mailFrom);
            TemplateContentBO templateContent = new TemplateContentBO();
            KeyValueRequest keyValueRequest = new KeyValueRequest();
            keyValueRequest.setKey("table");
            keyValueRequest.setValue(tableErrorSwift);
            templateContent.getKeyValueReq().add(keyValueRequest);
            emailRequest.setTemplateContent(templateContent);
            port.invoke(sendTemplateEmailReq);
        } catch (Exception e) {
            throw new SendMailException(e.getMessage(), swiftMT == null ? "N/A" : swiftMT.getF20(), fileName);
        }
    }

    private SendEmailServiceAIS getSendEmailServiceAIS() {
//        outProps.put("encryptionParts",
//                "{Element}{" + WSSE_NS + "}UsernameToken;"
//                        + "{Content}{http://schemas.xmlsoap.org/soap/envelope/}Body");
        SendEmailTemplateExportSendEmailServiceAISHttpService service = new SendEmailTemplateExportSendEmailServiceAISHttpService();
        SendEmailServiceAIS port = service.getSendEmailTemplateExportSendEmailServiceAISHttpPort();
        if ("true".equals(SwiftProducer.prop.get("isEncrytedEmail"))) {
            org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
            org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();
            WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(createOutProps());
            cxfEndpoint.getOutInterceptors().add(wssOut);
        }
        return port;
    }

    private Map<String, Object> createOutProps() {
        Map<String, Object> outProps = new HashMap<String, Object>();
        outProps.put("action", "Timestamp Encrypt");
        outProps.put("encryptionUser", "hpt");
//        outProps.put("encryptionPropFile", "Client_Encrypt.properties");
        final String decryptionPropRefId = "securityProperties";
        outProps.put("encryptionPropRefId", decryptionPropRefId);
        final Properties securityProperties = new Properties();
        securityProperties.put("org.apache.ws.security.crypto.provider", Merlin.class.getName());
        securityProperties.put("org.apache.ws.security.crypto.merlin.keystore.type", "jks");
        securityProperties.put("org.apache.ws.security.crypto.merlin.keystore.password", "Hhh$$111");
        securityProperties.put("org.apache.ws.security.crypto.merlin.keystore.alias", "hpt");
        securityProperties.put("org.apache.ws.security.crypto.merlin.keystore.file", "hptsender.jks");

        outProps.put(decryptionPropRefId, securityProperties);
        outProps.put("encryptionKeyIdentifier", "IssuerSerial");
        outProps.put(WSHandlerConstants.ENC_KEY_TRANSPORT, "http://www.w3.org/2001/04/xmlenc#rsa-1_5");
        return outProps;
    }

    private ResultClassifyMessage getClassify(SwiftMT swiftMT) throws DetermineSwiftException {
        try {
            DetermineClassifyMessageFlowDecisionService_Service service = new DetermineClassifyMessageFlowDecisionService_Service();
            DetermineClassifyMessageFlowDecisionService port = service.getRMINClassifyMessageDetermineClassifyMessageFlowPort();
//            Map<String, Object> requestContext = ((BindingProvider) port).getRequestContext();
//            requestContext.put(BindingProviderProperties.REQUEST_TIMEOUT, new Integer((String) SwiftProducer.prop.get("classifyRequestTimeout"))); // Timeout in millis
//            requestContext.put(BindingProviderProperties.CONNECT_TIMEOUT, new Integer((String) SwiftProducer.prop.get("classifyConnectTimeout"))); // Timeout in millis
            modifyReceiveTimeout(port, new Integer((String) SwiftProducer.prop.get("classifyRequestTimeout")), new Integer((String) SwiftProducer.prop.get("classifyConnectTimeout")));
            DetermineClassifyMessageFlowRequest request = new DetermineClassifyMessageFlowRequest();
            CMRuleRequest cmRuleRequest = new CMRuleRequest();
            ClassifyMessageRequest classifyMessageRequest = new ClassifyMessageRequest();
            InputClassifyMessageArr inputClassifyMessageArr = new InputClassifyMessageArr();
            InputClassifyMessage inputClassifyMessage = new InputClassifyMessage();
            inputClassifyMessage.setF20(swiftMT.getF20());
            inputClassifyMessage.setCurrency(swiftMT.getCurrency());
            inputClassifyMessage.setF21(swiftMT.getF21());
            inputClassifyMessage.setF52(swiftMT.getF52d());
            inputClassifyMessage.setF57A(swiftMT.getF57a());
            inputClassifyMessage.setF57D(swiftMT.getF57d());
            inputClassifyMessage.setF70(swiftMT.getF70());
            inputClassifyMessage.setF72(swiftMT.getF72s());
            inputClassifyMessage.setF79(swiftMT.getF79());
            inputClassifyMessage.setSender(swiftMT.getSender());
            inputClassifyMessage.setTypeSwift(swiftMT.getType());

            inputClassifyMessageArr.getInputSwiftMessagersArr().add(inputClassifyMessage);

            classifyMessageRequest.setIInputInforArr(inputClassifyMessageArr);
            cmRuleRequest.setCMRuleRequest(classifyMessageRequest);
            request.setCMRuleRequest(cmRuleRequest);
            logger.info("Classify Req =" + new JSONObject(request).toString());
            DetermineClassifyMessageFlowResponse response = port.determineClassifyMessageFlow(request);
            logger.info("Classify Resp =" + new JSONObject(response).toString());
            return response.getCMRuleResponse().getCMRuleResponse().getOResultArr().getResultSwiftMessagersArr().get(0);
        } catch (Exception e) {
            e.printStackTrace();
            throw new DetermineSwiftException(e.getMessage(), swiftMT.getF20(), swiftMT.getFileName());
        }
    }


}
