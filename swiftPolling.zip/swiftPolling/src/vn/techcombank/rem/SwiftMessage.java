package vn.techcombank.rem;

import com.sun.xml.internal.ws.client.BindingProviderProperties;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.ws.security.wss4j.WSS4JOutInterceptor;
import org.apache.log4j.Logger;
import org.apache.wss4j.dom.handler.WSHandlerConstants;
import org.json.JSONObject;
import vn.techcombank.rem.classify.*;
import vn.techcombank.rem.insertswift.*;
import vn.techcombank.rem.insertswift.ObjectFactory;
import vn.techcombank.rem.sendmail.*;

import javax.net.ssl.*;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.cert.CertificateException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class SwiftMessage {
    final static Logger logger = Logger.getLogger(SwiftMessage.class);
    public static final String TTTMNK = "TTTMNK";
    public static final String TTTMXK = "TTTMXK";
    private final Map<String, String> cloneDepsMap;
    final static String FILE_DATETIME_PATTERN = "-yyyy-MM-dd-HH-mm-ss";

    private Path path;
    private String fileName;
    private String fin;

    SwiftMessage(Path path, Map<String, String> cloneDepsMap) {
        this.path = path;
        this.cloneDepsMap = cloneDepsMap;
    }

    public static void trustAllHosts() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509ExtendedTrustManager() {
                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void process() {
//        trustAllHosts();
        String fin = "";
        String fileName = path.getFileName().toString();
        SwiftInsertResp insertResp = null;
        try {
            backupFile(fileName);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error(e);
        }
        try {
            fin = new String(Files.readAllBytes(path));
            SwiftMT swiftMT = new SwiftMT(fin, fileName);
            logger.info("F20 = " + swiftMT.getF20());

            ResultClassifyMessage classify = getClassify(swiftMT);

//            if (classify.getDepartment01().equals(TTTMNK) || classify.getDepartment01().equals(TTTMXK)) {
            if (cloneDepsMap.containsKey(classify.getDepartment01())) {
                logger.info("Coping file to ECM folder");
                Files.copy(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.ecmDir, fileName), StandardCopyOption.REPLACE_EXISTING);
                logger.info("File has been copied");
            }
            logger.info("Calling Insert Swift service");
            insertResp = insert(swiftMT, classify.getDepartment01(), classify.getDepartment02(), classify.getTransaction());
            logger.info("Call Insert Swift service success");
            logger.info("Copied file " + fileName + " to backup folder");
            moveFile(fileName, insertResp);
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!Sending email...");
            try {
                sendErrorMail(path, fin);
            } catch (Exception e2) {
                logger.error(e2);
                e2.printStackTrace();
                try {
                    sendErrorMail(path, fin.substring(100));
                } catch (Exception e3) {
                    logger.error(e3);
                    e3.printStackTrace();
                }
            }
            logger.error("Sent email for error fin " + path.getFileName().toString());
            try {
                moveToFail(fileName);
            } catch (IOException e1) {
                logger.error(e1);
                e1.printStackTrace();
            }
        }
        logger.info(".");
    }

    private void moveFile(String fileName, SwiftInsertResp insertResp) throws IOException {
        if (insertResp == null || insertResp.getId() == null) {
            moveToFail(fileName);
        } else {
            moveToSuccess(fileName);
        }
    }

    private void moveToSuccess(String fileName) throws IOException {
        Files.move(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.successDir, fileName), StandardCopyOption.REPLACE_EXISTING);
        logger.info("Moved file " + fileName + " to success folder");
    }

    private void moveToFail(String fileName) throws IOException {
        if (Files.exists(Paths.get(SwiftProducer.eventDir, fileName))) {
            Files.move(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.failDir, fileName), StandardCopyOption.REPLACE_EXISTING);
            logger.error("Move file " + fileName + " to fail folder");
        }
    }

    private void backupFile(String fileName) throws IOException {
        Files.copy(Paths.get(SwiftProducer.eventDir, fileName), Paths.get(SwiftProducer.backupDir, fileName), StandardCopyOption.REPLACE_EXISTING);
    }

    private SwiftInsertResp insert(SwiftMT swiftMT, String department01, String department02, String transaction) throws Exception {
//        SSLUtilities.trustAllHttpsCertificates();
        InsertSwift port = createServicePort();

        SwiftInsertReq req = new SwiftInsertReq();
        vn.techcombank.rem.insertswift.ObjectFactory objectFactory = new ObjectFactory();
        req.setAmount(objectFactory.createSwiftInsertReqAmount(swiftMT.getAmount()));
        req.setReadable(swiftMT.getReadable());
        req.setType(objectFactory.createSwiftInsertReqType(swiftMT.getType()));
        req.setCurrency(objectFactory.createSwiftInsertReqCurrency(swiftMT.getCurrency()));
        req.setDept(objectFactory.createSwiftInsertReqDept(department01));
        req.setDept2(department02);
        req.setProcessType(transaction);
        req.setSwiftId(swiftMT.getSwiftId());
        req.setF20Value(objectFactory.createSwiftInsertReqF20Value(swiftMT.getF20()));
        req.setF53A(swiftMT.getF53a());
        req.setF54A(swiftMT.getF54a());
        req.setF72(swiftMT.getF72());
        req.setF21Value(objectFactory.createSwiftInsertReqF21Value(swiftMT.getF21()));
        req.setFin(swiftMT.getFin());
        req.setFullContent(objectFactory.createSwiftInsertReqFullContent(swiftMT.getReadableJson()));
        req.setFileName(swiftMT.getFileName());
        req.setLinkNewFI(SwiftProducer.newFiLink);
        req.setLinkReminderNewKhdvkh(SwiftProducer.newKhLink);
        req.setDuplicateMailTo(SwiftProducer.duplicateMailTo);
        req.setMailFrom(SwiftProducer.mailFrom);
        req.setNewFiMailTo(SwiftProducer.newFiMailTo);
        req.setNewKhMailTo(SwiftProducer.newKhMailTo);
        req.setReceiver(swiftMT.getReceiver());
        req.setSender(objectFactory.createSwiftInsertReqSender(swiftMT.getSender()));
        req.setStatus(objectFactory.createSwiftInsertReqStatus(BigDecimal.valueOf(0)));
        XMLGregorianCalendar xmlGregorianCalendar = null;
        Date date = swiftMT.getValue_date();
        if (swiftMT.getValue_date() != null) {
            xmlGregorianCalendar = DateHelper.getXmlGregorianCalendar(date);
            req.setValueDate(objectFactory.createSwiftInsertReqValueDate(xmlGregorianCalendar));
        }
        /*try {
            req.setCreatedDate(objectFactory.createSwiftInsertReqCreatedDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(LocalDate.now().toString())));
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }*/
//        ((BindingProvider) port).getRequestContext().put(BindingProviderProperties.REQUEST_TIMEOUT, -1);
        /*Map requestContext = ((BindingProvider) port).getRequestContext();
        requestContext.put(JAXWSProperties.CONNECT_TIMEOUT, 300000);
        requestContext.put(JAXWSProperties.REQUEST_TIMEOUT, 300000);*/

        SwiftInsertResp resp = port.operation1(req);
        logger.info("Inserted Swift message have id " + resp.getId() + "," + resp.getId2());
        return resp;
    }

    private InsertSwift createServicePort() {
//        outProps.put("encryptionParts",
//                "{Element}{" + WSSE_NS + "}UsernameToken;"
//                        + "{Content}{http://schemas.xmlsoap.org/soap/envelope/}Body");
        InsertSwiftExport1InsertSwiftHttpService service = new InsertSwiftExport1InsertSwiftHttpService();
        InsertSwift port = service.getInsertSwiftExport1InsertSwiftHttpPort();
        org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
        org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();
        WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(createOutProps());
        cxfEndpoint.getOutInterceptors().add(wssOut);


        Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
        requestContext.put(BindingProviderProperties.REQUEST_TIMEOUT, new Integer((String) SwiftProducer.prop.get("insertSwiftRequestTimeout"))); // Timeout in millis
        requestContext.put(BindingProviderProperties.CONNECT_TIMEOUT, new Integer((String) SwiftProducer.prop.get("insertSwiftConnectTimeout"))); // Timeout in millis
        return port;
    }

    private void sendErrorMail(Path path, String fin) {
        java.util.List<String> headers = java.util.Arrays.asList("STT", "Nội dung điện", "Tên file");
        java.util.List<java.util.List<String>> data = java.util.Arrays.asList(java.util.Arrays.asList("1", fin, path.getFileName().toString()));
        String tableErrorSwift = HtmlHelper.buildTable(headers, data);

        SendEmailServiceAIS port = getSendEmailServiceAIS();


        SendEmailTemplateReq sendTemplateEmailReq = new SendEmailTemplateReq();
        EmailRequest emailRequest = new EmailRequest();
        sendTemplateEmailReq.setEmailRequest(emailRequest);
        emailRequest.setTemplateId("99802");
        emailRequest.setTo(SwiftProducer.duplicateMailTo);
        emailRequest.setFrom(SwiftProducer.mailFrom);
        TemplateContentBO templateContent = new TemplateContentBO();
        KeyValueRequest keyValueRequest = new KeyValueRequest();
        keyValueRequest.setKey("table");
        keyValueRequest.setValue(tableErrorSwift);
        templateContent.getKeyValueReq().add(keyValueRequest);
        emailRequest.setTemplateContent(templateContent);
        port.invoke(sendTemplateEmailReq);
    }

    private SendEmailServiceAIS getSendEmailServiceAIS() {
//        outProps.put("encryptionParts",
//                "{Element}{" + WSSE_NS + "}UsernameToken;"
//                        + "{Content}{http://schemas.xmlsoap.org/soap/envelope/}Body");
        SendEmailTemplateExportSendEmailServiceAISHttpService service = new SendEmailTemplateExportSendEmailServiceAISHttpService();
        SendEmailServiceAIS port = service.getSendEmailTemplateExportSendEmailServiceAISHttpPort();
        org.apache.cxf.endpoint.Client client = ClientProxy.getClient(port);
        org.apache.cxf.endpoint.Endpoint cxfEndpoint = client.getEndpoint();
        WSS4JOutInterceptor wssOut = new WSS4JOutInterceptor(createOutProps());
        cxfEndpoint.getOutInterceptors().add(wssOut);
        return port;
    }

    private Map<String, Object> createOutProps() {
        Map<String,Object> outProps = new HashMap<String,Object>();
        outProps.put("action", "Timestamp Encrypt");
        outProps.put("encryptionUser", "hpt");
        outProps.put("encryptionPropFile", "Client_Encrypt.properties");
        outProps.put("encryptionKeyIdentifier", "IssuerSerial");
        outProps.put(WSHandlerConstants.ENC_KEY_TRANSPORT, "http://www.w3.org/2001/04/xmlenc#rsa-1_5");
        return outProps;
    }

    private ResultClassifyMessage getClassify(SwiftMT swiftMT) throws DetermineClassifyMessageFlowSoapFault {
        DetermineClassifyMessageFlowDecisionService_Service service = new DetermineClassifyMessageFlowDecisionService_Service();
        DetermineClassifyMessageFlowDecisionService port = service.getRMINClassifyMessageDetermineClassifyMessageFlowPort();
        Map<String, Object> requestContext = ((BindingProvider)port).getRequestContext();
        requestContext.put(BindingProviderProperties.REQUEST_TIMEOUT, new Integer((String) SwiftProducer.prop.get("classifyRequestTimeout"))); // Timeout in millis
        requestContext.put(BindingProviderProperties.CONNECT_TIMEOUT, new Integer((String) SwiftProducer.prop.get("classifyConnectTimeout"))); // Timeout in millis
        DetermineClassifyMessageFlowRequest request = new DetermineClassifyMessageFlowRequest();
        CMRuleRequest cmRuleRequest = new CMRuleRequest();
        ClassifyMessageRequest classifyMessageRequest = new ClassifyMessageRequest();
        InputClassifyMessageArr inputClassifyMessageArr = new InputClassifyMessageArr();
        InputClassifyMessage inputClassifyMessage = new InputClassifyMessage();
        inputClassifyMessage.setF20(swiftMT.getF20());
        inputClassifyMessage.setCurrency(swiftMT.getCurrency());
        inputClassifyMessage.setF21(swiftMT.getF21());
        inputClassifyMessage.setF52(swiftMT.getF52d());
        inputClassifyMessage.setF57A(swiftMT.getF57a());
        inputClassifyMessage.setF57D(swiftMT.getF57d());
        inputClassifyMessage.setF70(swiftMT.getF70());
        inputClassifyMessage.setF72(swiftMT.getF72s());
        inputClassifyMessage.setF79(swiftMT.getF79());
        inputClassifyMessage.setSender(swiftMT.getSender());
        inputClassifyMessage.setTypeSwift(swiftMT.getType());

        inputClassifyMessageArr.getInputSwiftMessagersArr().add(inputClassifyMessage);

        classifyMessageRequest.setIInputInforArr(inputClassifyMessageArr);
        cmRuleRequest.setCMRuleRequest(classifyMessageRequest);
        request.setCMRuleRequest(cmRuleRequest);
        logger.info("Classify Req =" + new JSONObject(request).toString());
        DetermineClassifyMessageFlowResponse response = port.determineClassifyMessageFlow(request);
        logger.info("Classify Resp =" + new JSONObject(response).toString());
        return response.getCMRuleResponse().getCMRuleResponse().getOResultArr().getResultSwiftMessagersArr().get(0);
    }

}
