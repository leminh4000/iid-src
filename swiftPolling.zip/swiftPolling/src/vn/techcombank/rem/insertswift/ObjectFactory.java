
package vn.techcombank.rem.insertswift;

import java.math.BigDecimal;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.techcombank.rem.insertswift package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _SwiftInsertReqBc_QNAME = new QName("", "bc");
    private final static QName _SwiftInsertReqAmount_QNAME = new QName("", "amount");
    private final static QName _SwiftInsertReqF20Value_QNAME = new QName("", "f20_value");
    private final static QName _SwiftInsertReqFullContent_QNAME = new QName("", "full_content");
    private final static QName _SwiftInsertReqFromDepartment_QNAME = new QName("", "from_department");
    private final static QName _SwiftInsertReqDept_QNAME = new QName("", "dept");
    private final static QName _SwiftInsertReqType_QNAME = new QName("", "type");
    private final static QName _SwiftInsertReqSuffix_QNAME = new QName("", "suffix");
    private final static QName _SwiftInsertReqDocumentId_QNAME = new QName("", "document_id");
    private final static QName _SwiftInsertReqCreatedBy_QNAME = new QName("", "created_by");
    private final static QName _SwiftInsertReqF21Value_QNAME = new QName("", "f21_value");
    private final static QName _SwiftInsertReqSender_QNAME = new QName("", "sender");
    private final static QName _SwiftInsertReqCurrency_QNAME = new QName("", "currency");
    private final static QName _SwiftInsertReqId_QNAME = new QName("", "id");
    private final static QName _SwiftInsertReqCreatedDate_QNAME = new QName("", "created_date");
    private final static QName _SwiftInsertReqBankname_QNAME = new QName("", "bankname");
    private final static QName _SwiftInsertReqValueDate_QNAME = new QName("", "value_date");
    private final static QName _SwiftInsertReqStatus_QNAME = new QName("", "status");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.techcombank.rem.insertswift
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Operation1 }
     * 
     */
    public Operation1 createOperation1() {
        return new Operation1();
    }

    /**
     * Create an instance of {@link SwiftInsertReq }
     * 
     */
    public SwiftInsertReq createSwiftInsertReq() {
        return new SwiftInsertReq();
    }

    /**
     * Create an instance of {@link Operation1Response }
     * 
     */
    public Operation1Response createOperation1Response() {
        return new Operation1Response();
    }

    /**
     * Create an instance of {@link SwiftInsertResp }
     * 
     */
    public SwiftInsertResp createSwiftInsertResp() {
        return new SwiftInsertResp();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bc", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqBc(String value) {
        return new JAXBElement<String>(_SwiftInsertReqBc_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "amount", scope = SwiftInsertReq.class)
    public JAXBElement<BigDecimal> createSwiftInsertReqAmount(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_SwiftInsertReqAmount_QNAME, BigDecimal.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "f20_value", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqF20Value(String value) {
        return new JAXBElement<String>(_SwiftInsertReqF20Value_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "full_content", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqFullContent(String value) {
        return new JAXBElement<String>(_SwiftInsertReqFullContent_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "from_department", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqFromDepartment(String value) {
        return new JAXBElement<String>(_SwiftInsertReqFromDepartment_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "dept", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqDept(String value) {
        return new JAXBElement<String>(_SwiftInsertReqDept_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "type", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqType(String value) {
        return new JAXBElement<String>(_SwiftInsertReqType_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "suffix", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqSuffix(String value) {
        return new JAXBElement<String>(_SwiftInsertReqSuffix_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "document_id", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqDocumentId(String value) {
        return new JAXBElement<String>(_SwiftInsertReqDocumentId_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "created_by", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqCreatedBy(String value) {
        return new JAXBElement<String>(_SwiftInsertReqCreatedBy_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "f21_value", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqF21Value(String value) {
        return new JAXBElement<String>(_SwiftInsertReqF21Value_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "sender", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqSender(String value) {
        return new JAXBElement<String>(_SwiftInsertReqSender_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "currency", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqCurrency(String value) {
        return new JAXBElement<String>(_SwiftInsertReqCurrency_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "id", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqId(String value) {
        return new JAXBElement<String>(_SwiftInsertReqId_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "created_date", scope = SwiftInsertReq.class)
    public JAXBElement<XMLGregorianCalendar> createSwiftInsertReqCreatedDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_SwiftInsertReqCreatedDate_QNAME, XMLGregorianCalendar.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "bankname", scope = SwiftInsertReq.class)
    public JAXBElement<String> createSwiftInsertReqBankname(String value) {
        return new JAXBElement<String>(_SwiftInsertReqBankname_QNAME, String.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link XMLGregorianCalendar }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "value_date", scope = SwiftInsertReq.class)
    public JAXBElement<XMLGregorianCalendar> createSwiftInsertReqValueDate(XMLGregorianCalendar value) {
        return new JAXBElement<XMLGregorianCalendar>(_SwiftInsertReqValueDate_QNAME, XMLGregorianCalendar.class, SwiftInsertReq.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link BigDecimal }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "status", scope = SwiftInsertReq.class)
    public JAXBElement<BigDecimal> createSwiftInsertReqStatus(BigDecimal value) {
        return new JAXBElement<BigDecimal>(_SwiftInsertReqStatus_QNAME, BigDecimal.class, SwiftInsertReq.class, value);
    }

}
