package vn.techcombank.rem;

import org.apache.log4j.Logger;

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.nio.charset.Charset;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.ArrayBlockingQueue;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.atomic.AtomicInteger;

public class SwiftProducer extends Thread {
    final static Logger logger = Logger.getLogger("log1");
    final static Logger loggerParser = Logger.getLogger("parser");
    private static AtomicInteger count = new AtomicInteger(0);
    private final BlockingQueue fileQueue;


    private Path eventPath;
    private WatchService watcher;

    public static Properties prop;

    static {
        InputStream is = null;
        try {
            prop = new Properties();
            is = new FileInputStream("SwiftPoll.properties");
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    static final String eventDir = prop.getProperty("eventDir");
    static final String successDir = prop.getProperty("successDir");
    static final String failDir = prop.getProperty("failDir");
    static final String ecmDir = prop.getProperty("ecmDir");
    static final String backupDir = prop.getProperty("backupDir");
    static final String newFiLink = prop.getProperty("newFiLink");
    static final String newKhLink = prop.getProperty("newKhLink");
    static final String mailFrom = prop.getProperty("mailFrom");
    static final String newFiMailTo = prop.getProperty("newFiMailTo");
    static final String newKhMailTo = prop.getProperty("newKhMailTo");
    static final String duplicateMailTo = prop.getProperty("duplicateMailTo");
    protected static final String cloneToEcmDepts = prop.getProperty("cloneToEcmDepts") == null ? "" : prop.getProperty("cloneToEcmDepts").trim();
    protected static final String truststore = prop.getProperty("truststore");
    private static ServerSocket socket = null;
    static Map<String, String> cloneDepsMap = new HashMap<>();

    static {
        List<String> cloneDeps = Arrays.asList(cloneToEcmDepts.split(","));
        cloneDeps.forEach(s -> cloneDepsMap.put(s, s));
    }

    static final int TIME_TO_SLEEP_AFTER_CREATE = 2000;


    SwiftProducer(String path, BlockingQueue fileQueue) {
        this.fileQueue = fileQueue;
        try {
            eventPath = Paths.get(path);
            watcher = eventPath.getFileSystem().newWatchService();
            eventPath.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void rename(Path path) {
        try {
            Thread.sleep(TIME_TO_SLEEP_AFTER_CREATE);
            Files.move(path, Paths.get(eventDir, path.getFileName().toString() + LocalDateTime.now().format(DateTimeFormatter.ofPattern(SwiftMessage.FILE_DATETIME_PATTERN))));
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
    }

    private void renameRemoveNonASCII(Path path) {
        try {
            Thread.sleep(TIME_TO_SLEEP_AFTER_CREATE);
            Files.move(path, Paths.get(eventDir, path.getFileName().toString().replaceAll("[^\\p{ASCII}]", "").replace("  ", "")));
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            logger.error(e.getMessage());
        }
    }

    private boolean exists(Path path) {
        return Files.exists(Paths.get(backupDir, path.getFileName().toString()));
    }


    public void run() {
        try {
            if (!Files.exists(Paths.get(SwiftProducer.eventDir))) Files.createDirectories(Paths.get(eventDir));
            if (!Files.exists(Paths.get(SwiftProducer.successDir))) Files.createDirectories(Paths.get(successDir));
            if (!Files.exists(Paths.get(SwiftProducer.failDir))) Files.createDirectories(Paths.get(failDir));
            if (!Files.exists(Paths.get(SwiftProducer.ecmDir))) Files.createDirectories(Paths.get(ecmDir));
            if (!Files.exists(Paths.get(SwiftProducer.backupDir))) Files.createDirectories(Paths.get(backupDir));
        } catch (IOException e) {
            e.printStackTrace();
            logger.error(e);
        }
        try {
            Files.list(new File(eventPath.toString()).toPath())
                    .forEach(path -> {
                        doOneFile(path);
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {
            try {
                WatchKey watchKey = watcher.take();
                List<WatchEvent<?>> events = watchKey.pollEvents();
                for (WatchEvent<?> event : events) {
//                    if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
                    String newFileName = event.context().toString();
                    Path path = Paths.get(eventDir, newFileName);
                    doOneFile(path);
//                    }
                }
                watchKey.reset();
            } catch (Exception e) {
                logger.error("Error: " + e.toString());
            }
        }
    }

    private void doOneFile(Path path) {
        if (!Charset.forName("US-ASCII").newEncoder().canEncode(path.getFileName().toString()))
            renameRemoveNonASCII(path);
        else if (exists(path)) rename(path);
        else {
            logger.info(count.incrementAndGet() + " Created: " + path.getFileName().toString());
            fileQueue.add(path.getFileName().toString());
            logger.info("QUEUE SIZE:" + fileQueue.size());
        }
    }

    public static void main(String args[]) {
        logger.info("test1");
        loggerParser.info("test2");
        try {
            socket =
                    new ServerSocket(Integer.parseInt(prop.getProperty("localPort")), 10, InetAddress.getLocalHost());

        } catch (java.net.BindException b) {
            logger.error("Already Running...");
            System.exit(1);
        } catch (Exception e) {
            logger.error(e.toString());
        }
        System.setProperty("javax.net.ssl.trustStore", prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", prop.getProperty("trustStorePassword"));
//        SSLUtilities.trustAllHostnames();
        BlockingQueue fileQueue = new ArrayBlockingQueue(1024 * 10);
        new SwiftProducer(eventDir, fileQueue).start();
        new SwiftConsumer(fileQueue).start();
        logger.info("SwiftProducer is running!");
    }
}