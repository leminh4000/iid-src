
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for classifyMessageResponse complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="classifyMessageResponse">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="oResultArr" type="{http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow}resultClassifyMessageArr" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "classifyMessageResponse", propOrder = {
    "oResultArr"
})
public class ClassifyMessageResponse {

    protected ResultClassifyMessageArr oResultArr;

    /**
     * Gets the value of the oResultArr property.
     * 
     * @return
     *     possible object is
     *     {@link ResultClassifyMessageArr }
     *     
     */
    public ResultClassifyMessageArr getOResultArr() {
        return oResultArr;
    }

    /**
     * Sets the value of the oResultArr property.
     * 
     * @param value
     *     allowed object is
     *     {@link ResultClassifyMessageArr }
     *     
     */
    public void setOResultArr(ResultClassifyMessageArr value) {
        this.oResultArr = value;
    }

}
