
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for classifyMessageRequest complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="classifyMessageRequest">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="iInputInforArr" type="{http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow}inputClassifyMessageArr" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "classifyMessageRequest", propOrder = {
    "iInputInforArr"
})
public class ClassifyMessageRequest {

    protected InputClassifyMessageArr iInputInforArr;

    /**
     * Gets the value of the iInputInforArr property.
     * 
     * @return
     *     possible object is
     *     {@link InputClassifyMessageArr }
     *     
     */
    public InputClassifyMessageArr getIInputInforArr() {
        return iInputInforArr;
    }

    /**
     * Sets the value of the iInputInforArr property.
     * 
     * @param value
     *     allowed object is
     *     {@link InputClassifyMessageArr }
     *     
     */
    public void setIInputInforArr(InputClassifyMessageArr value) {
        this.iInputInforArr = value;
    }

}
