
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="cMRuleRequest" type="{http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow}classifyMessageRequest"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "cmRuleRequest"
})
@XmlRootElement(name = "cMRuleRequest", namespace = "http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow/param")
public class CMRuleRequest {

    @XmlElement(name = "cMRuleRequest", required = true)
    protected ClassifyMessageRequest cmRuleRequest;

    /**
     * Gets the value of the cmRuleRequest property.
     * 
     * @return
     *     possible object is
     *     {@link ClassifyMessageRequest }
     *     
     */
    public ClassifyMessageRequest getCMRuleRequest() {
        return cmRuleRequest;
    }

    /**
     * Sets the value of the cmRuleRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link ClassifyMessageRequest }
     *     
     */
    public void setCMRuleRequest(ClassifyMessageRequest value) {
        this.cmRuleRequest = value;
    }

}
