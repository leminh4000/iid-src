
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="DecisionID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0" form="qualified"/>
 *         &lt;element ref="{http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow/param}cMRuleRequest"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "decisionID",
    "cmRuleRequest"
})
@XmlRootElement(name = "DetermineClassifyMessageFlowRequest")
public class DetermineClassifyMessageFlowRequest {

    @XmlElement(name = "DecisionID", namespace = "http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow")
    protected String decisionID;
    @XmlElement(name = "cMRuleRequest", namespace = "http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow/param", required = true)
    protected CMRuleRequest cmRuleRequest;

    /**
     * Gets the value of the decisionID property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDecisionID() {
        return decisionID;
    }

    /**
     * Sets the value of the decisionID property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDecisionID(String value) {
        this.decisionID = value;
    }

    /**
     * Gets the value of the cmRuleRequest property.
     * 
     * @return
     *     possible object is
     *     {@link CMRuleRequest }
     *     
     */
    public CMRuleRequest getCMRuleRequest() {
        return cmRuleRequest;
    }

    /**
     * Sets the value of the cmRuleRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link CMRuleRequest }
     *     
     */
    public void setCMRuleRequest(CMRuleRequest value) {
        this.cmRuleRequest = value;
    }

}
