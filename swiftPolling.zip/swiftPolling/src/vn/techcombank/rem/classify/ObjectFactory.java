
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.techcombank.rem.classify package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.techcombank.rem.classify
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CMRuleRequest }
     * 
     */
    public CMRuleRequest createCMRuleRequest() {
        return new CMRuleRequest();
    }

    /**
     * Create an instance of {@link ClassifyMessageRequest }
     * 
     */
    public ClassifyMessageRequest createClassifyMessageRequest() {
        return new ClassifyMessageRequest();
    }

    /**
     * Create an instance of {@link CMRuleResponse }
     * 
     */
    public CMRuleResponse createCMRuleResponse() {
        return new CMRuleResponse();
    }

    /**
     * Create an instance of {@link ClassifyMessageResponse }
     * 
     */
    public ClassifyMessageResponse createClassifyMessageResponse() {
        return new ClassifyMessageResponse();
    }

    /**
     * Create an instance of {@link DetermineClassifyMessageFlowRequest }
     * 
     */
    public DetermineClassifyMessageFlowRequest createDetermineClassifyMessageFlowRequest() {
        return new DetermineClassifyMessageFlowRequest();
    }

    /**
     * Create an instance of {@link DetermineClassifyMessageFlowResponse }
     * 
     */
    public DetermineClassifyMessageFlowResponse createDetermineClassifyMessageFlowResponse() {
        return new DetermineClassifyMessageFlowResponse();
    }

    /**
     * Create an instance of {@link DetermineClassifyMessageFlowException }
     * 
     */
    public DetermineClassifyMessageFlowException createDetermineClassifyMessageFlowException() {
        return new DetermineClassifyMessageFlowException();
    }

    /**
     * Create an instance of {@link InputClassifyMessageArr }
     * 
     */
    public InputClassifyMessageArr createInputClassifyMessageArr() {
        return new InputClassifyMessageArr();
    }

    /**
     * Create an instance of {@link ResultClassifyMessage }
     * 
     */
    public ResultClassifyMessage createResultClassifyMessage() {
        return new ResultClassifyMessage();
    }

    /**
     * Create an instance of {@link ResultClassifyMessageArr }
     * 
     */
    public ResultClassifyMessageArr createResultClassifyMessageArr() {
        return new ResultClassifyMessageArr();
    }

    /**
     * Create an instance of {@link InputClassifyMessage }
     * 
     */
    public InputClassifyMessage createInputClassifyMessage() {
        return new InputClassifyMessage();
    }

}
