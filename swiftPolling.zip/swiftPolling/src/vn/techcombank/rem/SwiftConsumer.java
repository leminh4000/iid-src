package vn.techcombank.rem;

import org.apache.log4j.Logger;

import java.io.*;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.CopyOnWriteArraySet;
import java.util.concurrent.atomic.AtomicInteger;

public class SwiftConsumer extends Thread {
    final static Logger logger = Logger.getLogger("log1");
    private static AtomicInteger count = new AtomicInteger(0);
    private final BlockingQueue fileQueue;

    SwiftConsumer(BlockingQueue fileQueue) {
        this.fileQueue = fileQueue;
    }
    public void run() {
        while (true) {
            if (fileQueue.size() > 0) {
                logger.info("QUEUE SIZE:" + fileQueue.size());
                String newFileName = null;
                try {
                    newFileName = (String) fileQueue.take();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    logger.error(e.getMessage());
                }
                logger.info(count.incrementAndGet() + " | Consume: " + newFileName);
                Path path = Paths.get(SwiftProducer.eventDir, newFileName);
                doOneFile(path);
            } else {
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    logger.error(e.getMessage());
                }
            }
        }
    }

    static synchronized void doOneFile(Path path) {
        SwiftMessage swiftMessage = new SwiftMessage(path, SwiftProducer.cloneDepsMap);
        swiftMessage.process();
    }

}