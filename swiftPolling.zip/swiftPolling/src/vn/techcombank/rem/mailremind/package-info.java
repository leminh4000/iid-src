@javax.xml.bind.annotation.XmlSchema(namespace = "http://Swift_Polling_Email_Reminder_Module")
package vn.techcombank.rem.mailremind;
