
package vn.techcombank.rem.sendmail;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for SendEmailTemplateReq complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="SendEmailTemplateReq">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="emailRequest" type="{http://BBSESTK}EmailRequest" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "SendEmailTemplateReq", propOrder = {
    "emailRequest"
})
public class SendEmailTemplateReq {

    protected EmailRequest emailRequest;

    /**
     * Gets the value of the emailRequest property.
     * 
     * @return
     *     possible object is
     *     {@link EmailRequest }
     *     
     */
    public EmailRequest getEmailRequest() {
        return emailRequest;
    }

    /**
     * Sets the value of the emailRequest property.
     * 
     * @param value
     *     allowed object is
     *     {@link EmailRequest }
     *     
     */
    public void setEmailRequest(EmailRequest value) {
        this.emailRequest = value;
    }

}
