
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for inputClassifyMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="inputClassifyMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="currency" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f20" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f21" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f52" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f57A" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f57D" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f70" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f72" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="f79" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="sender" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeSwift" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "inputClassifyMessage", propOrder = {
    "currency",
    "f20",
    "f21",
    "f52",
    "f57A",
    "f57D",
    "f70",
    "f72",
    "f79",
    "sender",
    "typeSwift"
})
public class InputClassifyMessage {

    protected String currency;
    protected String f20;
    protected String f21;
    protected String f52;
    protected String f57A;
    protected String f57D;
    protected String f70;
    protected String f72;
    protected String f79;
    protected String sender;
    protected String typeSwift;

    /**
     * Gets the value of the currency property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getCurrency() {
        return currency;
    }

    /**
     * Sets the value of the currency property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setCurrency(String value) {
        this.currency = value;
    }

    /**
     * Gets the value of the f20 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF20() {
        return f20;
    }

    /**
     * Sets the value of the f20 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF20(String value) {
        this.f20 = value;
    }

    /**
     * Gets the value of the f21 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF21() {
        return f21;
    }

    /**
     * Sets the value of the f21 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF21(String value) {
        this.f21 = value;
    }

    /**
     * Gets the value of the f52 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF52() {
        return f52;
    }

    /**
     * Sets the value of the f52 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF52(String value) {
        this.f52 = value;
    }

    /**
     * Gets the value of the f57A property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF57A() {
        return f57A;
    }

    /**
     * Sets the value of the f57A property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF57A(String value) {
        this.f57A = value;
    }

    /**
     * Gets the value of the f57D property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF57D() {
        return f57D;
    }

    /**
     * Sets the value of the f57D property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF57D(String value) {
        this.f57D = value;
    }

    /**
     * Gets the value of the f70 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF70() {
        return f70;
    }

    /**
     * Sets the value of the f70 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF70(String value) {
        this.f70 = value;
    }

    /**
     * Gets the value of the f72 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF72() {
        return f72;
    }

    /**
     * Sets the value of the f72 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF72(String value) {
        this.f72 = value;
    }

    /**
     * Gets the value of the f79 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getF79() {
        return f79;
    }

    /**
     * Sets the value of the f79 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setF79(String value) {
        this.f79 = value;
    }

    /**
     * Gets the value of the sender property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSender() {
        return sender;
    }

    /**
     * Sets the value of the sender property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSender(String value) {
        this.sender = value;
    }

    /**
     * Gets the value of the typeSwift property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeSwift() {
        return typeSwift;
    }

    /**
     * Sets the value of the typeSwift property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeSwift(String value) {
        this.typeSwift = value;
    }

}
