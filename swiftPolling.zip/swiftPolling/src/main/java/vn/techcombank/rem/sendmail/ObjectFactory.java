
package vn.techcombank.rem.sendmail;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the vn.techcombank.rem.sendmail package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: vn.techcombank.rem.sendmail
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Invoke }
     * 
     */
    public Invoke createInvoke() {
        return new Invoke();
    }

    /**
     * Create an instance of {@link SendEmailTemplateReq }
     * 
     */
    public SendEmailTemplateReq createSendEmailTemplateReq() {
        return new SendEmailTemplateReq();
    }

    /**
     * Create an instance of {@link InvokeResponse }
     * 
     */
    public InvokeResponse createInvokeResponse() {
        return new InvokeResponse();
    }

    /**
     * Create an instance of {@link EmailResponseBO }
     * 
     */
    public EmailResponseBO createEmailResponseBO() {
        return new EmailResponseBO();
    }

    /**
     * Create an instance of {@link TemplateContentBO }
     * 
     */
    public TemplateContentBO createTemplateContentBO() {
        return new TemplateContentBO();
    }

    /**
     * Create an instance of {@link HeaderInfo }
     * 
     */
    public HeaderInfo createHeaderInfo() {
        return new HeaderInfo();
    }

    /**
     * Create an instance of {@link Header }
     * 
     */
    public Header createHeader() {
        return new Header();
    }

    /**
     * Create an instance of {@link StatusInfo }
     * 
     */
    public StatusInfo createStatusInfo() {
        return new StatusInfo();
    }

    /**
     * Create an instance of {@link MailAttachment }
     * 
     */
    public MailAttachment createMailAttachment() {
        return new MailAttachment();
    }

    /**
     * Create an instance of {@link EmailRequest }
     * 
     */
    public EmailRequest createEmailRequest() {
        return new EmailRequest();
    }

    /**
     * Create an instance of {@link KeyValueRequest }
     * 
     */
    public KeyValueRequest createKeyValueRequest() {
        return new KeyValueRequest();
    }

}
