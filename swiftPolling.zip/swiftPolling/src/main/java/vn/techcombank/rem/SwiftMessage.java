package vn.techcombank.rem;

import com.sun.xml.internal.ws.client.BindingProviderProperties;
import org.apache.log4j.Logger;
import org.json.JSONObject;
import vn.techcombank.rem.classify.*;
import vn.techcombank.rem.insertswift.*;
import vn.techcombank.rem.insertswift.ObjectFactory;
import vn.techcombank.rem.sendmail.*;

import javax.net.ssl.*;
import javax.xml.datatype.XMLGregorianCalendar;
import javax.xml.ws.BindingProvider;
import java.io.IOException;
import java.math.BigDecimal;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.security.cert.CertificateException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Map;

public class SwiftMessage {
    final static Logger logger = Logger.getLogger(SwiftMessage.class);
    public static final String TTTMNK = "TTTMNK";
    public static final String TTTMXK = "TTTMXK";
    private final Map<String, String> cloneDepsMap;
    private final String FILE_DATETIME_PATTERN = "-yyyy-MM-dd-HH-mm-ss";

    private Path path;
    private String fileName;
    private String fin;

    SwiftMessage(Path path, Map<String, String> cloneDepsMap) {
        this.path = path;
        this.cloneDepsMap = cloneDepsMap;
    }

    public static void trustAllHosts() {
        try {
            TrustManager[] trustAllCerts = new TrustManager[]{
                    new X509ExtendedTrustManager() {
                        @Override
                        public java.security.cert.X509Certificate[] getAcceptedIssuers() {
                            return null;
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] certs, String authType) {
                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, Socket socket) throws CertificateException {

                        }

                        @Override
                        public void checkClientTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                        @Override
                        public void checkServerTrusted(java.security.cert.X509Certificate[] xcs, String string, SSLEngine ssle) throws CertificateException {

                        }

                    }
            };

            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustAllCerts, new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            // Create all-trusting host name verifier
            HostnameVerifier allHostsValid = new HostnameVerifier() {
                @Override
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            // Install the all-trusting host verifier
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    void process() {
//        trustAllHosts();
        String fin = "";
        String fileName = path.getFileName().toString();
        SwiftInsertResp insertResp = null;
        try {
            backupFile(fileName);
        } catch (IOException e) {
            e.printStackTrace();
            logger.error(e);
        }
        try {
            fin = new String(Files.readAllBytes(path));
            SwiftHelper swiftHelper = new SwiftHelper(fin, fileName);
            logger.info("F20 = " + swiftHelper.getF20());

            ResultClassifyMessage classify = getClassify(swiftHelper);

//            if (classify.getDepartment01().equals(TTTMNK) || classify.getDepartment01().equals(TTTMXK)) {
            if (cloneDepsMap.containsKey(classify.getDepartment01())) {
                logger.info("Coping file to ECM folder");
                Files.copy(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.ecmDir, fileName), StandardCopyOption.REPLACE_EXISTING);
                logger.info("File has been copied");
            }
            logger.info("Calling Insert Swift service");
            insertResp = insert(swiftHelper, classify.getDepartment01(), classify.getDepartment02());
            logger.info("Call Insert Swift service success");
            logger.info("Copied file " + fileName + " to backup folder");
            moveFile(fileName, insertResp);
        } catch (Exception e) {
            logger.error(e);
            e.printStackTrace();
            logger.error("ERROR!!!!!!!!!!!!!!!!!!!!Sending email...");
            try {
                sendErrorMail(path, fin);
            } catch (Exception e2) {
                logger.error(e2);
                e2.printStackTrace();
                try {
                    sendErrorMail(path, fin.substring(100));
                } catch (Exception e3) {
                    logger.error(e3);
                    e3.printStackTrace();
                }
            }
            logger.error("Sent email for error fin " + path.getFileName().toString());
            try {
                moveToFail(fileName);
            } catch (IOException e1) {
                logger.error(e1);
                e1.printStackTrace();
            }
        }
        logger.info(".");
    }

    private void moveFile(String fileName, SwiftInsertResp insertResp) throws IOException {
        if (insertResp == null || insertResp.getId() == null) {
            moveToFail(fileName);
        } else {
            moveToSuccess(fileName);
        }
    }

    private void moveToSuccess(String fileName) throws IOException {
        if (!Files.exists(Paths.get(FinFolderPolling.successDir, fileName)))
            Files.move(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.successDir, fileName), StandardCopyOption.REPLACE_EXISTING);
        else
            Files.move(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.successDir, fileName + LocalDateTime.now().format(DateTimeFormatter.ofPattern(FILE_DATETIME_PATTERN))), StandardCopyOption.REPLACE_EXISTING);

        logger.info("Moved file " + fileName + " to success folder");
    }

    private void moveToFail(String fileName) throws IOException {
        if (Files.exists(Paths.get(FinFolderPolling.eventDir, fileName))) {
            if (!Files.exists(Paths.get(FinFolderPolling.failDir, fileName)))
                Files.move(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.failDir, fileName), StandardCopyOption.REPLACE_EXISTING);
            else
                Files.move(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.failDir, fileName + LocalDateTime.now().format(DateTimeFormatter.ofPattern(FILE_DATETIME_PATTERN))), StandardCopyOption.REPLACE_EXISTING);
            logger.error("Move file " + fileName + " to fail folder");
        }
    }

    private void backupFile(String fileName) throws IOException {
        if (Files.exists(Paths.get(FinFolderPolling.eventDir, fileName)))
            if (!Files.exists(Paths.get(FinFolderPolling.backupDir, fileName)))
                Files.copy(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.backupDir, fileName), StandardCopyOption.REPLACE_EXISTING);
            else
                Files.copy(Paths.get(FinFolderPolling.eventDir, fileName), Paths.get(FinFolderPolling.backupDir, fileName + LocalDateTime.now().format(DateTimeFormatter.ofPattern(FILE_DATETIME_PATTERN))), StandardCopyOption.REPLACE_EXISTING);
    }

    private SwiftInsertResp insert(SwiftHelper swiftHelper, String department01, String department02) {
//        SSLUtilities.trustAllHttpsCertificates();
        InsertSwiftExport1InsertSwiftHttpService service = new InsertSwiftExport1InsertSwiftHttpService();
        InsertSwift port = service.getInsertSwiftExport1InsertSwiftHttpPort();
        SwiftInsertReq req = new SwiftInsertReq();
        vn.techcombank.rem.insertswift.ObjectFactory objectFactory = new ObjectFactory();
        req.setAmount(objectFactory.createSwiftInsertReqAmount(swiftHelper.getAmount()));
        req.setReadable(swiftHelper.getReadable());
        req.setType(objectFactory.createSwiftInsertReqType(swiftHelper.getType()));
        req.setCurrency(objectFactory.createSwiftInsertReqCurrency(swiftHelper.getCurrency()));
        req.setDept(objectFactory.createSwiftInsertReqDept(department01));
        req.setDept2(department02);
        req.setSwiftId(swiftHelper.getSwiftId());
        req.setF20Value(objectFactory.createSwiftInsertReqF20Value(swiftHelper.getF20()));
        req.setF53A(swiftHelper.getF53a());
        req.setF54A(swiftHelper.getF54a());
        req.setF72(swiftHelper.getF72());
        req.setF21Value(objectFactory.createSwiftInsertReqF21Value(swiftHelper.getF21()));
        req.setFin(swiftHelper.getFin());
        req.setFullContent(objectFactory.createSwiftInsertReqFullContent(swiftHelper.getReadableJson()));
        req.setFileName(swiftHelper.getFileName());
        req.setLinkNewFI(FinFolderPolling.newFiLink);
        req.setLinkReminderNewKhdvkh(FinFolderPolling.newKhLink);
        req.setDuplicateMailTo(FinFolderPolling.duplicateMailTo);
        req.setMailFrom(FinFolderPolling.mailFrom);
        req.setNewFiMailTo(FinFolderPolling.newFiMailTo);
        req.setNewKhMailTo(FinFolderPolling.newKhMailTo);
        req.setReceiver(swiftHelper.getReceiver());
        req.setSender(objectFactory.createSwiftInsertReqSender(swiftHelper.getSender()));
        req.setStatus(objectFactory.createSwiftInsertReqStatus(BigDecimal.valueOf(0)));
        XMLGregorianCalendar xmlGregorianCalendar = null;
        Date date = swiftHelper.getValue_date();
        if (swiftHelper.getValue_date() != null) {
            xmlGregorianCalendar = DateHelper.getXmlGregorianCalendar(date);
            req.setValueDate(objectFactory.createSwiftInsertReqValueDate(xmlGregorianCalendar));
        }
        /*try {
            req.setCreatedDate(objectFactory.createSwiftInsertReqCreatedDate(DatatypeFactory.newInstance().newXMLGregorianCalendar(LocalDate.now().toString())));
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }*/
        ((BindingProvider) port).getRequestContext().put(BindingProviderProperties.REQUEST_TIMEOUT, -1);
        /*Map requestContext = ((BindingProvider) port).getRequestContext();
        requestContext.put(JAXWSProperties.CONNECT_TIMEOUT, 300000);
        requestContext.put(JAXWSProperties.REQUEST_TIMEOUT, 300000);*/

        SwiftInsertResp resp = port.operation1(req);
        logger.info("Inserted Swift message have id " + resp.getId() + "," + resp.getId2());
        return resp;
    }

    private void sendErrorMail(Path path, String fin) {
        java.util.List<String> headers = java.util.Arrays.asList("STT", "Nội dung điện", "Tên file");
        java.util.List<java.util.List<String>> data = java.util.Arrays.asList(java.util.Arrays.asList("1", fin, path.getFileName().toString()));
        String tableErrorSwift = HtmlHelper.buildTable(headers, data);

        SendEmailTemplateExportSendEmailServiceAISHttpService service = new SendEmailTemplateExportSendEmailServiceAISHttpService();
        SendEmailServiceAIS port = service.getSendEmailTemplateExportSendEmailServiceAISHttpPort();
        SendEmailTemplateReq sendTemplateEmailReq = new SendEmailTemplateReq();
        EmailRequest emailRequest = new EmailRequest();
        sendTemplateEmailReq.setEmailRequest(emailRequest);
        emailRequest.setTo(FinFolderPolling.duplicateMailTo);
        emailRequest.setFrom(FinFolderPolling.mailFrom);
        TemplateContentBO templateContent = new TemplateContentBO();
        KeyValueRequest keyValueRequest = new KeyValueRequest();
        keyValueRequest.setKey("table");
        keyValueRequest.setValue(tableErrorSwift);
        templateContent.getKeyValueReq().add(keyValueRequest);
        emailRequest.setTemplateContent(templateContent);
        port.invoke(sendTemplateEmailReq);
    }

    private ResultClassifyMessage getClassify(SwiftHelper swiftHelper) throws DetermineClassifyMessageFlowSoapFault {
        DetermineClassifyMessageFlowDecisionService_Service service = new DetermineClassifyMessageFlowDecisionService_Service();
        DetermineClassifyMessageFlowDecisionService port = service.getRMINClassifyMessageDetermineClassifyMessageFlowPort();
        DetermineClassifyMessageFlowRequest request = new DetermineClassifyMessageFlowRequest();
        CMRuleRequest cmRuleRequest = new CMRuleRequest();
        ClassifyMessageRequest classifyMessageRequest = new ClassifyMessageRequest();
        InputClassifyMessageArr inputClassifyMessageArr = new InputClassifyMessageArr();
        InputClassifyMessage inputClassifyMessage = new InputClassifyMessage();
        inputClassifyMessage.setF20(swiftHelper.getF20());
        inputClassifyMessage.setCurrency(swiftHelper.getCurrency());
        inputClassifyMessage.setF21(swiftHelper.getF21());
        inputClassifyMessage.setF52(swiftHelper.getF52d());
        inputClassifyMessage.setF57A(swiftHelper.getF57a());
        inputClassifyMessage.setF57D(swiftHelper.getF57d());
        inputClassifyMessage.setF70(swiftHelper.getF70());
        inputClassifyMessage.setF72(swiftHelper.getF72());
        inputClassifyMessage.setF79(swiftHelper.getF79());
        inputClassifyMessage.setSender(swiftHelper.getSender());
        inputClassifyMessage.setTypeSwift(swiftHelper.getType());

        inputClassifyMessageArr.getInputSwiftMessagersArr().add(inputClassifyMessage);

        classifyMessageRequest.setIInputInforArr(inputClassifyMessageArr);
        cmRuleRequest.setCMRuleRequest(classifyMessageRequest);
        request.setCMRuleRequest(cmRuleRequest);
        logger.info("Classify Req =" + new JSONObject(request).toString());
        DetermineClassifyMessageFlowResponse response = port.determineClassifyMessageFlow(request);
        logger.info("Classify Resp =" + new JSONObject(response).toString());
        return response.getCMRuleResponse().getCMRuleResponse().getOResultArr().getResultSwiftMessagersArr().get(0);
    }

}
