
package vn.techcombank.rem.mailremind;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fi4hRemindResp" type="{http://Swift_Polling_Email_Reminder_Module}Fi4hRemindResp"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fi4HRemindResp"
})
@XmlRootElement(name = "invokeResponse", namespace = "http://Swift_Polling_Email_Reminder_Module/Fi4hRemindService")
public class InvokeResponse {

    @XmlElement(name = "fi4hRemindResp", required = true, nillable = true)
    protected Fi4HRemindResp fi4HRemindResp;

    /**
     * Gets the value of the fi4HRemindResp property.
     * 
     * @return
     *     possible object is
     *     {@link Fi4HRemindResp }
     *     
     */
    public Fi4HRemindResp getFi4HRemindResp() {
        return fi4HRemindResp;
    }

    /**
     * Sets the value of the fi4HRemindResp property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fi4HRemindResp }
     *     
     */
    public void setFi4HRemindResp(Fi4HRemindResp value) {
        this.fi4HRemindResp = value;
    }

}
