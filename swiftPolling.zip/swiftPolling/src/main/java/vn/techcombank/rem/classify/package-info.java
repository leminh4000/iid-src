@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ibm.com/rules/decisionservice/RMIN_ClassifyMessage/DetermineClassifyMessageFlow")
package vn.techcombank.rem.classify;
