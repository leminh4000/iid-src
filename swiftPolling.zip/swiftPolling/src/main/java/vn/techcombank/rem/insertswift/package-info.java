@javax.xml.bind.annotation.XmlSchema(namespace = "http://Swift_Lib/InsertSwift")
package vn.techcombank.rem.insertswift;
