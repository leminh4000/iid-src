package vn.techcombank.rem;

import org.apache.log4j.Logger;
import org.quartz.*;
import org.quartz.impl.StdSchedulerFactory;
import vn.techcombank.rem.disableswift.Disable940950Req;
import vn.techcombank.rem.disableswift.Disable940950Service;
import vn.techcombank.rem.disableswift.Disable940950ServiceExport1Disable940950ServiceHttpService;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.Properties;

public class MailRemind {
    public static Properties prop;
    final static Logger logger = Logger.getLogger(MailRemind.class);

    static {
        InputStream is = null;
        try {
            prop = new Properties();
            is = new FileInputStream("MailRemind.properties");
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static ServerSocket socket = null;

    public static void main(String[] args) throws InterruptedException, SchedulerException {

        try{
            socket =
                    new ServerSocket(Integer.parseInt(prop.getProperty("localPort")), 10, InetAddress.getLocalHost());

        }catch(java.net.BindException b){
            System.out.println("Already Running...");
            System.exit(1);
        }catch(Exception e){
            System.out.println(e.toString());
        }
        /*while (true) {
            doOne();
            Thread.sleep(100000);
        }*/

        System.setProperty("javax.net.ssl.trustStore", prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", prop.getProperty("trustStorePassword"));

        /*JobDetail fi4hjob = JobBuilder.newJob(MailRemindFi4hJob.class)
                .withIdentity("Fi4h", "group1").build();

        JobDetail wb1hjob = JobBuilder.newJob(MailRemindWb1hJob.class)
                .withIdentity("Wb1h", "group1").build();


        Trigger fi4htrigger = TriggerBuilder
                .newTrigger()
                .withIdentity("Fi4h", "group1")
                .withSchedule(
                        SimpleScheduleBuilder.simpleSchedule()
                                .withIntervalInSeconds(Integer.parseInt(MailRemind.prop.getProperty("fi4hIntervalInSecond"))).repeatForever())
                .build();
        Trigger wb1htrigger = TriggerBuilder
                .newTrigger()
                .withIdentity("Wb1h", "group1")
                .withSchedule(
                        SimpleScheduleBuilder.simpleSchedule()
                                .withIntervalInSeconds(Integer.parseInt(MailRemind.prop.getProperty("wb1hIntervalInSecond"))).repeatForever())
                .build();

        // schedule it
        Scheduler scheduler = new StdSchedulerFactory().getScheduler();
        scheduler.start();
        scheduler.scheduleJob(fi4hjob, fi4htrigger);
        scheduler.scheduleJob(wb1hjob, wb1htrigger);*/

        Thread mailRemindWb1hThread = new MailRemindWb1hThread();
        Thread mailRemindFi4hThread = new MailRemindFi4hThread();
        Thread disable940950Thread = new Disable940950Thread();
        mailRemindWb1hThread.start();
        mailRemindFi4hThread.start();
        disable940950Thread.start();
    }
    public static class MailRemindWb1hThread extends Thread{
        public MailRemindWb1hThread() {
            super();
        }
        public void run() {
            while (true){
                MailRemindWb1hJob.invoke();
                try {
                    Thread.sleep(Long.parseLong(MailRemind.prop.getProperty("wb1hIntervalInSecond"))*1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    public static class MailRemindFi4hThread extends Thread{
        public void run() {
            while (true){
                MailRemindFi4hJob.invoke();
                try {
                    Thread.sleep(Long.parseLong(MailRemind.prop.getProperty("fi4hIntervalInSecond"))*1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private static class Disable940950Thread extends Thread {
        public void run() {
            while (true){
                logger.info("Start Disable 940950");
                invoke();
                logger.info("Disable 940950 success");
                try {
                    Thread.sleep(Long.parseLong(MailRemind.prop.getProperty("disable940950IntervalInSecond"))*1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        private void invoke() {
            Disable940950ServiceExport1Disable940950ServiceHttpService service = new Disable940950ServiceExport1Disable940950ServiceHttpService();
            Disable940950Service port = service.getDisable940950ServiceExport1Disable940950ServiceHttpPort();
            Disable940950Req input1 = new Disable940950Req();
            input1.setDays(Integer.valueOf(MailRemind.prop.getProperty("disable940950Days")));
            port.operation1(input1);
        }
    }
}
