
package vn.techcombank.rem.classify;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for resultClassifyMessage complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="resultClassifyMessage">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="department01" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="department02" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="transaction" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="typeSwift" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "resultClassifyMessage", propOrder = {
    "department01",
    "department02",
    "transaction",
    "typeSwift"
})
public class ResultClassifyMessage {

    protected String department01;
    protected String department02;
    protected String transaction;
    protected String typeSwift;

    /**
     * Gets the value of the department01 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartment01() {
        return department01;
    }

    /**
     * Sets the value of the department01 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartment01(String value) {
        this.department01 = value;
    }

    /**
     * Gets the value of the department02 property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDepartment02() {
        return department02;
    }

    /**
     * Sets the value of the department02 property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDepartment02(String value) {
        this.department02 = value;
    }

    /**
     * Gets the value of the transaction property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTransaction() {
        return transaction;
    }

    /**
     * Sets the value of the transaction property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTransaction(String value) {
        this.transaction = value;
    }

    /**
     * Gets the value of the typeSwift property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTypeSwift() {
        return typeSwift;
    }

    /**
     * Sets the value of the typeSwift property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTypeSwift(String value) {
        this.typeSwift = value;
    }

}
