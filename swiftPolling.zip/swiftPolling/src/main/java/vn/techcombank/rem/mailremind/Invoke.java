
package vn.techcombank.rem.mailremind;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="fi4hRemindReq" type="{http://Swift_Polling_Email_Reminder_Module}Fi4hRemindReq"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "fi4HRemindReq"
})
@XmlRootElement(name = "invoke", namespace = "http://Swift_Polling_Email_Reminder_Module/Fi4hRemindService")
public class Invoke {

    @XmlElement(name = "fi4hRemindReq", required = true, nillable = true)
    protected Fi4HRemindReq fi4HRemindReq;

    /**
     * Gets the value of the fi4HRemindReq property.
     * 
     * @return
     *     possible object is
     *     {@link Fi4HRemindReq }
     *     
     */
    public Fi4HRemindReq getFi4HRemindReq() {
        return fi4HRemindReq;
    }

    /**
     * Sets the value of the fi4HRemindReq property.
     * 
     * @param value
     *     allowed object is
     *     {@link Fi4HRemindReq }
     *     
     */
    public void setFi4HRemindReq(Fi4HRemindReq value) {
        this.fi4HRemindReq = value;
    }

}
