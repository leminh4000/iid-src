package vn.techcombank.rem;

import vn.techcombank.rem.insertswift.ObjectFactory;
import vn.techcombank.rem.insertswift.SwiftInsertReq;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import javax.xml.datatype.XMLGregorianCalendar;
import java.util.Date;
import java.util.GregorianCalendar;

public class DateHelper {
    public static XMLGregorianCalendar getXmlGregorianCalendar(Date date) {
        try {
            GregorianCalendar c = new GregorianCalendar();
            c.setTime(date);
            return DatatypeFactory.newInstance().newXMLGregorianCalendar(c);
        } catch (DatatypeConfigurationException e) {
            e.printStackTrace();
        }
        return null;
    }
}
