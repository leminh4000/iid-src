package vn.techcombank.rem;

import org.apache.log4j.Logger;
import org.json.JSONObject;
import org.quartz.Job;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import vn.techcombank.rem.mailremind.Fi4HRemindReq;
import vn.techcombank.rem.mailremind.Fi4HRemindResp;
import vn.techcombank.rem.mailremind.Fi4HRemindService;
import vn.techcombank.rem.mailremind.Fi4HRemindServiceExport1Fi4HRemindServiceHttpService;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;

public class MailRemindFi4hJob implements Job
{
    final static Logger logger = Logger.getLogger(MailRemindFi4hJob.class);
    public void execute(JobExecutionContext context)
            throws JobExecutionException {
        invoke();

    }

    static void invoke() {
        try {
            Fi4HRemindServiceExport1Fi4HRemindServiceHttpService service = new Fi4HRemindServiceExport1Fi4HRemindServiceHttpService();
            Fi4HRemindService remindServiceHttpPort = service.getFi4HRemindServiceExport1Fi4HRemindServiceHttpPort();
            Fi4HRemindReq fi4HRemindReq = new Fi4HRemindReq();
            fi4HRemindReq.setCurrentDateTime(LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")).toString());
            fi4HRemindReq.setDept("FI");
            fi4HRemindReq.setFrom(MailRemind.prop.getProperty("fi4hMailFrom"));
            fi4HRemindReq.setTo(MailRemind.prop.getProperty("fi4hMailTo"));
            fi4HRemindReq.setLinkNewFI(MailRemind.prop.getProperty("newFiLink"));
            fi4HRemindReq.setTime(DateHelper.getXmlGregorianCalendar(new Date(System.currentTimeMillis() - (new Long(MailRemind.prop.getProperty("fi4hInSecond")).longValue() * 1000))));
            fi4HRemindReq.setStatus(0);
            logger.debug("Mail Fi 4h req = " + new JSONObject(fi4HRemindReq).toString());
            Fi4HRemindResp fi4HRemindResp = remindServiceHttpPort.invoke(fi4HRemindReq);
            logger.debug("Mail Fi 4h resp = " + (fi4HRemindResp == null ? "Null": new JSONObject(fi4HRemindResp).toString()));
        } catch (Exception e) {
            e.printStackTrace();
            logger.error(e);
        }
    }

    public static void main(String[] args) {
        logger.info(new Date(System.currentTimeMillis() - (new Long(MailRemind.prop.getProperty("fi4hInSecond")).longValue() * 1000)));
        logger.info(String.format("{\"SwiftID\":\"%s\"}", "V123"));
        JSONObject jsonObject = new JSONObject();
        logger.info(jsonObject.put("SwiftID", "V123").put("SwiftID2", "V1232").toString());
    }
}

