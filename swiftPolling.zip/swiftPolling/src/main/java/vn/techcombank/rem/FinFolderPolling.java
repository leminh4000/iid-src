package vn.techcombank.rem;

import org.apache.log4j.Logger;
import vn.techcombank.rem.classify.*;
import vn.techcombank.rem.insertswift.ObjectFactory;
import vn.techcombank.rem.insertswift.*;
import vn.techcombank.rem.sendmail.*;

import javax.xml.datatype.DatatypeConfigurationException;
import javax.xml.datatype.DatatypeFactory;
import java.io.*;
import java.math.BigDecimal;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.nio.file.*;
import java.time.LocalDate;
import java.util.*;

public class FinFolderPolling extends Thread {
    final static Logger logger = Logger.getLogger(FinFolderPolling.class);


    private Path eventPath;
    private WatchService watcher;

    public static Properties prop;

    static {
        InputStream is = null;
        try {
            prop = new Properties();
            is = new FileInputStream("SwiftPoll.properties");
            prop.load(is);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static final int PAUSE_INTERVAL = 1000;
    static final String eventDir = prop.getProperty("eventDir");
    static final String successDir = prop.getProperty("successDir");
    static final String failDir = prop.getProperty("failDir");
    static final String ecmDir = prop.getProperty("ecmDir");
    static final String backupDir = prop.getProperty("backupDir");
    static final String newFiLink = prop.getProperty("newFiLink");
    static final String newKhLink = prop.getProperty("newKhLink");
    static final String mailFrom = prop.getProperty("mailFrom");
    static final String newFiMailTo = prop.getProperty("newFiMailTo");
    static final String newKhMailTo = prop.getProperty("newKhMailTo");
    static final String duplicateMailTo = prop.getProperty("duplicateMailTo");
    protected static final String cloneToEcmDepts = prop.getProperty("cloneToEcmDepts") == null ? "" : prop.getProperty("cloneToEcmDepts").trim();
    protected static final String truststore = prop.getProperty("truststore");
    private static ServerSocket socket = null;


    FinFolderPolling(String path) {
        try {
            eventPath = Paths.get(path);
            watcher = eventPath.getFileSystem().newWatchService();
            eventPath.register(watcher, StandardWatchEventKinds.ENTRY_CREATE);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    public void run() {
        try {
            if (!Files.exists(Paths.get(FinFolderPolling.eventDir))) Files.createDirectories(Paths.get(eventDir));
            if (!Files.exists(Paths.get(FinFolderPolling.successDir))) Files.createDirectories(Paths.get(successDir));
            if (!Files.exists(Paths.get(FinFolderPolling.failDir))) Files.createDirectories(Paths.get(failDir));
            if (!Files.exists(Paths.get(FinFolderPolling.ecmDir))) Files.createDirectories(Paths.get(ecmDir));
            if (!Files.exists(Paths.get(FinFolderPolling.backupDir))) Files.createDirectories(Paths.get(backupDir));
        } catch (IOException e) {
            e.printStackTrace();
            logger.error(e);
        }
        try {
            Files.list(new File(eventPath.toString()).toPath())
                    .forEach(path -> {
                        doOneFile(path);
                    });
        } catch (IOException e) {
            e.printStackTrace();
        }
        while (true) {
            try {
                WatchKey watchKey = watcher.take();
                List<WatchEvent<?>> events = watchKey.pollEvents();
                for (WatchEvent<?> event : events) {
                    // You can listen for these events too :
                    //     StandardWatchEventKinds.ENTRY_DELETE
                    //     StandardWatchEventKinds.ENTRY_MODIFY
                    if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
                        String newFileName = event.context().toString();
                        logger.info("Created: " + newFileName);
                        Path path = Paths.get(eventPath.toString(), newFileName);
                        Thread.sleep(PAUSE_INTERVAL);
                        doOneFile(path);
                    }
                }
                watchKey.reset();
            } catch (Exception e) {
                System.out.println("Error: " + e.toString());
            }
        }
    }

    private synchronized void doOneFile(Path path) {
        List<String> cloneDeps = Arrays.asList(cloneToEcmDepts.split(","));
        Map<String, String> cloneDepsMap = new HashMap<>();
        cloneDeps.forEach(s -> cloneDepsMap.put(s, s));
        SwiftMessage swiftMessage = new SwiftMessage(path, cloneDepsMap);
        swiftMessage.process();
    }


    public static void main(String args[]) {
        try{
            socket =
                    new ServerSocket(Integer.parseInt(prop.getProperty("localPort")), 10, InetAddress.getLocalHost());

        }catch(java.net.BindException b){
            System.out.println("Already Running...");
            System.exit(1);
        }catch(Exception e){
            System.out.println(e.toString());
        }
        System.setProperty("javax.net.ssl.trustStore", prop.getProperty("trustStore"));
        System.setProperty("javax.net.ssl.trustStorePassword", prop.getProperty("trustStorePassword"));
//        SSLUtilities.trustAllHostnames();
        new FinFolderPolling(eventDir).start();
        logger.info("FinFolderPolling is running!");
    }
}