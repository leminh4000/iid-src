@javax.xml.bind.annotation.XmlSchema(namespace = "http://Swift_Insert_Email_Reminder_Module/Disable940950Service")
package vn.techcombank.rem.disableswift;
