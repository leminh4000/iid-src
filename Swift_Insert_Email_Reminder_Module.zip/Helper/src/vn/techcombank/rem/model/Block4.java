package vn.techcombank.rem.model;

import java.util.ArrayList;

public class Block4 {
  ArrayList<Property> tags = new ArrayList<Property>();


 // Getter Methods 



 // Setter Methods 


}