package vn.techcombank.rem;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ErrorHelper {

	private static final String INVALID_CONTENT_STRING = "Invalid content was found starting with element";
	private static final String NOT_VALID_START = "of element '";
	private static final String NOT_VALID_END = "' is not valid";
	private static final String NOT_VALID_VALUE = "*";
	private static final String NOT_VALID = NOT_VALID_START
			+ ".*"
			+ NOT_VALID_END;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String err = "http://InRemLib/IthaCreatingService:createItha_._type validation returned the following errors:\n" +
                "Property: /*[local-name()='createItha' and namespace-uri()='http://InRemLib/IthaCreatingService'][1]/createIthaReq[1]/ihta[1]/*[local-name()='debitAccNo' and namespace-uri()='http://InRemLib'][1] has error: CWLBN2000E: The following error or errors were found during business object instance validation: {[cvc-minLength-valid, cvc-minLength-valid: Value '' with length = '0' is not facet-valid with respect to minLength '1' for type '#AnonType_debitAccNoItha'., cvc-type.3.1.3, cvc-type.3.1.3: The value '' of element 'inr:debitAccNo' is not valid.of element 'inr:debitAccNoAAA' is not valid.]}/n";;
        System.out.println(sampleTransform(err));        
	}

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
	public static java.lang.String sampleTransform(
			java.lang.String failureString) {
//		System.out.println("failureString="+ failureString);
		Matcher m = Pattern.compile(NOT_VALID)
			     .matcher(failureString);
		java.lang.String result="";
		while (m.find()) {
			int invalidIndex2 = failureString.indexOf(NOT_VALID_START, m.start()) +  NOT_VALID_START.length();
			int invalidEndIndex = failureString.indexOf(NOT_VALID_END, invalidIndex2);
			String field = failureString.substring(invalidIndex2, invalidEndIndex);
			result += "Dữ liệu sau trống hoặc sai định dạng: " + field;
			 }
		return result;
	}

}
