package vn.techcombank.rem;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class DateTimeHelper {

	public static void main(String[] args) {
		System.out.println("aaa" + dateAndTimeTransform("200909", "1823"));
		System.out.println("aaa" + sampleTransform("2008252040"));

	}

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
	public static java.lang.Object sampleTransform(java.lang.Object Datetime) {
		System.out.println("Converting " + Datetime + " to dateTime");
		if (Datetime == null) return null;
		DateFormat destDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
		SimpleDateFormat sourceDateFormat = new SimpleDateFormat("yyMMddHHmm");
		Date convertedCurrentDate = null;
		try {
			convertedCurrentDate = sourceDateFormat.parse((String) Datetime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		System.out.println("Value is " + convertedCurrentDate );
		return destDateFormat.format(convertedCurrentDate);
	}
	
	public static java.lang.Object dateAndTimeTransform(java.lang.Object date, java.lang.Object time) {
		
		return sampleTransform(date.toString() + time.toString());
	}

}
