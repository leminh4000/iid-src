package vn.techcombank.rem;

import java.util.concurrent.ThreadLocalRandom;

public class AccId {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
	public static java.lang.Object sampleTransform() {
		return "FT1111111" +  ThreadLocalRandom.current().nextInt(10000, 99999);
	}

}
