package vn.techcombank.rem;

public class StringHelper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String[] samples = {"Hello", "World"};
		System.out.println(sampleTransform(samples));

	}

	/**
	 * Sample method that can be called from a Mapping Custom Java transform.
	 * The content of this method provides the implementation for the Custom Java transform.
	 */
	public static java.lang.Object sampleTransform(java.lang.Object AddtlInf) {
//		System.out.println("AddtlInf="+AddtlInf);
//		String[] infs = (String[]) AddtlInf;
//		String result = "";
//		String sep="\n";
//		for (int i=0; i<infs.length; i++){
//			result += (sep + infs[i]); 
//		}
//		if (!"".equals(result)) result = result.substring(sep.length());
//		return result;
		return AddtlInf;
	}

}
