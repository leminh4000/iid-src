package vn.techcombank.rem.model;

public class SwiftModel {
	private String timestamp;
	private float version;
	Data DataObject;

	// Getter Methods

	public String getTimestamp() {
		return timestamp;
	}

	public float getVersion() {
		return version;
	}

	public Data getData() {
		return DataObject;
	}

	// Setter Methods

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public void setVersion(float version) {
		this.version = version;
	}

	public void setData(Data dataObject) {
		this.DataObject = dataObject;
	}
}