package vn.techcombank.rem.model;

public class Property {
	private String name;
	private String value;

	// Getter Methods

	public String getName() {
		return name;
	}

	public String getValue() {
		return value;
	}

	// Setter Methods

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(String value) {
		this.value = value;
	}
}