package vn.techcombank.remittance.sla.model;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import com.google.gson.Gson;

public class TaskResult  implements Comparable<TaskResult>{
	
	
	
	private Date startDate;
	private Date endDate;
	private String id;
	private int intervalInMinutes;
	private double intervalInDays;
	private int averageInterval;
	private String credited;
	private String qualified = "N";
	private Date shrinkStartDate;
	private Date shrinkEndDate;
	private Date shrinkEndTime;
	private Date shrinkStartTime;
	private Date nextBusinessDate;
	private Date nextBusinessDate2;
	private String shrinkDateTime;
	private Date lastActionDate;
	private Date shrinkLastActionDate;
	private Date shrinkLastActionTime;
	private String haveReturnExtensionDate;
	
	public TaskResult() {
		super();
	}

	public TaskResult(Date startDate, Date endDate, String id, String credited,
			Date lastActionDate, String haveReturnExtensionDate) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.id = id;
		this.credited = credited;
		this.lastActionDate = lastActionDate;
		this.haveReturnExtensionDate = haveReturnExtensionDate;
	}



	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public String getCredited() {
		return credited;
	}
	public void setCredited(String credited) {
		this.credited = credited;
	}
	public Date getEndDate() {
		return endDate;
	}
	public int getIntervalInMinutes() {
		return intervalInMinutes;
	}
	public void setIntervalInMinutes(int intervalInMinutes) {
		this.intervalInMinutes = intervalInMinutes;
	}
	public String getShrinkDateTime() {
		return shrinkDateTime;
	}

	public void setShrinkDateTime(String shrinkDateTime) {
		this.shrinkDateTime = shrinkDateTime;
	}

	public Date getLastActionDate() {
		return lastActionDate;
	}

	public void setLastActionDate(Date lastActionDate) {
		this.lastActionDate = lastActionDate;
	}

	public String getHaveReturnExtensionDate() {
		return haveReturnExtensionDate;
	}

	public void setHaveReturnExtensionDate(String haveReturnExtensionDate) {
		this.haveReturnExtensionDate = haveReturnExtensionDate;
	}

	public int getAverageInterval() {
		return averageInterval;
	}
	public void setAverageInterval(int averageInterval) {
		this.averageInterval = averageInterval;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public Date getStartTime(){
		return getTime(this.startDate);
//		return ilog.rules.brl.IlrDateUtil.getTime(this.startDate);
	}

	public static Date getTime(Date date) {
		try {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss Z");
			return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z").parse("01/01/1970 " + sdf.format(date));
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	public Date getEndTime(){
		return getTime(this.endDate);
//		return ilog.rules.brl.IlrDateUtil.getTime(this.endDate);
	}
	public String getQualified() {
		return qualified;
	}
	public void setQualified(String qualified) {
		this.qualified = qualified;
	}
	public double getIntervalInDays() {
		return intervalInDays;
	}

	public void setIntervalInDays(double intervalInDays) {
		this.intervalInDays = intervalInDays;
	}

	public Date getNextBusinessDate() {
		return nextBusinessDate;
	}

	public void setNextBusinessDate(Date nextBusinessDate) {
		this.nextBusinessDate = nextBusinessDate;
	}

	public Date getShrinkStartDate() {
		return shrinkStartDate;
	}
	public void setShrinkStartDate(Date shrinkStartDate) {
		this.shrinkStartDate = shrinkStartDate;
	}
	public Date getShrinkEndDate() {
		return shrinkEndDate;
	}
	public void setShrinkEndDate(Date shrinkEndDate) {
		this.shrinkEndDate = shrinkEndDate;
	}
	public Date getShrinkEndTime() {
		return shrinkEndTime;
	}
	public Date getNextBusinessDate2() {
		return nextBusinessDate2;
	}

	public void setNextBusinessDate2(Date nextBusinessDate2) {
		this.nextBusinessDate2 = nextBusinessDate2;
	}

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public void setShrinkEndTime(Date shrinkEndTime) {
		this.shrinkEndTime = shrinkEndTime;
	}
	public Date getShrinkLastActionDate() {
		return shrinkLastActionDate;
	}

	public void setShrinkLastActionDate(Date shrinkLastActionDate) {
		this.shrinkLastActionDate = shrinkLastActionDate;
	}

	public Date getShrinkLastActionTime() {
		return shrinkLastActionTime;
	}

	public void setShrinkLastActionTime(Date shrinkLastActionTime) {
		this.shrinkLastActionTime = shrinkLastActionTime;
	}

	public Date getShrinkStartTime() {
		return shrinkStartTime;
	}
	public void setShrinkStartTime(Date shrinkStartTime) {
		this.shrinkStartTime = shrinkStartTime;
	}
	public Date getStartDay(){
		return atStartOfDay(this.startDate);
	}
	public Date getStartDay(Date date){
		return atStartOfDay(date);
	}
	public Date getEndDay(){
		return atStartOfDay(this.endDate);
	}
	public static Date atStartOfDay(Date date) {
	    Calendar calendar = Calendar.getInstance();
	    calendar.setTime(date);
	    calendar.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
	    calendar.set(Calendar.HOUR_OF_DAY, 0);
	    calendar.set(Calendar.MINUTE, 0);
	    calendar.set(Calendar.SECOND, 0);
	    calendar.set(Calendar.MILLISECOND, 0);
	    return calendar.getTime();
	}
	public int getStartDayOfWeek(){
		Calendar cal = Calendar.getInstance();
		cal.setTime(this.startDate);
		cal.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
		
		return cal.get(Calendar.DAY_OF_WEEK);
//		return ilog.rules.brl.IlrDateUtil.extractDayOfWeek(this.startDate);
	}
	public static int getDayOfWeek(Date date){
//		if (date == null) return 0;
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.setTimeZone(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
		return cal.get(Calendar.DAY_OF_WEEK);
		//		return ilog.rules.brl.IlrDateUtil.extractDayOfWeek(date);
	}
	public static void main(String[] args) throws ParseException{
		System.out.println(TaskResult.getDayOfWeek(null));
	}
	

	public static String toString(Date date){
		if (date==null) return "null";
		return new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(date);
	}
	
	public static Date decreaseDate(Date date){
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		cal.add(Calendar.DATE, -1);
		return cal.getTime();
	}
	public String gotShrinkDateTime(){
		DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy "); 
		dateFormat.setTimeZone(TimeZone.getTimeZone("GMT+07")); 
		DateFormat timeFormat = new SimpleDateFormat("hh:mm:ss a"); 
		timeFormat.setTimeZone(TimeZone.getTimeZone("GMT+07"));
		return dateFormat.format(shrinkStartDate) + timeFormat.format(shrinkStartTime);
	}
	public static Date chooseStartTime(Date shrinkStartTime, Date beginWorkingTime, Date shrinkStartDate, Date shrinkEndDate, Date endDateIterator){
		if (endDateIterator.before(shrinkStartDate)) return TaskAgreementResp.END;
		if (shrinkStartDate.equals(endDateIterator)) return shrinkStartTime;
		return beginWorkingTime;
	}
	public static Date chooseEndTime(Date shrinkEndTime, Date endWorkingTime, Date shrinkStartDate, Date shrinkEndDate, Date endDateIterator){
		if (shrinkEndDate.equals(endDateIterator)) {
//			if (shrinkStartDate.after(endWorkingDate)) return endWorkingDate;
			return shrinkEndTime;
			
		}
		return endWorkingTime;
	}
	public static boolean isSameDay(Date date1, Date date2){
		Calendar cal1 = Calendar.getInstance(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
		Calendar cal2 = Calendar.getInstance(TimeZone.getTimeZone("Asia/Ho_Chi_Minh"));
		cal1.setTime(date1);
		cal2.setTime(date2);
		return cal1.get(Calendar.DAY_OF_YEAR) == cal2.get(Calendar.DAY_OF_YEAR) &&
		                  cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR);
	}
	@Override
	public int compareTo(TaskResult o) {
		return new Integer(getIntervalInMinutes()).compareTo(new Integer(o.getIntervalInMinutes()));
	}
	public String toString() {
		return new Gson().toJson(this);
	}
	
	
	
}
