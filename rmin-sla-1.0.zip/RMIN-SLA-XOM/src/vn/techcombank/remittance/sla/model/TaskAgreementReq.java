package vn.techcombank.remittance.sla.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.management.RuntimeErrorException;

import com.google.gson.Gson;

public class TaskAgreementReq {
	private List<Task> taskAgreements = new ArrayList<Task>();
	private String process;
	private List<Date> restDays = new ArrayList<Date>();

	public TaskAgreementReq() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TaskAgreementReq(List<Task> taskAgreements, String process,
			List<Date> restDays) {
		super();
		this.taskAgreements = taskAgreements;
		this.process = process;
		this.restDays = restDays;
	}

	public List<Task> getTaskAgreements() {
		return taskAgreements;
	}

	public void setTaskAgreements(List<Task> taskAgreements) {
		this.taskAgreements = taskAgreements;
	}

	public String getProcess() {
		return process;
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public int getLength() {
		return taskAgreements.size();
	}

	public List<Date> getRestDays() {
		return restDays;
	}

	public void setRestDays(List<Date> restDays) {
		this.restDays = restDays;
	}

	public static TaskAgreementReq initilize() {
		java.util.List<Task> taskAgreements = new java.util.ArrayList<Task>();
		try {
			
//			 taskAgreements.add(new vn.techcombank.remittance.sla.model.Task(
//			 new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
//			  .parse("06/12/2020 07:00:00 +0700"), new
//			  SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
//			  .parse("08/12/2020 08:46:00 +0700"), "N", "1", null, "Y"));
//			  ArrayList<Date> restDays3 = new ArrayList<Date>();
//			  restDays3.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
//			  .parse("01/01/2020 00:00:00 +0700"));
//			  
//			  vn.techcombank.remittance.sla.model.TaskAgreementReq result = new
//			  vn.techcombank.remittance.sla.model.TaskAgreementReq(
//			  taskAgreements, "Accounting", restDays3); return result;
			 

			taskAgreements.add(new vn.techcombank.remittance.sla.model.Task(
					new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
							.parse("01/12/2020 17:00:00 +0700"),
					new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
							.parse("02/12/2020 08:15:00 +0700"), "Y", "1",
					null, "N"));
			ArrayList<Date> restDays3 = new ArrayList<Date>();
			restDays3.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
					.parse("01/01/2020 00:00:00 +0700"));

			vn.techcombank.remittance.sla.model.TaskAgreementReq result = new vn.techcombank.remittance.sla.model.TaskAgreementReq(
					taskAgreements, "Accounting", restDays3);
			return result;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	public static TaskAgreementReq initilizeTracing() {
		java.util.List<Task> taskAgreements = new java.util.ArrayList<Task>();
		try {
			
//			 taskAgreements.add(new vn.techcombank.remittance.sla.model.Task(
//			 new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
//			  .parse("06/12/2020 07:00:00 +0700"), new
//			  SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
//			  .parse("08/12/2020 08:46:00 +0700"), "N", "1", null, "Y"));
//			  ArrayList<Date> restDays3 = new ArrayList<Date>();
//			  restDays3.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
//			  .parse("01/01/2020 00:00:00 +0700"));
//			  
//			  vn.techcombank.remittance.sla.model.TaskAgreementReq result = new
//			  vn.techcombank.remittance.sla.model.TaskAgreementReq(
//			  taskAgreements, "Accounting", restDays3); return result;
			 

			taskAgreements.add(new vn.techcombank.remittance.sla.model.Task(
					new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
							.parse("01/12/2020 08:00:00 +0700"),
					new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
							.parse("22/12/2020 12:01:00 +0700"), "N", "1",
					new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
							.parse("19/12/2020 11:00:00 +0700"), "Y"));
			ArrayList<Date> restDays3 = new ArrayList<Date>();
			restDays3.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
					.parse("01/01/2020 00:00:00 +0700"));

			vn.techcombank.remittance.sla.model.TaskAgreementReq result = new vn.techcombank.remittance.sla.model.TaskAgreementReq(
					taskAgreements, "Tracing", restDays3);
			return result;
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;

	}

	
	public static void main(String[] args) {
		TaskAgreementReq initilize = vn.techcombank.remittance.sla.model.TaskAgreementReq
				.initilize();
		System.out.println(initilize.getLength());
	}

	public String toString() {
		return new Gson().toJson(this);
	}

	public Task gotTask(int index) {
		Task result = taskAgreements.get(index);
		return result;
	}

	public int gotSize() {
		return taskAgreements.size();
	}

	public static Date decreaseDate(Date date, Date time) {
		try {
			long diffInMillies = time.getTime()
					- TaskAgreementResp.ZERO.getTime();
			return new Date(date.getTime() - diffInMillies);
		} catch (Exception e) {
			return null;
		}
	}

	public static Date increaseDate(Date date, Date time) {
		try {
			long diffInMillies = time.getTime()
					- TaskAgreementResp.ZERO.getTime();
			Date result = new Date(date.getTime() + diffInMillies);
			return result;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

}
