package vn.techcombank.remittance.sla.model;

import ilog.rules.xml.binding.IlrConstant;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import com.google.gson.Gson;

public class Task{
	private Date startDate;
	private Date endDate;
	private String credited;
	private String id;
	private Date lastActionDate;
	private String haveReturnExtensionDate;
	public Task() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Task(Date startDate, Date endDate, String credited, String id, Date lastActionDate, String haveReturnExtentionDate) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.credited = credited;
		this.id = id;
		this.lastActionDate =  lastActionDate;
		this.haveReturnExtensionDate =  haveReturnExtentionDate;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getCredited() {
		return credited;
	}

	public Date getLastActionDate() {
		return lastActionDate;
	}

	public void setLastActionDate(Date lastActionDate) {
		this.lastActionDate = lastActionDate;
	}

	public String getHaveReturnExtensionDate() {
		return haveReturnExtensionDate;
	}

	public void setHaveReturnExtensionDate(String haveReturnExtensionDate) {
		this.haveReturnExtensionDate = haveReturnExtensionDate;
	}

	public void setCredited(String credited) {
		this.credited = credited;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	
	
	
}
