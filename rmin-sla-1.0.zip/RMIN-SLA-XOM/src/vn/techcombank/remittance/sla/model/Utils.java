package vn.techcombank.remittance.sla.model;

public class Utils {

	public Utils() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static double add(double n1, double n2){
		return n1+n2;
	}

}
