package vn.techcombank.remittance.sla.model;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import com.google.gson.Gson;

public class TaskAgreementResp {
	static Date ZERO=null;
	static Date ONE=null;
	static Date END=null;
	static{
		try {
			ZERO = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z").parse("01/01/1970 00:00:00 +0700");
			ONE = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z").parse("02/01/1970 00:00:00 +0700");
			END = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z").parse("01/01/3000 00:00:00 +0700");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	private List<TaskResult> taskResults = new ArrayList<TaskResult>();
	private List<TaskResult> taskCrediteds = new ArrayList<TaskResult>();
	private List<TaskResult> taskOthers = new ArrayList<TaskResult>();
	private List<TaskResult> taskZeros = new ArrayList<TaskResult>();
	private int countCredited = 0;
	private int countOther = 0;
	private long utilCountTotalCredited = 0;
	private long utilCountTotalOther = 0;
	private List<Date> restDays = new ArrayList<Date>();

	private int index;

	public TaskAgreementResp() {
		super();
		// TODO Auto-generated constructor stub
	}
	

	public TaskAgreementResp(List<TaskResult> taskResults,
			List<TaskResult> taskCrediteds, List<TaskResult> taskOthers,
			List<TaskResult> taskZeros, long utilCountTotalCredited,
			long utilCountTotalOther, List<Date> restDays) {
		super();
		this.taskResults = taskResults;
		this.taskCrediteds = taskCrediteds;
		this.taskOthers = taskOthers;
		this.taskZeros = taskZeros;
		this.utilCountTotalCredited = utilCountTotalCredited;
		this.utilCountTotalOther = utilCountTotalOther;
		this.restDays = restDays;
	}

	public List<Date> getRestDays() {
		return restDays;
	}


	public void setRestDays(List<Date> restDays) {
		this.restDays = restDays;
	}


	public List<TaskResult> getTaskResults() {
		return taskResults;
	}

	public void setTaskResults(List<TaskResult> taskResults) {
		this.taskResults = taskResults;
	}

	public int getLength() {
		return taskResults.size();
	}

	public TaskResult getTaskResult() {
		return taskResults.get(index);
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public void add(Task task) {
		TaskResult taskResult = new TaskResult(task.getStartDate(), task.getEndDate(), task.getId(), task.getCredited(), task.getLastActionDate(), task.getHaveReturnExtensionDate());
		taskResults.add(taskResult);
	}

	public String toString() {
		return new Gson().toJson(this);
	}

	public int getCreditedListSize() {
		return taskCrediteds.size();
	}

	public int getOtherListSize() {
		return taskOthers.size();
	}

	public TaskResult getCreditedTask(int index) {
		return taskCrediteds.get(index);
	}

	public TaskResult getOtherTask(int index) {
		return taskOthers.get(index);
	}

	public TaskResult getTaskResult(int index) {
		return taskResults.get(index);
	}

	public void sort() {
		Collections.sort(taskResults);
	}

	public void calculateCumulativeAverage() {
		for (Iterator iterator = taskResults.iterator(); iterator.hasNext();) {
			TaskResult task = (TaskResult) iterator.next();
			if (task.getIntervalInMinutes() == 0) {
				task.setAverageInterval(0);
				task.setQualified("Y");
				taskZeros.add(task);
			} else if ("Y".equals(task.getCredited())) {
				taskCrediteds.add(task);
			} else {
				taskOthers.add(task);
			}
		}
		for (Iterator iterator = taskCrediteds.iterator(); iterator.hasNext();) {
			TaskResult task = (TaskResult) iterator.next();
			countCredited++;
			utilCountTotalCredited += task.getIntervalInMinutes();
			task.setAverageInterval((int) (utilCountTotalCredited / countCredited));
		}
		for (Iterator iterator = taskOthers.iterator(); iterator.hasNext();) {
			TaskResult task = (TaskResult) iterator.next();
			countOther++;
			utilCountTotalOther += task.getIntervalInMinutes();
			task.setAverageInterval((int) (utilCountTotalOther / countOther));
		}
	}
	
	public int getInterval(int interval, Date date1, Date date2, Date date){
		if (wasRestDay(date)) return interval;
		if (date1 == null || date2 == null) return interval;
		long diffInMillies = date2.getTime() - date1.getTime();
		if (diffInMillies <= 0) return interval;
		return interval + (int) (diffInMillies/(1000*60));
	}
	private boolean wasRestDay(Date date) {
		// TODO Auto-generated method stub
		boolean result = restDays != null && !restDays.isEmpty() && restDays.contains(date);
		return result;
	}
	
	public int increaseInterval(int interval, Date time, Date date){
		if (time == null) return interval;
		return interval + getInterval(0, TaskAgreementResp.ZERO, time, date);
	}
	public int decreaseInterval(int interval, Date time, Date date){
		if (time == null) return interval;
		return interval - getInterval(0, ZERO, time, date);
	}
	
	public void transportRestDays(TaskAgreementReq req){
		this.setRestDays(req.getRestDays());
	}
	
	public Date increaseDateByRestDays(Date date){
		Date result = date;
		if (!restDays.contains(result)) return result;
		while (restDays.contains(result)){
			result = TaskAgreementReq.increaseDate(result, ONE);
			System.out.println("result = " + result);
		}
		return result;
	}
	
	public Date decreaseDateByRestDays(Date date){
		Date result = date;
		if (!restDays.contains(result)) return date;
		while (restDays.contains(result)){
			result = TaskAgreementReq.decreaseDate(result, ONE);
		}
		return result;
	}
	public static void main(String[] args) throws Exception {
		TaskAgreementResp resp = new TaskAgreementResp();
		ArrayList<Date> restDays3 = new ArrayList<Date>();
		restDays3.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
				.parse("23/11/2020 00:00:00 +0700"));
		restDays3.add(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
				.parse("24/11/2020 00:00:00 +0700"));
		resp.setRestDays(restDays3);
		
		TaskResult taskResult = new TaskResult();
		taskResult.setStartDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
				.parse("21/11/2020 10:00:00 +0700"));
		taskResult.setEndDate(new SimpleDateFormat("dd/MM/yyyy HH:mm:ss Z")
		.parse("24/11/2020 13:00:00 +0700"));
		
		
	}
	

}
